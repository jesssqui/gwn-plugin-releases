<?php
/**
 * One packing slip. Override: yourtheme/gwn-packing-slips/slip.php
 *
 * @var WC_Order $order
 * @var array    $rows     gwnps_rows( $order )
 * @var int      $units    number of things that go in the box
 * @var string   $format   letter | label
 * @var array    $classes
 */
defined( 'ABSPATH' ) || exit;

$logo     = gwnps_logo();
$images   = 'letter' === $format && (bool) apply_filters( 'gwnps_show_images', false, $order ); // product photos: GWND Fulfillment Pro
$sku      = gwnps_on( 'show_sku' );
$ship     = gwnps_ship_address( $order );
$phone    = $order->get_shipping_phone() ?: $order->get_billing_phone();
$email    = $order->get_billing_email();
$method   = gwnps_shipping_method( $order );
$note     = $order->get_customer_note();
$help     = gwnps_help_email();
$footer   = gwnps_opt( 'footer' );
if ( '' === $footer ) {
	$footer = implode( ' · ', array_filter( array( preg_replace( '#^https?://(www\.)?#', '', untrailingslashit( home_url() ) ), $help ) ) );
}
$created  = $order->get_date_created();

$row_html = function ( $r, $cls, $is_child = false ) use ( $images, $sku ) {
	echo '<tr class="' . esc_attr( $cls ) . '">';
	echo '<td class="c-chk">' . ( empty( $r['children'] ) ? '<span class="ps-chk"></span>' : '' ) . '</td>';
	if ( $images ) {
		echo '<td class="c-img">' . ( $r['image'] ? '<img class="ps-img" src="' . esc_url( $r['image'] ) . '" alt="">' : '' ) . '</td>';
	}
	echo '<td class="c-item"><div class="ps-name">' . esc_html( $r['name'] ) . '</div>';
	if ( $r['meta'] ) {
		$parts = array();
		foreach ( $r['meta'] as $k => $v ) {
			$parts[] = $k . ': ' . $v;
		}
		echo '<div class="ps-meta">' . esc_html( implode( ' · ', $parts ) ) . '</div>';
	}
	if ( $sku && $r['sku'] ) {
		echo '<div class="ps-sku">SKU ' . esc_html( $r['sku'] ) . '</div>';
	}
	echo '</td>';
	$qcls = 'ps-qty' . ( $r['qty'] > 1 ? ' is-multi' : '' ) . ( empty( $r['children'] ) ? '' : ' is-bundle' );
	echo '<td class="c-qty"><span class="' . esc_attr( $qcls ) . '">' . (int) $r['qty'] . '</span></td>';
	echo '</tr>';
};
?>
<div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" data-pn="Order #<?php echo esc_attr( $order->get_order_number() ); ?>">
	<header class="ps-head">
		<div class="ps-logo">
			<?php if ( $logo ) : ?>
				<img src="<?php echo esc_url( $logo ); ?>" alt="<?php echo esc_attr( gwnps_store_name() ); ?>">
			<?php else : ?>
				<div class="ps-logo__text"><?php echo esc_html( gwnps_store_name() ); ?></div>
			<?php endif; ?>
		</div>
		<div class="ps-head__meta">
			<span class="ps-kicker">Packing slip</span>
			<div class="ps-num">Order #<?php echo esc_html( $order->get_order_number() ); ?></div>
			<?php if ( $created ) : ?>
				<div><?php echo esc_html( wc_format_datetime( $created ) ); ?></div>
			<?php endif; ?>
		</div>
	</header>

	<section class="ps-addr">
		<div class="ps-box">
			<p class="ps-box__t">Ship to</p>
			<div class="ps-to"><?php echo wp_kses( $ship ?: '—', array( 'br' => array() ) ); ?></div>
			<?php if ( $phone || $email ) : ?>
				<div class="ps-contact"><?php echo esc_html( implode( ' · ', array_filter( array( $phone, $email ) ) ) ); ?></div>
			<?php endif; ?>
			<?php if ( $method ) : ?>
				<div class="ps-ship"><?php echo esc_html( $method ); ?></div>
			<?php endif; ?>
		</div>
		<?php if ( gwnps_on( 'show_from' ) ) : ?>
			<div class="ps-box ps-from">
				<p class="ps-box__t">From</p>
				<?php echo wp_kses( gwnps_store_address(), array( 'br' => array() ) ); ?>
			</div>
		<?php endif; ?>
	</section>

	<?php if ( $note ) : ?>
		<div class="ps-note"><strong>Customer note</strong><?php echo nl2br( esc_html( $note ) ); ?></div>
	<?php endif; ?>

	<table class="ps-items">
		<thead><tr>
			<th class="c-chk"></th>
			<?php if ( $images ) : ?><th class="c-img"></th><?php endif; ?>
			<th class="c-item">Item <span class="ps-th-order">· Order #<?php echo esc_html( $order->get_order_number() ); ?></span></th>
			<th class="c-qty">Qty</th>
		</tr></thead>
		<?php
		// Each bundle gets its own <tbody> so it isn't split across printed pages; loose items share one.
		$open = false;
		foreach ( $rows as $r ) {
			if ( $r['children'] ) {
				if ( $open ) {
					echo '</tbody>';
					$open = false;
				}
				echo '<tbody class="ps-group">';
				$row_html( $r, 'is-parent' );
				$n = count( $r['children'] );
				foreach ( $r['children'] as $i => $c ) {
					$row_html( $c, 'is-child' . ( $i === $n - 1 ? ' is-last-child' : '' ), true );
				}
				echo '</tbody>';
				continue;
			}
			if ( ! $open ) {
				echo '<tbody>';
				$open = true;
			}
			$row_html( $r, 'is-item' );
		}
		if ( $open ) {
			echo '</tbody>';
		}
		?>
	</table>
	<?php /* translators: %d: number of items */ ?>
	<div class="ps-count"><?php echo esc_html( sprintf( _n( '%d item to pack', '%d items to pack', $units, 'gwnd-fulfillment' ), $units ) ); ?></div>

	<?php do_action( 'gwnps_after_items', $order, $format ); // GWND Fulfillment Pro: thank-you message and QR code ?>


	<?php if ( $footer ) : ?>
		<div class="ps-foot"><?php echo esc_html( $footer ); ?></div>
	<?php endif; ?>
</div>
