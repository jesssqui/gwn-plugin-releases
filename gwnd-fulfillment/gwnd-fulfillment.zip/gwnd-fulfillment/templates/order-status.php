<?php
/**
 * Order status page. Override in your theme: gwn-order-tracking/order-status.php
 *
 * Available: $GLOBALS['gwnot_order'] (WC_Order|null), $GLOBALS['gwnot_error'] (string|null).
 */
defined( 'ABSPATH' ) || exit;

$order = $GLOBALS['gwnot_order'] ?? null;
$error = $GLOBALS['gwnot_error'] ?? '';
$styled = function_exists( 'gwnf_look_on' ) && gwnf_look_on( 'status' );
// Block themes limit content to a narrow column: let the page use the wide (or, with a page colour, full) width.
$align  = function_exists( 'gwnot_is_block_theme' ) && gwnot_is_block_theme() ? ( $styled && gwnf_look( 'bg' ) ? 'alignfull' : 'alignwide' ) : '';
$wrap   = trim( 'ot-wrap ' . $align . ' ' . ( $styled ? gwnf_look_classes() : '' ) . ' ' . apply_filters( 'gwnot_wrap_class', '' ) );
$vars   = $styled ? gwnf_look_vars() : '';
$on_dark_hero = $styled && in_array( gwnf_look( 'layout' ), array( 'split', 'banner' ), true ) ? gwnf_is_dark( gwnf_look( 'brand' ) ) : ( $styled && gwnf_look( 'bg' ) && gwnf_is_dark( gwnf_look( 'bg' ) ) );
$logo   = $styled ? gwnf_logo_html( $on_dark_hero ) : '';
$shop  = wc_get_page_permalink( 'shop' );
$help  = gwnot_help_email();

gwnot_get_header();
echo '<div class="' . esc_attr( $wrap ) . '"' . ( $vars ? ' style="' . esc_attr( $vars ) . '"' : '' ) . '><main class="ot" id="ot">';

if ( ! $order ) :
	?>
	<header class="ot-hero ot-head">
		<?php echo $logo; // phpcs:ignore WordPress.Security.EscapeOutput -- built with wp_get_attachment_image ?>
		<p class="ot-kicker"><?php esc_html_e( 'Order status', 'gwnd-fulfillment' ); ?></p>
		<h1 class="ot-title"><?php echo esc_html( gwnf_w( 'lookup_title' ) ); ?></h1>
		<p class="ot-lead"><?php echo esc_html( gwnf_w( 'lookup_lead' ) ); ?></p>
	</header>
	<div class="ot-card">
		<?php if ( $error ) : ?><p class="ot-notice" role="alert"><?php echo esc_html( $error ); ?></p><?php endif; ?>
		<form class="ot-form" method="post" action="<?php echo esc_url( gwnot_lookup_url() ); ?>">
			<?php wp_nonce_field( 'gwnot_lookup', 'gwnot_lnonce' ); ?>
			<div><label for="ot-order"><?php esc_html_e( 'Order number', 'gwnd-fulfillment' ); ?></label><input id="ot-order" name="gwnot_order" inputmode="numeric" autocomplete="off" required></div>
			<div><label for="ot-email"><?php esc_html_e( 'Email', 'gwnd-fulfillment' ); ?></label><input id="ot-email" name="gwnot_email" type="email" autocomplete="email" required></div>
			<button type="submit" name="gwnot_lookup" value="1" class="<?php echo esc_attr( gwnot_btn( 'primary' ) ); ?>"><?php echo esc_html( gwnf_w( 'lookup_button' ) ); ?></button>
		</form>
		<?php if ( is_user_logged_in() ) : ?>
			<p class="ot-lead" style="margin-top:16px">
				<?php
				/* translators: %s: link to My account */
				printf( esc_html__( 'Signed in? All your orders are in %s.', 'gwnd-fulfillment' ), '<a href="' . esc_url( wc_get_account_endpoint_url( 'orders' ) ) . '">' . esc_html__( 'My account', 'gwnd-fulfillment' ) . '</a>' );
				?>
			</p>
		<?php endif; ?>
	</div>
	<?php
else :
	$copy  = gwnot_status_copy( $order );
	$steps = gwnot_steps( $order );
	$bad   = $order->has_status( array( 'cancelled', 'refunded', 'failed' ) );
	$views = gwnot_views( $order );
	$first = $views ? $views[ count( $views ) - 1 ] : null;
	// Headline: the last words can carry a marker highlight (Look → Highlight).
	$words = preg_split( '/\s+/', trim( $copy['title'] ) );
	$tail  = count( $words ) > 3 ? array_splice( $words, -3 ) : ( count( $words ) > 1 ? array_splice( $words, -1 ) : array() );
	?>
	<header class="ot-hero ot-head">
		<?php echo $logo; // phpcs:ignore WordPress.Security.EscapeOutput -- built with wp_get_attachment_image ?>
		<p class="ot-kicker">
			<?php
			/* translators: 1: order number, 2: date placed */
			echo esc_html( sprintf( __( 'Order #%1$s · placed %2$s', 'gwnd-fulfillment' ), $order->get_order_number(), gwnot_date( $order->get_date_created() ? $order->get_date_created()->getTimestamp() : 0 ) ) );
			?>
		</p>
		<h1 class="ot-title"><?php echo esc_html( implode( ' ', $words ) ); ?><?php if ( $tail ) : ?> <span class="ot-title__hl"><?php echo esc_html( implode( ' ', $tail ) ); ?></span><?php endif; ?></h1>
		<?php if ( $copy['lead'] ) : ?><p class="ot-lead"><?php echo esc_html( $copy['lead'] ); ?></p><?php endif; ?>
		<?php if ( $first && $first['url'] && ! $bad ) : ?>
			<p class="ot-hero__cta"><a class="<?php echo esc_attr( gwnot_btn( 'primary' ) ); ?> ot-btn--hero" href="<?php echo esc_url( $first['url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( gwnf_w( 'track_button' ) ); ?> <span aria-hidden="true">↗</span></a></p>
		<?php endif; ?>
	</header>

	<?php if ( ! $bad ) : ?>
		<ol class="ot-steps">
			<?php foreach ( $steps as $s ) : ?>
				<li class="ot-step is-<?php echo esc_attr( $s[2] ); ?>"><b><?php echo esc_html( $s[0] ); ?></b><span><?php echo esc_html( $s[1] ); ?></span></li>
			<?php endforeach; ?>
		</ol>
		<?php do_action( 'gwnot_after_steps', $order, $steps ); ?>
	<?php endif; ?>

	<?php if ( gwnot_views( $order ) ) : ?>
		<section class="ot-card ot-card--tracking">
			<h2 class="ot-card__title"><?php echo esc_html( gwnf_w( 'tracking_title' ) ); ?></h2>
			<?php echo gwnot_shipments_html( $order ); // phpcs:ignore ?>
		</section>
	<?php endif; ?>

	<?php do_action( 'gwnot_status_before_details', $order ); ?>

	<div class="ot-grid">
		<section class="ot-card ot-card--items">
			<h2 class="ot-card__title"><?php echo esc_html( gwnf_w( 'items_title' ) ); ?></h2>
			<ul class="ot-items">
				<?php
				foreach ( $order->get_items() as $item ) :
					$product = $item->get_product();
					$img_id  = $product ? ( $product->get_image_id() ?: get_post_thumbnail_id( $product->get_parent_id() ) ) : 0;
					$meta    = wc_display_item_meta( $item, array( 'echo' => false, 'before' => '', 'after' => '', 'separator' => ' · ', 'autop' => false, 'label_before' => '', 'label_after' => ': ' ) );
					?>
					<li class="ot-item">
						<span class="ot-item__img"><?php echo $img_id ? wp_get_attachment_image( $img_id, 'woocommerce_thumbnail', false, array( 'alt' => '' ) ) : ''; // phpcs:ignore ?><span class="ot-item__qty"><?php echo (int) $item->get_quantity(); ?></span></span>
						<span class="ot-item__name"><?php echo esc_html( $item->get_name() ); ?><?php if ( $meta ) : ?><span class="ot-item__meta"><?php echo wp_kses_post( $meta ); ?></span><?php endif; ?></span>
						<span class="ot-item__total"><?php echo wp_kses_post( $order->get_formatted_line_subtotal( $item ) ); ?></span>
					</li>
				<?php endforeach; ?>
			</ul>
			<table class="ot-totals">
				<?php foreach ( $order->get_order_item_totals() as $tkey => $row ) : ?>
					<tr class="ot-totals__<?php echo esc_attr( sanitize_html_class( $tkey ) ); ?>"><th scope="row"><?php echo esc_html( wp_strip_all_tags( $row['label'] ) ); ?></th><td><?php echo wp_kses_post( $row['value'] ); ?></td></tr>
				<?php endforeach; ?>
			</table>
		</section>

		<aside class="ot-side">
			<section class="ot-card">
				<dl class="ot-dl">
					<?php if ( $order->has_shipping_address() ) : ?>
						<dt><?php esc_html_e( 'Shipping to', 'gwnd-fulfillment' ); ?></dt><dd><address><?php echo wp_kses_post( $order->get_formatted_shipping_address() ); ?></address></dd>
						<?php if ( $order->get_shipping_method() ) : ?><dt><?php esc_html_e( 'Shipping method', 'gwnd-fulfillment' ); ?></dt><dd><?php echo esc_html( $order->get_shipping_method() ); ?></dd><?php endif; ?>
					<?php elseif ( $order->get_formatted_billing_address() ) : ?>
						<dt><?php esc_html_e( 'Billing address', 'gwnd-fulfillment' ); ?></dt><dd><address><?php echo wp_kses_post( $order->get_formatted_billing_address() ); ?></address></dd>
					<?php endif; ?>
					<?php if ( $order->get_billing_email() ) : ?><dt><?php esc_html_e( 'Contact', 'gwnd-fulfillment' ); ?></dt><dd><?php echo esc_html( $order->get_billing_email() ); ?></dd><?php endif; ?>
					<?php if ( $order->get_payment_method_title() ) : ?><dt><?php esc_html_e( 'Payment', 'gwnd-fulfillment' ); ?></dt><dd><?php echo esc_html( $order->get_payment_method_title() ); ?></dd><?php endif; ?>
				</dl>
			</section>
			<section class="ot-card ot-card--help">
				<h2 class="ot-card__title"><?php echo esc_html( gwnf_w( 'help_title' ) ); ?></h2>
				<?php
				/* translators: %s: order number */
				$mailto = '<a href="mailto:' . esc_attr( $help ) . '?subject=' . rawurlencode( sprintf( __( 'Order #%s', 'gwnd-fulfillment' ), $order->get_order_number() ) ) . '">' . esc_html( $help ) . '</a>';
				echo '<p>' . str_replace( esc_html( '{email}' ), $mailto, esc_html( gwnf_w( 'help_text' ) ) ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput -- both parts escaped above
				?>
				<div class="ot-actions">
					<a class="<?php echo esc_attr( gwnot_btn( 'primary' ) ); ?>" href="<?php echo esc_url( $shop ); ?>"><?php echo esc_html( gwnf_w( 'shop_button' ) ); ?></a>
					<?php if ( is_user_logged_in() && (int) $order->get_customer_id() === get_current_user_id() ) : ?>
						<a class="<?php echo esc_attr( gwnot_btn( 'secondary' ) ); ?>" href="<?php echo esc_url( wc_get_account_endpoint_url( 'orders' ) ); ?>"><?php esc_html_e( 'My orders', 'gwnd-fulfillment' ); ?></a>
					<?php endif; ?>
				</div>
			</section>
		</aside>
	</div>
	<?php do_action( 'gwnot_status_after', $order ); ?>
<?php endif; ?>
</main></div>
<?php
gwnot_get_footer();
