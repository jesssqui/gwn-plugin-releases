<?php
/**
 * Uninstall: removes the settings (on/off, look, wording, workflow), cached tokens and rewrite bookkeeping.
 * Tracking numbers, packing photos (uploads/gwnd-packing-photos/) and "slip printed" markers are always kept —
 * they're order history. Photos of an order are removed when that order is permanently deleted.
 * Packing slip settings are kept too, unless wp-config.php defines GWNPS_REMOVE_SETTINGS_ON_UNINSTALL as true.
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

if ( function_exists( 'as_unschedule_all_actions' ) ) {
	as_unschedule_all_actions( '', array(), 'gwnd-fulfillment' ); // live tracking poller
}
global $wpdb;
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_gwnot\\_%' OR option_name LIKE '\\_transient\\_timeout\\_gwnot\\_%'" ); // carrier tokens, test results
foreach ( array( 'gwnf_modules', 'gwnf_replaced_legacy', 'gwnot_rewrite', 'gwnot_last_carrier', 'gwnf_look', 'gwnf_words', 'gwnf_flow', 'gwnfc_update_signatures', 'gwnfc_auto_updates_defaulted', 'gwnfc_auto_updates_notice', 'gwnfc_auto_updates_notice_dismissed' ) as $o ) {
	delete_option( $o );
}
if ( defined( 'GWNPS_REMOVE_SETTINGS_ON_UNINSTALL' ) && GWNPS_REMOVE_SETTINGS_ON_UNINSTALL ) {
	delete_option( 'gwnps_settings' );
}
flush_rewrite_rules( false );
