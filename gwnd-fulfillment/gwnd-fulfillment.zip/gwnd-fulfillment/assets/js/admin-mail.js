/* WooCommerce → Fulfillment → Emails: colour picker and live preview of the real email with unsaved changes. */
( function ( $ ) {
	var form = document.getElementById( 'gwnf-mail' );
	var box = document.querySelector( '.gwnf-preview--mail' );
	if ( ! form || ! box ) {
		return;
	}
	var frame = box.querySelector( 'iframe' );
	var timer = null;

	function kind() {
		var k = form.querySelector( 'input[name="gwnf_mail_kind"]:checked' );
		return k ? k.value : 'shipped';
	}

	/** Unsaved values: { mail: {…}, words: {…} } (hidden "no" + checkbox "yes": the checked box wins). */
	function values() {
		var out = { mail: {}, words: {} };
		[].forEach.call( form.elements, function ( el ) {
			var m = el.name && el.name.match( /^gwnf_(mail|words)\[([a-z_]+)\]$/ );
			if ( ! m || ( ( el.type === 'radio' || el.type === 'checkbox' ) && ! el.checked ) ) {
				return;
			}
			out[ m[ 1 ] === 'mail' ? 'mail' : 'words' ][ m[ 2 ] ] = el.value;
		} );
		return out;
	}

	function refresh( now ) {
		clearTimeout( timer );
		timer = setTimeout( function () {
			frame.src = box.getAttribute( 'data-base' ) + '&kind=' + encodeURIComponent( kind() ) + '&v=' + encodeURIComponent( JSON.stringify( values() ) );
			var test = document.querySelector( '.gwnf-mail-test input[name="kind"]' );
			if ( test ) {
				test.value = kind();
			}
		}, now ? 0 : 500 );
	}

	form.addEventListener( 'input', function () {
		refresh();
	} );
	form.addEventListener( 'change', function ( e ) {
		refresh( e.target && e.target.name === 'gwnf_mail_kind' );
	} );
	if ( $.fn.wpColorPicker ) {
		$( '.gwnf-mail-color' ).wpColorPicker( {
			change: function () {
				setTimeout( refresh, 0 );
			},
			clear: function () {
				setTimeout( refresh, 0 );
			},
		} );
	}
}( jQuery ) );
