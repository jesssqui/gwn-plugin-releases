/* WooCommerce → Fulfillment → Look: presets, logo picker, colour pickers, contrast check and live preview. */
( function ( $ ) {
	var cfg = window.gwnfAdmin || {};
	var form = document.getElementById( 'gwnf-look' );
	if ( ! form ) {
		return;
	}
	var timer = null;

	function field( key ) {
		return form.querySelectorAll( '[name="gwnf_look[' + key + ']"]' );
	}

	/** Current form values as an object (hidden "no" + checkbox "yes": the checked box wins). */
	function values() {
		var out = {};
		[].forEach.call( form.elements, function ( el ) {
			var m = el.name && el.name.match( /^gwnf_look\[([a-z_]+)\]$/ );
			if ( ! m ) {
				return;
			}
			if ( ( el.type === 'radio' || el.type === 'checkbox' ) && ! el.checked ) {
				return;
			}
			out[ m[ 1 ] ] = el.value;
		} );
		return out;
	}

	function set( key, val ) {
		[].forEach.call( field( key ), function ( el ) {
			if ( el.type === 'radio' ) {
				el.checked = el.value === String( val );
			} else if ( el.type === 'checkbox' ) {
				el.checked = String( val ) === el.value;
			} else if ( el.type === 'hidden' && el.nextElementSibling && el.nextElementSibling.type === 'checkbox' ) {
				// handled by the checkbox
			} else if ( $( el ).hasClass( 'gwnf-colorpick' ) && $.fn.wpColorPicker ) {
				$( el ).wpColorPicker( 'color', val || '' );
				if ( ! val ) {
					el.value = '';
				}
			} else {
				el.value = val;
			}
		} );
	}

	/* ---- Live preview ---- */
	function refresh() {
		clearTimeout( timer );
		timer = setTimeout( function () {
			var frame = document.querySelector( '.gwnf-preview iframe' );
			if ( ! frame || ! cfg.preview ) {
				return;
			}
			var url = cfg.preview + '&gwnf_look=' + encodeURIComponent( JSON.stringify( values() ) );
			frame.src = url;
			var open = document.querySelector( '.gwnf-preview-open' );
			if ( open ) {
				open.href = url;
			}
		}, 450 );
		contrast();
	}

	/* ---- Contrast check (WCAG ratio) ---- */
	function lum( hex ) {
		hex = String( hex || '' ).replace( '#', '' );
		if ( hex.length === 3 ) {
			hex = hex.replace( /(.)/g, '$1$1' );
		}
		if ( ! /^[0-9a-f]{6}$/i.test( hex ) ) {
			return null;
		}
		var c = [ 0, 2, 4 ].map( function ( i ) {
			var v = parseInt( hex.substr( i, 2 ), 16 ) / 255;
			return v <= 0.03928 ? v / 12.92 : Math.pow( ( v + 0.055 ) / 1.055, 2.4 );
		} );
		return 0.2126 * c[ 0 ] + 0.7152 * c[ 1 ] + 0.0722 * c[ 2 ];
	}
	function ratio( a, b ) {
		var x = lum( a ), y = lum( b );
		if ( x === null || y === null ) {
			return null;
		}
		return ( Math.max( x, y ) + 0.05 ) / ( Math.min( x, y ) + 0.05 );
	}
	function contrast() {
		var box = form.querySelector( '.gwnf-contrast' );
		if ( ! box ) {
			return;
		}
		var v = values(), low = [];
		( cfg.pairs || [] ).forEach( function ( p ) {
			var bg = v[ p[ 0 ] ], fg = v[ p[ 1 ] ];
			if ( ! fg && p[ 1 ] === 'on_brand' && bg ) {
				fg = lum( bg ) !== null && lum( bg ) < 0.2 ? '#ffffff' : '#111111';
			}
			var r = ratio( bg, fg );
			if ( r !== null && r < 4.5 ) {
				low.push( p[ 2 ] + ' ' + r.toFixed( 1 ) + ':1' );
			}
		} );
		box.className = 'gwnf-contrast ' + ( low.length ? 'is-low' : 'is-ok' );
		box.textContent = low.length ? String( cfg.lowText ).replace( '%s', low.join( ', ' ) ) : cfg.okText;
	}

	/* ---- Colour pickers ---- */
	if ( $.fn.wpColorPicker ) {
		$( '.gwnf-colorpick' ).wpColorPicker( {
			change: function ( e, ui ) {
				e.target.value = ui.color.toString();
				builderChanged( e.target );
				refresh();
			},
			clear: function () {
				refresh();
			}
		} );
	}

	/* ---- Presets: picking a style fills in its values ---- */
	var applying = false;
	form.addEventListener( 'change', function ( e ) {
		var t = e.target;
		if ( t.name === 'gwnf_look[style]' ) {
			var p = ( cfg.styles || {} )[ t.value ];
			if ( p ) {
				applying = true;
				Object.keys( p ).forEach( function ( k ) {
					set( k, p[ k ] );
				} );
				applying = false;
			}
		} else {
			builderChanged( t );
		}
		refresh();
	} );
	form.addEventListener( 'input', function ( e ) {
		if ( e.target.type === 'text' || e.target.type === 'number' || e.target.type === 'range' || e.target.tagName === 'TEXTAREA' ) {
			builderChanged( e.target );
			refresh();
		}
	} );

	/** Changing a builder setting turns a preset into "My style". */
	function builderChanged( el ) {
		if ( applying || ! el || ! el.closest || ! el.closest( '.gwnf-builder' ) ) {
			return;
		}
		var custom = form.querySelector( 'input[name="gwnf_look[style]"][value="custom"]' );
		if ( custom && ! custom.checked ) {
			custom.checked = true;
		}
	}

	/* ---- Logo picker (Media Library) ---- */
	$( form ).on( 'click', '.gwnf-logo__pick', function ( e ) {
		e.preventDefault();
		var wrap = $( this ).closest( '.gwnf-logo' );
		var frame = wp.media( { title: cfg.choose, button: { text: cfg.use }, library: { type: 'image' }, multiple: false } );
		frame.on( 'select', function () {
			var a = frame.state().get( 'selection' ).first().toJSON();
			var src = ( a.sizes && ( a.sizes.medium || a.sizes.full ) || a ).url;
			wrap.find( 'input[type=hidden]' ).val( a.id );
			wrap.find( '.gwnf-logo__box' ).empty().append( $( '<img alt="">' ).attr( 'src', src ) );
			refresh();
		} );
		frame.open();
	} );
	$( form ).on( 'click', '.gwnf-logo__clear', function ( e ) {
		e.preventDefault();
		var wrap = $( this ).closest( '.gwnf-logo' );
		wrap.find( 'input[type=hidden]' ).val( '0' );
		wrap.find( '.gwnf-logo__box' ).empty().append( $( '<span>' ).text( cfg.nologo ) );
		refresh();
	} );

	contrast();
} )( jQuery );
