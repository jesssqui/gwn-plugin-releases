/* Order status page: copy a tracking number. */
( function () {
	var t = window.gwnfStatus || { copied: 'Copied!', copy: 'Copy', prompt: 'Tracking number' };
	document.addEventListener( 'click', function ( e ) {
		var b = e.target.closest ? e.target.closest( '.ot-copy' ) : null;
		if ( ! b ) {
			return;
		}
		var n = b.getAttribute( 'data-copy' );
		var done = function () {
			b.textContent = t.copied;
			setTimeout( function () { b.textContent = t.copy; }, 1600 );
		};
		if ( navigator.clipboard && navigator.clipboard.writeText ) {
			navigator.clipboard.writeText( n ).then( done, function () { window.prompt( t.prompt, n ); } );
		} else {
			window.prompt( t.prompt, n );
		}
	} );
} )();
