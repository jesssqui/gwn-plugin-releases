=== GWND Fulfillment – Order Tracking, Packing Slips & Photos ===
Contributors: greatwhitenorthdesign
Tags: woocommerce, order tracking, shipment tracking, packing slip, order status
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
WC requires at least: 8.0
WC tested up to: 9.9
Stable tag: 1.2.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Tracking numbers with a branded order status page, packing slips without prices, and packing photos on every order.

== Description ==

GWND Fulfillment handles what happens after an order is paid: telling the customer it shipped, giving them one place to check on it, and keeping a record of what went in the box. It doesn't buy or print shipping labels: keep using your carrier or label service for that.

**Shipment tracking**

* A "Shipment tracking" box on every order. Scan or paste the label barcode and the carrier is detected (Canada Post, UPS, Purolator, FedEx, Canpar, Chit Chats, or any other carrier with your own link).
* Save tracking and the order is marked Completed, so the customer gets the completed email with the tracking number, a Track package button and a View your order button. You can choose to leave the status alone instead.
* A private order status page for each order (works without logging in, protected by the order key) plus a lookup form where customers enter their order number and email.
* Tracking in My account, with a Track button in the orders list.
* REST API: `/wp-json/wc-tracking/v1/orders/{id}` with WooCommerce API keys.

**Make it look like your store**

* Two styles: Theme default (inherits your theme) and Clean.
* Your logo, with an optional light version for dark backgrounds, your brand and accent colours, and a live preview of your newest order while you change them.
* Use the same logo and brand colour on WooCommerce emails and packing slips if you like.
* Every customer-facing line can be reworded under Wording & emails. Leave a line empty to keep the translated default.
* Nothing customers see names this plugin.

**Packing slips**

* Print a Letter-size packing slip from any order. Slips never show prices.
* Bundles and composite products are grouped; a QR code takes the customer to their order status page.

**Packing photos**

* A "Packing photos" box on each order opens the phone camera. Photos are shrunk in the browser, stored privately (staff only) and listed on the order. Your record if a customer says something was missing.

**GWND Fulfillment Pro** (included with stores built or looked after by Great White North Design) adds more page styles and a full style builder, 4×6 and bulk packing slips, and a Pro credit on the settings screen.

== Installation ==

1. Install and activate the plugin (WooCommerce must be active).
2. Go to WooCommerce → Fulfillment. Choose what to switch on, then set your logo and colours under Look.
3. On an order, add a tracking number in the Shipment tracking box.

== Frequently Asked Questions ==

= Does it print shipping labels? =

No. Buy and print labels with your carrier or label service, then scan or paste the tracking number here.

= Where is the order status page? =

At `/order-status/` on your site (you can change the address under Workflow). Each order's own page link is in the customer's emails and My account.

= Will it match my theme? =

Theme default leaves fonts and colours to your theme. Themes can also ship their own skin (`yourtheme/gwn-order-tracking/skin.php`) or override the template (`yourtheme/gwn-order-tracking/order-status.php`).

= Is it translated? =

All text is translation-ready (text domain `gwnd-fulfillment`).

== External services ==

This plugin doesn't call any outside service by itself. Tracking links point customers to their carrier's own website (Canada Post, UPS, Purolator, FedEx, Canpar or Chit Chats) when they click Track package; nothing is sent to those sites before the customer clicks.

== Credits ==

* QR codes on packing slips are drawn in the browser by [QR Code Generator for JavaScript](https://github.com/kazuhikoarase/qrcode-generator) by Kazuhiko Arase (MIT licence), bundled as `assets/qrcode.js`. It runs locally and sends nothing anywhere.

== Screenshots ==

1. The order status page in the Clean style.
2. The Look tab with live preview.
3. Shipment tracking box on the order screen.
4. A packing slip.

== Changelog ==

= 1.2.2 =
* Changed: the admin credit (Plugins screen and the foot of the Fulfillment settings) always shows, also when GWND Fulfillment Pro is active. The menu name is fixed as "Fulfillment".
* Removed: leftover ShipStation code (an order-note label and an unused carrier-name mapper). The plugin has no ShipStation or other shipping-platform integration.
* New: Credits section for the bundled QR code library.

= 1.2.1 =
* New: plugin icon and banner; Docs & support link on the Plugins screen and a small credit at the foot of the Fulfillment settings (hidden when GWND Fulfillment Pro is active).
* Fix: on packing slips the order number in the header was grey; it's now full black.
* Tweak: admin and packing-slip CSS/JS load through WordPress's script and style queue; the Print button no longer uses an inline handler.

= 1.2.0 =
* New: Look tab with styles, logo (plus dark-background logo), colours and a live preview.
* New: Wording & emails tab: every customer-facing line can be changed.
* New: Workflow tab: order status page address, help email, carriers offered, what saving tracking does.
* New: carrier auto-detect is the default on the order screen.
* Changed: settings are now one page with tabs; assets are loaded as files.
* Changed: 4×6 and bulk slips move to GWND Fulfillment Pro. Live tracking and the ShipStation bridge are removed.

= 1.1.0 =
* Combined GWN Order Tracking and GWN Packing Slips, added packing photos.
