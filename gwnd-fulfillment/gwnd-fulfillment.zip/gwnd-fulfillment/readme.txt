=== GWND Fulfillment – Order Tracking, Packing Slips & Photos ===
Contributors: greatwhitenorthdesign
Tags: woocommerce, order tracking, shipment tracking, packing slip, order status
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
WC requires at least: 8.0
WC tested up to: 11.3
Stable tag: 1.4.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Tracking numbers with a branded order status page, packing slips without prices, and packing photos on every order.

== Description ==

GWND Fulfillment handles what happens after an order is paid: telling the customer it shipped, giving them one place to check on it, and keeping a record of what went in the box. It doesn't buy or print shipping labels: keep using your carrier or label service for that.

**Shipment tracking**

* A "Shipment tracking" box on every order. Scan or paste the label barcode and the carrier is detected.
* Works worldwide: 29 built-in carriers (UPS, FedEx and DHL everywhere; Canada Post, Purolator, Canpar, Chit Chats; USPS, OnTrac; Royal Mail, Parcelforce, Evri, DPD UK, An Post; DPD, GLS, Deutsche Post, PostNL, bpost, La Poste / Colissimo, Correos, Poste Italiane, PostNord, InPost; Australia Post, StarTrack, Aramex, Sendle, NZ Post). The order screen offers the ones for your store's country automatically, or pick your own list.
* Add your own carriers (a local courier, say) with their tracking link, and optionally send carriers without a link to 17TRACK.
* Save tracking and the order is marked Completed, so the customer gets the completed email with the tracking number, a Track package button and a View your order button. You can choose to leave the status alone instead.
* A private order status page for each order (works without logging in, protected by the order key) plus a lookup form where customers enter their order number and email.
* Tracking in My account, with a Track button in the orders list.
* REST API: `/wp-json/wc-tracking/v1/orders/{id}` with WooCommerce API keys.

**Make it look like your store**

* Two styles: Theme default (inherits your theme) and Clean.
* Your logo, with an optional light version for dark backgrounds, your brand and accent colours, and a live preview of your newest order while you change them.
* Use the same logo on packing slips if you like.
* Every customer-facing line can be reworded on the Wording tab. Leave a line empty to keep the translated default.

**Emails**

* An Emails tab with a live preview of the real WooCommerce email for your newest order, and a Send me a test button.
* Logo and colours from WooCommerce's email settings or from your Look tab, a separate tracking box and button colour, three box styles and three button shapes.
* Choose what shows (tracking number, Track package, View your order, the status line in the order received email), reword the subject, heading, first line and every label, and add your own message under the tracking (returns, a discount code). {first_name}, {order} and {site} are filled in.
* Nothing customers see names this plugin.

**Packing slips**

* Letter or A4 paper, picked from your store's country (change it on the Packing slips tab).
* Print a packing slip from any order. Slips never show prices.
* A plain, practical slip: ship-to and return address, the customer's note, a checkbox per item, SKUs, bundles kept together, quantities over 1 highlighted and an item count.

**Packing photos**

* A "Packing photos" box on each order opens the phone camera. Photos are shrunk in the browser, stored privately (staff only) and listed on the order. Your record if a customer says something was missing.

**GWND Fulfillment Pro** (included with stores built or looked after by Great White North Design) adds more page styles and a full style builder, packing slip styles, product photos, a thank-you message and a QR code on slips, and 4×6 and bulk packing slips.

== Installation ==

1. Install and activate the plugin (WooCommerce must be active).
2. Go to WooCommerce → Fulfillment. Choose what to switch on, then set your logo and colours under Look.
3. On an order, add a tracking number in the Shipment tracking box.

== Frequently Asked Questions ==

= Who can see packing photos? =

Only signed-in staff who can edit that order. Photos are kept in wp-content/uploads/gwnd-packing-photos/ with random file names and served through WordPress. Apache and LiteSpeed block direct access with the .htaccess file the plugin adds. On nginx, add this to your server block so the folder can't be reached directly:

`location ^~ /wp-content/uploads/gwnd-packing-photos/ { deny all; }`

= Does it print shipping labels? =

No. Buy and print labels with your carrier or label service, then scan or paste the tracking number here.

= Where is the order status page? =

At `/order-status/` on your site (you can change the address under Workflow). Each order's own page link is in the customer's emails and My account.

= Will it match my theme? =

Theme default leaves fonts and colours to your theme. Themes can also ship their own skin (`yourtheme/gwn-order-tracking/skin.php`) or override the template (`yourtheme/gwn-order-tracking/order-status.php`).

= Is it translated? =

All text is translation-ready (text domain `gwnd-fulfillment`).

== External services ==

This plugin doesn't call any outside service by itself. Tracking links point customers to their carrier's own website (or to 17TRACK, t.17track.net, if you switch that on for carriers without a link) when they click Track package. Nothing is sent to those sites before the customer clicks; the click sends the tracking number in the link. 17TRACK's terms (https://www.17track.net/en/terms) and privacy policy apply.

== Screenshots ==

1. The order status page in the Clean style.
2. The Look tab with live preview.
3. Shipment tracking box on the order screen.
4. A packing slip.

== Changelog ==

= 1.4.0 =
* Security: a site-wide cap on failed order-status lookups (filter gwnot_lookup_failure_cap), so a faked IP header can't be used to step through order numbers.
* Security: photos, packing slips, tracking and the tracking REST API check that the user can edit that specific order (works with vendor plugins). Photos are served with nosniff.
* New: works outside Canada: 29 built-in carriers grouped by country, offered automatically for your store's country or from your own list; number detection only picks offered carriers.
* New: add your own carriers with their tracking links, and optionally send carriers without a link to 17TRACK.
* New: Emails tab: logo and colours, tracking box and button style, what shows, wording with {first_name}/{order}/{site}, your own message, a live preview of the real WooCommerce email and Send me a test.
* New: Wording tab on its own.
* New: a short setup checklist on the Fulfillment screen.
* New: Letter or A4 packing slips, picked from your store's country.
* Tweak: shop managers can save the settings tabs.

= 1.3.1 =
* Fix: packing slips are split into pages at their real printed width, so each Letter or 4×6 page is filled properly and a long order doesn't leave half-empty pages.
* Tweak: the slip's footer line sits in the bottom strip of the last page, next to the page number, so it never needs a page of its own.

= 1.3.0 =
* Changed: the packing slip is now a plain, practical slip: ship-to and return address, customer note, checkboxes, SKUs and quantities. Product photos, the thank-you message and the QR code move to GWND Fulfillment Pro, along with new slip styles.
* Removed: the bundled QR code library.

= 1.2.3 =
* Fix: with a style chosen under Look, headings and links on the order status page use the style's colours, so a theme can't turn them white (or another colour that disappears on the page). Theme default still follows the theme.

= 1.2.2 =
* Changed: the admin credit (Plugins screen and the foot of the Fulfillment settings) always shows, also when GWND Fulfillment Pro is active. The menu name is fixed as "Fulfillment".
* Removed: leftover ShipStation code (an order-note label and an unused carrier-name mapper). The plugin has no ShipStation or other shipping-platform integration.
* New: Credits section for the bundled QR code library.

= 1.2.1 =
* New: plugin icon and banner; Docs & support link on the Plugins screen and a small credit at the foot of the Fulfillment settings (hidden when GWND Fulfillment Pro is active).
* Fix: on packing slips the order number in the header was grey; it's now full black.
* Tweak: admin and packing-slip CSS/JS load through WordPress's script and style queue; the Print button no longer uses an inline handler.

= 1.2.0 =
* New: Look tab with styles, logo (plus dark-background logo), colours and a live preview.
* New: Wording & emails tab: every customer-facing line can be changed.
* New: Workflow tab: order status page address, help email, carriers offered, what saving tracking does.
* New: carrier auto-detect is the default on the order screen.
* Changed: settings are now one page with tabs; assets are loaded as files.
* Changed: 4×6 and bulk slips move to GWND Fulfillment Pro. Live tracking and the ShipStation bridge are removed.

= 1.1.0 =
* Combined GWN Order Tracking and GWN Packing Slips, added packing photos.
