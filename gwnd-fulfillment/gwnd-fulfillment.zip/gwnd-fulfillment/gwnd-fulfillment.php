<?php
/**
 * Plugin Name:       GWND Fulfillment – Order Tracking, Packing Slips & Photos
 * Description:       Shipment tracking with a branded order status page, packing slips without prices, and packing photos on every order, for WooCommerce stores.
 * Version:           1.2.3
 * Plugin URI:        https://greatwhitenorthdesign.ca/tools/fulfillment/
 * Author:            Great White North Design
 * Author URI:        https://greatwhitenorthdesign.ca
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Requires Plugins:  woocommerce
 * WC requires at least: 8.0
 * WC tested up to:   9.9
 * Text Domain:       gwnd-fulfillment
 * Domain Path:       /languages
 *
 * Replaces the separate GWN Order Tracking and GWN Packing Slips plugins. Function names, order meta,
 * options, filters, REST routes and theme skin paths are unchanged, so a store moving over keeps its
 * settings, tracking numbers and theme styling. The old plugins are switched off automatically.
 *
 * Nothing customer-facing names the plugin or its author.
 *
 * Settings: WooCommerce → Fulfillment (tabs: General, Look, Wording, Workflow; GWND Fulfillment Pro adds
 * Carriers and Branding). Filter gwnf_modules (array 'tracking' => bool, 'slips' => bool, 'photos' => bool)
 * to force any part on or off. Extension points for add-ons: gwnf_settings_tabs, gwnf_look, gwnf_styles,
 * gwnf_look_classes, gwnot_after_steps, gwnps_formats.
 *
 * Packing photos: order screen box (phone camera or files), stored privately in uploads/gwnd-packing-photos/,
 *   shown only to staff who can edit orders. Filters: gwnf_photo_max_px, gwnf_photos_dir, gwnf_photo_can_view,
 *   gwnf_photo_can_delete. See includes/photos.php.
 *
 * Shipment tracking — theme hooks (all optional):
 *   gwnot_slug            (string)  URL base of the order status page. Default from Workflow settings ("order-status").
 *   gwnot_carriers        (array)   key => [name, url with {n} placeholder].
 *   gwnot_wrap_class      (string)  extra classes on the page wrapper.
 *   gwnot_button_class    (string, $variant 'primary'|'secondary')
 *   gwnot_help_email      (string)  "Questions?" address. Default: Wording settings, else the WooCommerce "from" address.
 *   gwnot_status_copy     (array, $order)  headline/lead for the page.
 *   gwnot_is_block_theme  (bool)    force block-theme or classic page chrome.
 *   Template override:    yourtheme/gwn-order-tracking/order-status.php
 *   Theme skin:           yourtheme/gwn-order-tracking/skin.php
 *   REST:                 /wp-json/wc-tracking/v1/orders/{id} (WooCommerce API keys)
 *
 * Packing slips — theme hooks (all optional):
 *   gwnps_defaults, gwnps_item_parent_key, gwnps_item_group_key, gwnps_item_meta, gwnps_rows, gwnps_qr_url,
 *   gwnps_help_email, gwnps_slip_classes, gwnps_head (action), gwnps_after_items (action)
 *   Template override:    yourtheme/gwn-packing-slips/slip.php
 *   Theme skin:           yourtheme/gwn-packing-slips/skin.php
 */
defined( 'ABSPATH' ) || exit;

/** The separate plugins this one replaces. */
function gwnf_legacy_plugins() {
	return array( 'gwn-order-tracking/gwn-order-tracking.php', 'gwn-packing-slips/gwn-packing-slips.php' );
}

/** Legacy plugins still switched on (they'd clash with this one, so this one waits until they're off). */
function gwnf_active_legacy() {
	$active = (array) get_option( 'active_plugins', array() );
	if ( is_multisite() ) {
		$active = array_merge( $active, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
	}
	return array_values( array_intersect( gwnf_legacy_plugins(), $active ) );
}

function gwnf_switch_off_legacy() {
	$legacy = gwnf_active_legacy();
	if ( ! $legacy ) {
		return false;
	}
	if ( ! function_exists( 'deactivate_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	deactivate_plugins( $legacy, true );
	if ( is_multisite() ) {
		deactivate_plugins( $legacy, true, true );
	}
	update_option( 'gwnf_replaced_legacy', $legacy, false );
	return true;
}

register_activation_hook( __FILE__, function () {
	gwnf_switch_off_legacy();
	delete_option( 'gwnot_rewrite' ); // tracking flushes rewrite rules on the next init
} );
register_deactivation_hook( __FILE__, function () {
	delete_option( 'gwnot_rewrite' );
	flush_rewrite_rules( false );
} );

if ( gwnf_active_legacy() || defined( 'GWNOT_VERSION' ) || defined( 'GWNPS_VERSION' ) ) {
	// The old plugins are loaded this request: stay out of their way, switch them off, and reload.
	add_action( 'admin_init', function () {
		if ( current_user_can( 'activate_plugins' ) && gwnf_switch_off_legacy() ) {
			delete_option( 'gwnot_rewrite' );
			wp_safe_redirect( add_query_arg( 'gwnf_replaced', 1, admin_url( 'plugins.php' ) ) );
			exit;
		}
	} );
	return;
}

define( 'GWNF_VERSION', '1.2.3' );
define( 'GWNF_FILE', __FILE__ );
define( 'GWNF_DIR', plugin_dir_path( __FILE__ ) );

// The modules still use their own constants; both point at this plugin.
define( 'GWNOT_VERSION', GWNF_VERSION );
define( 'GWNOT_FILE', GWNF_FILE );
define( 'GWNOT_DIR', GWNF_DIR );
define( 'GWNPS_VERSION', GWNF_VERSION );
define( 'GWNPS_FILE', GWNF_FILE );
define( 'GWNPS_DIR', GWNF_DIR );

define( 'GWNF_URL', plugin_dir_url( __FILE__ ) );
define( 'GWNF_HOME', 'https://greatwhitenorthdesign.ca/tools/fulfillment/' );

/*
 * Updates from GitHub (the GitHub build only; the WordPress.org build leaves the updater out).
 * GWND Fulfillment Pro updates this plugin itself, so this steps aside when Pro is loaded.
 */
add_action( 'plugins_loaded', function () {
	if ( defined( 'GWNFP_FILE' ) || class_exists( 'GWNFPC_Updater' ) ) {
		return;
	}
	if ( is_readable( GWNF_DIR . 'includes/class-gwnf-updater.php' ) ) {
		require_once GWNF_DIR . 'includes/class-gwnf-updater.php';
		GWNF_Updater::init( GWNF_FILE );
	}
}, 5 );

require_once GWNF_DIR . 'includes/brand.php'; // admin-only credit and docs link, admin CSS/JS helper

/** Which parts are on: option set on WooCommerce → Fulfillment, both on by default. */
function gwnf_modules() {
	$saved = get_option( 'gwnf_modules', array() );
	$saved = is_array( $saved ) ? $saved : array();
	$on    = array(
		'tracking' => 'no' !== ( $saved['tracking'] ?? 'yes' ),
		'slips'    => 'no' !== ( $saved['slips'] ?? 'yes' ),
		'photos'   => 'no' !== ( $saved['photos'] ?? 'yes' ),
	);
	return (array) apply_filters( 'gwnf_modules', $on );
}

function gwnf_on( $module ) {
	return ! empty( gwnf_modules()[ $module ] );
}

add_action( 'before_woocommerce_init', function () {
	if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', GWNF_FILE, true );
	}
} );

add_action( 'plugins_loaded', function () {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}
	if ( gwnf_on( 'tracking' ) ) {
		foreach ( array( 'detect', 'core', 'admin', 'emails', 'frontend', 'rest' ) as $f ) {
			require_once GWNF_DIR . "includes/tracking/{$f}.php";
		}
	}
	if ( gwnf_on( 'slips' ) ) {
		foreach ( array( 'core', 'admin', 'print' ) as $f ) {
			require_once GWNF_DIR . "includes/slips/{$f}.php";
		}
	}
	if ( gwnf_on( 'photos' ) ) {
		require_once GWNF_DIR . 'includes/photos.php';
	}
	require_once GWNF_DIR . 'includes/options.php'; // wording, workflow and look settings (read everywhere)
	require_once GWNF_DIR . 'includes/look.php';
	if ( is_admin() ) {
		require_once GWNF_DIR . 'includes/settings.php';
	}
	do_action( 'gwnf_loaded' ); // add-ons (GWND Fulfillment Pro) load their parts here
}, 20 );


/* Optional theme skins, one per part: {theme}/gwn-order-tracking/skin.php, {theme}/gwn-packing-slips/skin.php */
add_action( 'after_setup_theme', function () {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}
	foreach ( array( 'tracking' => 'gwn-order-tracking/skin.php', 'slips' => 'gwn-packing-slips/skin.php' ) as $m => $skin ) {
		// A theme's tracking skin is its "Theme default" look: any other style chosen under Look replaces it.
		if ( 'tracking' === $m && function_exists( 'gwnf_look' ) && 'theme' !== gwnf_look( 'style' ) && gwnf_look_on( 'status' ) ) {
			continue;
		}
		if ( gwnf_on( $m ) && ( $f = locate_template( $skin ) ) ) {
			require_once $f;
		}
	}
}, 20 );

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
	array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=gwnd-fulfillment' ) ) . '">' . esc_html__( 'Settings', 'gwnd-fulfillment' ) . '</a>' );
	return $links;
} );
