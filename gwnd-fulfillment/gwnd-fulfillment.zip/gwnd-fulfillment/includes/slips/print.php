<?php
/**
 * The print page: admin-post.php?action=gwnps_print&ids=1,2&format=letter|label (nonce gwnps_print).
 * A standalone HTML document, one slip per page, CSS inline, opens the print dialog on load.
 */
defined( 'ABSPATH' ) || exit;

add_action( 'admin_post_gwnps_print', 'gwnps_print_page' );

function gwnps_print_page() {
	if ( ! current_user_can( 'edit_shop_orders' ) ) {
		wp_die( 'You are not allowed to print packing slips.', 403 );
	}
	check_admin_referer( 'gwnps_print' );

	$format = gwnps_format( sanitize_key( wp_unslash( $_GET['format'] ?? '' ) ) );
	$ids    = array_filter( array_map( 'absint', explode( ',', sanitize_text_field( wp_unslash( $_GET['ids'] ?? '' ) ) ) ) );
	$orders = array();
	foreach ( array_unique( $ids ) as $id ) {
		$o = wc_get_order( $id );
		if ( $o instanceof WC_Order && 'shop_order_refund' !== $o->get_type() ) {
			$orders[] = $o;
		}
	}
	if ( ! $orders ) {
		wp_die( 'No orders to print.', 404 );
	}

	foreach ( $orders as $o ) {
		if ( ! $o->get_meta( '_gwnps_printed' ) && gwnps_on( 'note' ) ) {
			$o->add_order_note( 'Packing slip printed.', false, true );
		}
		$o->update_meta_data( '_gwnps_printed', time() );
		$o->update_meta_data( '_gwnps_printed_by', wp_get_current_user()->display_name );
		$o->save_meta_data();
	}

	nocache_headers();
	header( 'Content-Type: text/html; charset=utf-8' );
	header( 'X-Robots-Tag: noindex, nofollow' );

	$ids_csv  = implode( ',', array_map( function ( $o ) { return $o->get_id(); }, $orders ) );
	$other    = 'label' === $format ? 'letter' : 'label';
	$title    = 1 === count( $orders ) ? 'Packing slip #' . $orders[0]->get_order_number() : count( $orders ) . ' packing slips';
	$template = locate_template( 'gwn-packing-slips/slip.php' ) ?: GWNPS_DIR . 'templates/slip.php';
	$back     = 1 === count( $orders ) ? $orders[0]->get_edit_order_url() : admin_url( 'admin.php?page=wc-orders' );
	?>
<!doctype html>
<html lang="<?php echo esc_attr( get_bloginfo( 'language' ) ); ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?php echo esc_html( $title ); ?></title>
<?php
wp_register_style( 'gwnps-print', false, array(), GWNF_VERSION );
wp_add_inline_style( 'gwnps-print', gwnps_css( $format ) );
wp_print_styles( 'gwnps-print' );
?>
<?php do_action( 'gwnps_head', $format ); ?>
</head>
<body class="ps-doc ps-doc--<?php echo esc_attr( $format ); ?>">
<div class="ps-bar">
	<strong><?php echo esc_html( $title ); ?></strong>
	<span class="ps-bar__sp"></span>
	<?php if ( isset( gwnps_formats()[ $other ] ) ) : ?>
	<a href="<?php echo esc_url( gwnps_print_url( explode( ',', $ids_csv ), $other ) ); ?>"><?php echo 'label' === $other ? esc_html__( 'Switch to 4×6 label', 'gwnd-fulfillment' ) : esc_html__( 'Switch to Letter', 'gwnd-fulfillment' ); ?></a>
	<?php endif; ?>
	<a href="<?php echo esc_url( $back ); ?>">Back to <?php echo 1 === count( $orders ) ? 'order' : 'orders'; ?></a>
	<button type="button" class="ps-print">Print</button>
</div>
<?php
	foreach ( $orders as $order ) {
		$rows    = gwnps_rows( $order );
		$units   = gwnps_unit_count( $rows );
		$classes = apply_filters( 'gwnps_slip_classes', array( 'ps', 'ps--' . $format ), $order, $format );
		include $template;
	}
	?>
<?php ob_start(); ?>
(function(){
	document.querySelectorAll('.ps-print').forEach(function(b){b.addEventListener('click',function(){window.print();});});

	/* Split each slip into real pages: a bundle (tbody.ps-group) never splits unless it's taller than a page,
	   the item header repeats on every page, and "Order #N · Page x of y" goes at the bottom when there's more than one. */
	function paginate(ps){
		var table=ps.querySelector('.ps-items'); if(!table)return;
		var thead=table.tHead, label=ps.getAttribute('data-pn')||'', units=[];
		[].slice.call(ps.children).forEach(function(el){
			if(el===table){[].slice.call(table.tBodies).forEach(function(tb){
				if(tb.classList.contains('ps-group'))units.push({tb:tb});else[].slice.call(tb.rows).forEach(function(tr){units.push({tr:tr});});
			});}else units.push({el:el});
		});
		while(ps.firstChild)ps.removeChild(ps.firstChild);
		var pages=[],body,tbl,tb;
		function newPage(){var pg=document.createElement('div');pg.className='ps-page';body=document.createElement('div');body.className='ps-body';
			var pn=document.createElement('div');pn.className='ps-pn';pg.appendChild(body);pg.appendChild(pn);ps.appendChild(pg);pages.push(pg);tbl=null;tb=null;}
		function fits(){return body.scrollHeight<=body.clientHeight+1;}
		function ensureTable(){if(!tbl){tbl=table.cloneNode(false);if(thead)tbl.appendChild(thead.cloneNode(true));body.appendChild(tbl);}}
		function put(u){var n;
			if(u.el){n=u.el;body.appendChild(n);}
			else if(u.tb){ensureTable();n=u.tb;tbl.appendChild(n);tb=null;}
			else{ensureTable();if(!tb){tb=document.createElement('tbody');tbl.appendChild(tb);}n=u.tr;tb.appendChild(n);}
			if(fits())return true;
			n.parentNode.removeChild(n);
			if(tb&&!tb.rows.length){tb.remove();tb=null;}
			if(tbl&&!tbl.tBodies.length){tbl.remove();tbl=null;}
			return false;}
		function emptyPage(){return !body.children.length;}
		newPage();
		var foot=null;
		units.forEach(function(u){
			if(u.el&&u.el.classList&&u.el.classList.contains('ps-foot')){foot=u.el;return;} // goes in the last page's bottom strip
			if(put(u))return;
			if(!emptyPage()){newPage();if(put(u))return;}
			if(u.tb){[].slice.call(u.tb.rows).forEach(function(tr){var x={tr:tr};if(!put(x)){if(!emptyPage())newPage();if(!put(x)){ensureTable();if(!tb){tb=document.createElement('tbody');tbl.appendChild(tb);}tb.appendChild(tr);}}});return;}
			if(u.el)body.appendChild(u.el);else{ensureTable();if(!tb){tb=document.createElement('tbody');tbl.appendChild(tb);}tb.appendChild(u.tr);} // taller than a page on its own
		});
		var small=ps.classList.contains('ps--label'); // 4×6: the order number is already in each page's item header
		if(pages.length>1)pages.forEach(function(pg,i){var t=document.createElement('span');t.className='ps-pn__n';t.textContent=small?'Page '+(i+1)+'/'+pages.length:(label?label+' · ':'')+'Page '+(i+1)+' of '+pages.length;pg.lastChild.appendChild(t);});
		if(foot)pages[pages.length-1].lastChild.insertBefore(foot,pages[pages.length-1].lastChild.firstChild); // the footer line never needs a page of its own
	}

	function ready(cb){
		var imgs=[].slice.call(document.images).filter(function(i){return !i.complete;}),n=imgs.length,fired=false;
		function go(){if(fired)return;fired=true;(document.fonts&&document.fonts.ready?document.fonts.ready:Promise.resolve()).then(cb);}
		if(!n)return go();
		imgs.forEach(function(i){var d=function(){if(--n<=0)go();};i.addEventListener('load',d);i.addEventListener('error',d);});
		setTimeout(go,4000);
	}
	ready(function(){
		// Switch to the paged layout first, so pages are measured at their real width (not with the no-JS padding).
		document.body.classList.add('is-paged');
		document.querySelectorAll('.ps').forEach(function(ps){try{paginate(ps);}catch(e){document.body.classList.remove('is-paged');}});
		<?php if ( gwnps_on( 'auto_print' ) ) : ?>
		setTimeout(function(){window.print();},250);
		<?php endif; ?>
	});
})();
<?php
do_action( 'gwnps_footer', $format ); // add-ons (GWND Fulfillment Pro) print their scripts here, before pages are built
wp_register_script( 'gwnps-print', false, array(), GWNF_VERSION, false );
wp_add_inline_script( 'gwnps-print', ob_get_clean() );
wp_print_scripts( 'gwnps-print' );
?>
</body>
</html>
	<?php
	exit;
}

function gwnps_css( $format ) {
	// Printable area: Letter 8.5×11 − 0.4in margins = 7.7×10.2in; 4×6 − 0.08in margins = 3.84×5.84in.
	// Each .ps-page is built a hair shorter than that so rounding never spills onto a blank page.
	$page = 'label' === $format ? 'size: 4in 6in; margin: 0.08in;' : 'size: letter; margin: 0.4in;';
	return '@page { ' . $page . ' }' . "\n" . <<<'CSS'
:root { --ps-ink: #111; --ps-muted: #555; --ps-line: #111; --ps-soft: #f2f2f2; --ps-r: 10px; --ps-font: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; --ps-font-d: var(--ps-font); }
* { box-sizing: border-box; }
html, body { margin: 0; padding: 0; background: #e9e9ec; color: var(--ps-ink); font: 13px/1.4 var(--ps-font); -webkit-print-color-adjust: exact; print-color-adjust: exact; }
.ps-bar { position: sticky; top: 0; z-index: 5; display: flex; gap: 14px; align-items: center; padding: 10px 18px; background: #1d2327; color: #fff; font-size: 13px; }
.ps-bar__sp { flex: 1; }
.ps-bar a { color: #9ec2e6; text-decoration: none; }
.ps-bar button { background: #2271b1; color: #fff; border: 0; border-radius: 4px; padding: 7px 16px; font: inherit; font-weight: 600; cursor: pointer; }
.ps { margin: 24px auto; }
.ps--letter { width: 7.7in; }
.ps--label { width: 3.84in; font-size: 10.7px; }
body:not(.is-paged) .ps { background: #fff; padding: .3in; } /* before pages are built (or without JS) */
.ps-page { position: relative; display: flex; flex-direction: column; background: #fff; border: 2px solid var(--ps-line); border-radius: var(--ps-r); box-shadow: 0 2px 14px rgba(0,0,0,.12); margin: 0 0 24px; overflow: hidden; break-after: page; page-break-after: always; }
.ps:last-of-type .ps-page:last-child { break-after: auto; page-break-after: auto; }
.ps-body { flex: 1 1 auto; min-height: 0; overflow: hidden; }
.ps-pn { flex: 0 0 auto; height: 16px; padding-top: 3px; display: flex; gap: 10px; align-items: baseline; font: 600 10px/13px var(--ps-font); color: var(--ps-muted); letter-spacing: .02em; overflow: hidden; }
.ps-pn__n { margin-left: auto; white-space: nowrap; }
.ps-pn .ps-foot { margin: 0; padding: 0; border: 0; font-size: inherit; flex: 1 1 auto; min-width: 0; text-align: left; font-weight: 400; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.ps--letter .ps-page { height: 10.15in; padding: .35in .35in .12in; }
.ps--label .ps-page { height: 5.8in; padding: .08in .1in .03in; border-radius: 8px; }
.ps--label .ps-pn { height: 14px; padding-top: 1px; font-size: 10.7px; line-height: 13px; }

.ps-head { display: flex; justify-content: space-between; align-items: flex-start; gap: 16px; padding-bottom: 12px; border-bottom: 2px solid var(--ps-line); }
.ps-logo img { max-height: 54px; max-width: 220px; display: block; }
.ps-logo__text { font: 800 22px/1.1 var(--ps-font-d); }
.ps-head__meta { text-align: right; }
.ps-kicker { display: inline-block; font: 800 11px/1 var(--ps-font-d); text-transform: uppercase; letter-spacing: .12em; padding: 5px 9px; border: 1.5px solid var(--ps-line); border-radius: 99px; }
.ps-num { font: 800 26px/1.1 var(--ps-font-d); margin: 6px 0 2px; }
.ps-head__meta div { color: var(--ps-muted); }
.ps-head__meta .ps-num { color: var(--ps-ink); }

.ps-addr { display: grid; grid-template-columns: 1.3fr 1fr; gap: 18px; margin: 14px 0; }
.ps-box { border: 1.5px solid var(--ps-line); border-radius: var(--ps-r); padding: 12px 14px; }
.ps-box__t { font: 800 10px/1 var(--ps-font-d); text-transform: uppercase; letter-spacing: .12em; color: var(--ps-muted); margin: 0 0 7px; }
.ps-to { font-size: 15px; line-height: 1.35; }
.ps-to::first-line { font-weight: 800; }
.ps-contact { margin-top: 6px; color: var(--ps-muted); font-size: 12px; }
.ps-from { color: var(--ps-muted); font-size: 12px; }
.ps-ship { margin-top: 10px; font-weight: 700; }

.ps-note { background: var(--ps-soft); border-radius: var(--ps-r); padding: 8px 14px; margin: 0 0 12px; }
.ps-note strong { display: block; font-size: 10px; text-transform: uppercase; letter-spacing: .12em; color: var(--ps-muted); margin-bottom: 3px; }

.ps-items { width: 100%; border-collapse: collapse; }
.ps-items th { text-align: left; font: 800 10px/1 var(--ps-font-d); text-transform: uppercase; letter-spacing: .12em; color: var(--ps-muted); padding: 0 8px 8px; border-bottom: 2px solid var(--ps-line); }
.ps-items td { padding: 6px 8px; border-bottom: 1px solid #d6d6d6; vertical-align: middle; }
.ps-items tr { page-break-inside: avoid; break-inside: avoid; }
.ps-items thead { display: table-header-group; } /* repeats on every printed page */
.ps-items tbody.ps-group { break-inside: avoid; page-break-inside: avoid; } /* keep a bundle and its items on one page */
.ps-th-order { font-weight: 600; letter-spacing: .06em; }
.ps-items .c-chk { width: 26px; padding-right: 0; }
.ps-items .c-img { width: 52px; }
.ps-items .c-qty { width: 60px; text-align: center; }
.ps-chk { display: inline-block; width: 16px; height: 16px; border: 1.5px solid var(--ps-line); border-radius: 4px; }
.ps-img { width: 36px; height: 36px; object-fit: cover; border-radius: 8px; border: 1px solid #ddd; display: block; }
.ps-name { font-weight: 700; font-size: 14px; }
.ps-meta { color: var(--ps-muted); font-size: 11.5px; margin-top: 2px; }
.ps-sku { color: var(--ps-muted); font-size: 11px; font-family: ui-monospace, Menlo, Consolas, monospace; }
.ps-qty { display: inline-block; min-width: 34px; padding: 4px 8px; border: 1.5px solid var(--ps-line); border-radius: 8px; font: 800 15px/1 var(--ps-font-d); text-align: center; }
.ps-qty.is-multi { background: var(--ps-ink); color: #fff; }
.ps-items tr.is-parent td { border-bottom: 0; padding-bottom: 4px; }
.ps-items tr.is-parent .ps-name::after { content: " — bundle"; font-weight: 400; color: var(--ps-muted); }
.ps-items tr.is-child td { padding-top: 3px; padding-bottom: 3px; border-bottom: 0; }
.ps-items tr.is-child .ps-name { font-weight: 600; font-size: 13px; }
.ps-items tr.is-child .ps-name::before { content: "↳ "; color: var(--ps-muted); }
.ps-items tr.is-child .ps-img { width: 28px; height: 28px; margin-left: 8px; }
.ps-items tr.is-last-child td { border-bottom: 1px solid #d6d6d6; padding-bottom: 6px; }
.ps-items .ps-qty.is-bundle { border-style: dashed; }
.ps-count { text-align: right; padding: 8px 8px 0; font-weight: 700; }

.ps-foot { text-align: center; color: var(--ps-muted); font-size: 11px; margin-top: 12px; }

/* 4×6 label: compact, no photos, no return address */
.ps--label .ps-head { padding-bottom: 5px; gap: 8px; }
.ps--label .ps-logo img { max-height: 30px; max-width: 120px; }
.ps--label .ps-logo__text { font-size: 15px; }
.ps--label .ps-kicker { font-size: 10.7px; padding: 3px 6px; }
.ps--label .ps-num { font-size: 19px; margin: 3px 0 0; }
.ps--label .ps-head__meta div { font-size: 10.7px; }
.ps--label .ps-addr { display: block; margin: 6px 0; }
.ps--label .ps-box { padding: 7px 9px; border-radius: 7px; }
.ps--label .ps-to { font-size: 11.5px; }
.ps--label .ps-contact, .ps--label .ps-ship { font-size: 10.7px; margin-top: 3px; }
.ps--label .ps-from, .ps--label .c-img { display: none; }
.ps--label .ps-note { padding: 5px 9px; margin-bottom: 6px; font-size: 10.7px; }
.ps--label .ps-items th { font-size: 10.7px; padding: 0 4px 5px; }
.ps--label .ps-items td, .ps--label .ps-items tr.is-child td { padding: 3px 4px; }
.ps--label .ps-items tr.is-last-child td { padding-bottom: 5px; }
.ps--label .ps-items .c-chk { width: 16px; }
.ps--label .ps-items .c-qty { width: 38px; }
.ps--label .ps-chk { width: 11px; height: 11px; border-radius: 3px; }
.ps--label .ps-name { font-size: 11px; }
.ps--label .ps-items tr.is-child .ps-name { font-size: 10.7px; }
.ps--label .ps-meta, .ps--label .ps-sku { font-size: 10.7px; }
.ps--label .ps-qty { font-size: 11px; padding: 3px 5px; min-width: 24px; border-radius: 6px; }
.ps--label .ps-count { font-size: 10.7px; padding-top: 4px; }
.ps--label .ps-foot { font-size: 10.7px; margin-top: 4px; }

@media print {
	html, body { background: #fff; }
	.ps-bar { display: none; }
	.ps { margin: 0; }
	.ps-page { margin: 0; box-shadow: none; }
}
CSS;
}
