<?php
/**
 * Admin: "Packing slip" box on the order screen, bulk actions + a row button in the orders list,
 * and the settings page (WooCommerce → Packing slips).
 */
defined( 'ABSPATH' ) || exit;

function gwnps_order_screen() {
	if ( class_exists( \Automattic\WooCommerce\Utilities\OrderUtil::class ) && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ) {
		return wc_get_page_screen_id( 'shop-order' );
	}
	return 'shop_order';
}

/* ---------- Order screen box ---------- */
add_action( 'add_meta_boxes', function () {
	add_meta_box( 'gwnps-slip', __( 'Packing slip', 'gwnd-fulfillment' ), 'gwnps_meta_box', gwnps_order_screen(), 'side', 'high' );
} );

function gwnps_meta_box( $obj ) {
	$order = $obj instanceof WP_Post ? wc_get_order( $obj->ID ) : $obj;
	if ( ! $order instanceof WC_Order ) {
		return;
	}
	$printed = (int) $order->get_meta( '_gwnps_printed' );
	$by      = (string) $order->get_meta( '_gwnps_printed_by' );
	$alt = array();
	echo '<div class="gwnps-box">';
	echo '<p><a class="button button-primary" style="width:100%;text-align:center" target="_blank" rel="noopener" href="' . esc_url( gwnps_print_url( $order->get_id(), gwnps_sheet() ) ) . '">' . esc_html__( 'Print packing slip', 'gwnd-fulfillment' ) . '</a></p>';
	foreach ( gwnps_formats() as $f => $label ) {
		if ( gwnps_sheet() === $f ) {
			continue;
		}
		if ( gwnps_is_sheet( $f ) ) {
			$alt = array( $f, $label ); // the other full-page paper: offered as a small link under the box
			continue;
		}
		/* translators: %s: paper size */
		echo '<p><a class="button" style="width:100%;text-align:center" target="_blank" rel="noopener" href="' . esc_url( gwnps_print_url( $order->get_id(), $f ) ) . '">' . esc_html( sprintf( __( 'Print on %s', 'gwnd-fulfillment' ), $label ) ) . '</a></p>';
	}
	echo '<p style="color:#646970;font-size:12px;margin:0">';
	if ( $printed ) {
		/* translators: 1: date and time, 2: person */
		echo esc_html( $by ? sprintf( __( 'Printed %1$s by %2$s', 'gwnd-fulfillment' ), wp_date( get_option( 'date_format' ) . ' g:ia', $printed ), $by ) : sprintf( __( 'Printed %s', 'gwnd-fulfillment' ), wp_date( get_option( 'date_format' ) . ' g:ia', $printed ) ) );
	} else {
		esc_html_e( 'Not printed yet', 'gwnd-fulfillment' );
	}
	if ( ! empty( $alt ) ) {
		/* translators: %s: paper size, e.g. "A4 (210×297 mm)" */
		echo ' · <a target="_blank" rel="noopener" href="' . esc_url( gwnps_print_url( $order->get_id(), $alt[0] ) ) . '">' . esc_html( sprintf( __( 'Print on %s', 'gwnd-fulfillment' ), strtok( $alt[1], ' ' ) ) ) . '</a>';
	}
	echo '</p></div>';
}

/* ---------- Orders list: per-row button (Actions column) ---------- */
add_filter( 'woocommerce_admin_order_actions', function ( $actions, $order ) {
	$actions['gwnps'] = array(
		'url'    => gwnps_print_url( $order->get_id() ),
		'name'   => __( 'Packing slip', 'gwnd-fulfillment' ),
		'action' => 'gwnps',
	);
	return $actions;
}, 20, 2 );

/* Open slips in a new tab (bulk + row button) and give the row button an icon. */
add_action( 'admin_footer', function () {
	$s = get_current_screen();
	if ( ! $s || ! in_array( $s->id, array( 'woocommerce_page_wc-orders', 'edit-shop_order' ), true ) ) {
		return;
	}
	?>
	<?php ob_start(); ?>
	.wc-action-button-gwnps::after{font-family:dashicons!important;content:"\f497"!important}
	tr .gwnps-printed{display:inline-block;margin-left:6px;color:#757575;font-size:11px}
	<?php gwnf_admin_inline( 'css', ob_get_clean() ); ?>
	<?php ob_start(); ?>
	(function(){
		document.querySelectorAll('a.wc-action-button-gwnps').forEach(function(a){a.target='_blank';a.rel='noopener';});
		document.querySelectorAll('#wc-orders-filter, #posts-filter').forEach(function(f){
			f.addEventListener('submit',function(){
				var a=f.querySelector('[name=action]'),b=f.querySelector('[name=action2]');
				var v=(a&&a.value!=='-1'?a.value:'')||(b?b.value:'');
				if(v.indexOf('gwnps_')===0){f.target='_blank';setTimeout(function(){f.target='';},500);}
			});
		});
	})();
	<?php gwnf_admin_inline( 'js', ob_get_clean(), array( 'jquery' ) ); ?>
	<?php
} );

/* ---------- Settings page ---------- */
/* Packing slip settings live on WooCommerce → Fulfillment → Packing slips. The old page address still works. */
add_filter( 'gwnf_settings_tabs', function ( $tabs ) {
	$out = array();
	foreach ( $tabs as $k => $v ) {
		$out[ $k ] = $v;
		if ( 'flow' === $k ) {
			$out['slips'] = __( 'Packing slips', 'gwnd-fulfillment' );
		}
	}
	return $out;
} );
add_action( 'gwnf_settings_tab_slips', function () {
	$GLOBALS['gwnps_in_tab'] = true;
	gwnps_settings_page();
} );
add_action( 'admin_menu', function () {
	add_submenu_page( '', __( 'Packing slips', 'gwnd-fulfillment' ), '', 'manage_woocommerce', 'gwn-packing-slips', function () {
		wp_safe_redirect( admin_url( 'admin.php?page=gwnd-fulfillment&tab=slips' ) );
		exit;
	} );
}, 60 );
add_action( 'admin_init', function () {
	if ( isset( $_GET['page'] ) && 'gwn-packing-slips' === $_GET['page'] && current_user_can( 'manage_woocommerce' ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		wp_safe_redirect( admin_url( 'admin.php?page=gwnd-fulfillment&tab=slips' ) );
		exit;
	}
} );

add_action( 'admin_init', function () {
	register_setting( 'gwnps', 'gwnps_settings', array(
		'type'              => 'array',
		'sanitize_callback' => 'gwnps_sanitize',
		'default'           => array(),
	) );
} );

function gwnps_fields() {
	return (array) apply_filters( 'gwnps_fields', array(
		'logo'         => array( __( 'Logo', 'gwnd-fulfillment' ), 'url', __( 'Image URL. Leave blank to use the logo from WooCommerce → Settings → Emails (or the store name as text).', 'gwnd-fulfillment' ) ),
		'store_name'   => array( __( 'Store name', 'gwnd-fulfillment' ), 'text', __( 'Leave blank to use the site title.', 'gwnd-fulfillment' ) ),
		'show_from'    => array( __( 'Return address', 'gwnd-fulfillment' ), 'check', __( 'Show the store address (WooCommerce → Settings → General) on full-page (Letter or A4) slips.', 'gwnd-fulfillment' ) ),
		'format'       => array( __( 'Default paper', 'gwnd-fulfillment' ), 'select', __( 'Used by the orders-list row button.', 'gwnd-fulfillment' ), gwnps_formats() ),
		'show_sku'     => array( __( 'SKU', 'gwnd-fulfillment' ), 'check', __( 'Show each item\'s SKU.', 'gwnd-fulfillment' ) ),
		'footer'       => array( __( 'Footer line', 'gwnd-fulfillment' ), 'text', __( 'Small print at the bottom, e.g. your website and email. Leave blank for site address · contact email.', 'gwnd-fulfillment' ) ),
		'note'         => array( __( 'Order note', 'gwnd-fulfillment' ), 'check', __( 'Add "Packing slip printed" to the order notes the first time it\'s printed.', 'gwnd-fulfillment' ) ),
		'auto_print'   => array( __( 'Open print dialog', 'gwnd-fulfillment' ), 'check', __( 'Open the print dialog as soon as the slip loads.', 'gwnd-fulfillment' ) ),
	) ); // GWND Fulfillment Pro adds slip style, product photos, a thank-you message and a QR code
}

function gwnps_sanitize( $in ) {
	$in  = is_array( $in ) ? $in : array();
	$out = array();
	foreach ( gwnps_fields() as $k => $f ) {
		$v = $in[ $k ] ?? '';
		switch ( $f[1] ) {
			case 'check':
				$out[ $k ] = empty( $v ) ? 'no' : 'yes';
				break;
			case 'url':
				$out[ $k ] = esc_url_raw( trim( (string) $v ) );
				break;
			case 'link':
				$v = trim( (string) $v );
				if ( '' !== $v && ! preg_match( '#^https?://#i', $v ) && 0 !== strpos( $v, '{' ) ) {
					$v = 'https://' . $v; // "instagram.com/yourstore" → https://…
				}
				$out[ $k ] = sanitize_text_field( preg_replace( '/\s+/', '', $v ) ); // keeps {placeholders}
				break;
			case 'textarea':
				$out[ $k ] = sanitize_textarea_field( (string) $v );
				break;
			case 'select':
				$out[ $k ] = isset( $f[3][ $v ] ) ? $v : key( $f[3] );
				break;
			default:
				$out[ $k ] = sanitize_text_field( (string) $v );
		}
	}
	// Keep settings that belong to fields not shown right now (e.g. Pro's, while Pro is switched off).
	$saved = get_option( 'gwnps_settings', array() );
	return $out + ( is_array( $saved ) ? $saved : array() );
}

function gwnps_settings_page() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	wp_enqueue_media();
	$sample = wc_get_orders( array( 'limit' => 1, 'return' => 'ids', 'type' => 'shop_order' ) );
	echo empty( $GLOBALS['gwnps_in_tab'] ) ? '<div class="wrap"><h1>' . esc_html__( 'Packing slips', 'gwnd-fulfillment' ) . '</h1>' : '<div class="gwnps-tab">';
	echo '<p>Print from an order (the <strong>Packing slip</strong> box), the printer button in the orders list, or tick several orders and choose <strong>Print packing slips</strong> from Bulk actions. Slips never show prices.</p>';
	if ( $sample ) {
		echo '<p><a class="button" target="_blank" rel="noopener" href="' . esc_url( gwnps_print_url( $sample[0], gwnps_sheet() ) ) . '">Preview with latest order</a> ';
		echo ( isset( gwnps_formats()['label'] ) ? '<a class="button" target="_blank" rel="noopener" href="' . esc_url( gwnps_print_url( $sample[0], 'label' ) ) . '">Preview 4×6</a>' : '' ) . '</p>';
	}
	echo '<form method="post" action="options.php">';
	settings_fields( 'gwnps' );
	echo '<table class="form-table" role="presentation">';
	foreach ( gwnps_fields() as $k => $f ) {
		$name = 'gwnps_settings[' . $k . ']';
		$val  = gwnps_opt( $k );
		echo '<tr><th scope="row"><label for="gwnps-' . esc_attr( $k ) . '">' . esc_html( $f[0] ) . '</label></th><td>';
		switch ( $f[1] ) {
			case 'check':
				echo '<label><input type="checkbox" id="gwnps-' . esc_attr( $k ) . '" name="' . esc_attr( $name ) . '" value="yes"' . checked( $val, 'yes', false ) . '> ' . esc_html( $f[2] ) . '</label>';
				break;
			case 'textarea':
				echo '<textarea class="large-text" rows="3" id="gwnps-' . esc_attr( $k ) . '" name="' . esc_attr( $name ) . '">' . esc_textarea( $val ) . '</textarea>';
				break;
			case 'select':
				echo '<select id="gwnps-' . esc_attr( $k ) . '" name="' . esc_attr( $name ) . '">';
				foreach ( $f[3] as $ok => $ol ) {
					echo '<option value="' . esc_attr( $ok ) . '"' . selected( $val, $ok, false ) . '>' . esc_html( $ol ) . '</option>';
				}
				echo '</select>';
				break;
			case 'url':
				echo '<input type="url" class="regular-text" id="gwnps-' . esc_attr( $k ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '"> <button type="button" class="button gwnps-media">' . esc_html__( 'Choose image', 'gwnd-fulfillment' ) . '</button>';
				break;
			case 'link':
				echo '<input type="text" class="large-text code" placeholder="https://" id="gwnps-' . esc_attr( $k ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '">';
				break;
			default:
				echo '<input type="text" class="regular-text" id="gwnps-' . esc_attr( $k ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '">';
		}
		if ( $f[2] && 'check' !== $f[1] ) {
			echo '<p class="description">' . esc_html( $f[2] ) . '</p>';
		}
		echo '</td></tr>';
	}
	echo '</table>';
	submit_button();
	echo '</form></div>';
	?>
	<?php ob_start(); ?>
	jQuery(function($){$('.gwnps-media').on('click',function(e){e.preventDefault();var i=$(this).prev('input'),f=wp.media({title:<?php echo wp_json_encode( __( 'Packing slip logo', 'gwnd-fulfillment' ) ); ?>,multiple:false,library:{type:'image'}});
	f.on('select',function(){i.val(f.state().get('selection').first().toJSON().url);});f.open();});});
	jQuery(function($){var t=$('#gwnps-qr_target'),r=$('#gwnps-qr_link').closest('tr');if(!t.length)return;function s(){r.toggle(t.val()==='custom');}t.on('change',s);s();});
	<?php gwnf_admin_inline( 'js', ob_get_clean(), array( 'jquery' ) ); ?>
	<?php
}
