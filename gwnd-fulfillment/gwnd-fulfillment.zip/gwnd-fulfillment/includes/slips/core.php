<?php
/**
 * Core: settings, print URLs, and turning an order into packing rows.
 */
defined( 'ABSPATH' ) || exit;

function gwnps_defaults() {
	return apply_filters( 'gwnps_defaults', array(
		'logo'         => '',          // image URL; blank = WooCommerce email header image, then the store name as text
		'store_name'   => '',          // blank = site title
		'show_from'    => 'yes',       // return address (WooCommerce store address) on Letter slips
		'format'       => 'letter',    // default paper: letter | label (4×6)
		'show_images'  => 'yes',       // product thumbnails (Letter only)
		'show_sku'     => 'yes',
		'thanks_title' => 'Thanks for your order!',
		'thanks_text'  => 'We hope you love everything in here. If anything isn\'t right, just get in touch and we\'ll sort it out.',
		'show_qr'      => 'yes',
		'qr_label'     => 'Scan to see your order',
		'qr_target'    => 'order',     // order = the customer's own order page | custom = qr_link below
		'qr_link'      => '',          // custom QR link; {order_id} {order_number} {order_key} {status_url} are filled in per order
		'footer'       => '',          // small line at the very bottom (e.g. website · email)
		'note'         => 'yes',       // add an order note the first time a slip is printed
		'auto_print'   => 'yes',       // open the print dialog as soon as the page loads
	) );
}

function gwnps_opt( $key ) {
	$saved = get_option( 'gwnps_settings', array() );
	$all   = wp_parse_args( is_array( $saved ) ? $saved : array(), gwnps_defaults() );
	return $all[ $key ] ?? '';
}

function gwnps_on( $key ) {
	return 'yes' === gwnps_opt( $key );
}

/** Paper sizes: id => label. GWND Fulfillment Pro adds the 4×6 label. */
function gwnps_formats() {
	return (array) apply_filters( 'gwnps_formats', array( 'letter' => __( 'Letter (8.5×11)', 'gwnd-fulfillment' ) ) );
}

function gwnps_format( $f = '' ) {
	$f = $f ?: gwnps_opt( 'format' );
	return isset( gwnps_formats()[ $f ] ) ? $f : 'letter';
}

/** Admin URL that prints the given orders. */
function gwnps_print_url( $ids, $format = '' ) {
	$ids = array_filter( array_map( 'absint', (array) $ids ) );
	return add_query_arg( array(
		'action'   => 'gwnps_print',
		'ids'      => implode( ',', $ids ),
		'format'   => gwnps_format( $format ),
		'_wpnonce' => wp_create_nonce( 'gwnps_print' ),
	), admin_url( 'admin-post.php' ) );
}

function gwnps_store_name() {
	return gwnps_opt( 'store_name' ) ?: get_bloginfo( 'name' );
}

function gwnps_logo() {
	$logo = gwnps_opt( 'logo' );
	if ( ! $logo ) {
		$id   = absint( apply_filters( 'gwnps_logo_id', 0 ) ); // the store logo from Fulfillment → Look
		$logo = $id ? (string) wp_get_attachment_image_url( $id, 'medium' ) : '';
	}
	if ( ! $logo ) {
		$logo = get_option( 'woocommerce_email_header_image', '' );
	}
	return $logo;
}

function gwnps_help_email() {
	return apply_filters( 'gwnps_help_email', get_option( 'woocommerce_email_from_address', get_option( 'admin_email' ) ) );
}

/** The store's own address (WooCommerce → Settings → General), one line per part. */
function gwnps_store_address() {
	$c = WC()->countries;
	return WC()->countries->get_formatted_address( array(
		'company'   => gwnps_store_name(),
		'address_1' => $c->get_base_address(),
		'address_2' => $c->get_base_address_2(),
		'city'      => $c->get_base_city(),
		'state'     => $c->get_base_state(),
		'postcode'  => $c->get_base_postcode(),
		'country'   => $c->get_base_country(),
	) );
}

function gwnps_ship_address( WC_Order $order ) {
	$a = $order->get_formatted_shipping_address();
	return $a ?: $order->get_formatted_billing_address();
}

/** The customer's own order page: order status page (shipment tracking), else My Account → order, else the shop. */
function gwnps_order_page_url( WC_Order $order ) {
	$url = function_exists( 'gwnot_status_url' ) ? gwnot_status_url( $order ) : '';
	if ( ! $url ) {
		$url = $order->get_customer_id() ? $order->get_view_order_url() : home_url( '/' );
	}
	return $url;
}

function gwnps_qr_url( WC_Order $order ) {
	$url  = gwnps_order_page_url( $order );
	$link = trim( (string) gwnps_opt( 'qr_link' ) );
	if ( 'custom' === gwnps_opt( 'qr_target' ) && '' !== $link ) {
		$url = strtr( $link, array(
			'{order_id}'     => rawurlencode( (string) $order->get_id() ),
			'{order_number}' => rawurlencode( (string) $order->get_order_number() ),
			'{order_key}'    => rawurlencode( (string) $order->get_order_key() ),
			'{status_url}'   => rawurlencode( $url ),
		) );
	}
	return apply_filters( 'gwnps_qr_url', $url, $order );
}

function gwnps_item_image( WC_Order_Item_Product $item ) {
	$p  = $item->get_product();
	$id = $p ? $p->get_image_id() : 0;
	if ( ! $id && $p && $p->get_parent_id() ) {
		$id = get_post_thumbnail_id( $p->get_parent_id() );
	}
	return $id ? wp_get_attachment_image_url( $id, 'thumbnail' ) : '';
}

/**
 * Order → rows to pack. Prices are never included.
 * Each row: [ name, sku, qty, image, meta => [label => value], children => [rows] ].
 */
function gwnps_rows( WC_Order $order ) {
	$rows  = array();
	$index = array(); // group key => row index
	$kids  = array(); // parent key => child rows (in order)

	foreach ( $order->get_items( 'line_item' ) as $item_id => $item ) {
		if ( ! $item instanceof WC_Order_Item_Product ) {
			continue;
		}
		$qty = (int) $item->get_quantity() + (int) $order->get_qty_refunded_for_item( $item_id ); // refunded qty is negative
		if ( $qty <= 0 ) {
			continue;
		}
		$product = $item->get_product();
		$parent  = (string) apply_filters( 'gwnps_item_parent_key', (string) $item->get_meta( '_bundled_by' ), $item );
		$group   = (string) apply_filters( 'gwnps_item_group_key', (string) $item->get_meta( '_bundle_cart_key' ), $item );

		$row = array(
			'id'       => $item_id,
			'name'     => $item->get_name() ?: ( $product ? $product->get_name() : 'Item #' . $item_id ),
			'sku'      => $product ? $product->get_sku() : '',
			'qty'      => $qty,
			'image'    => gwnps_item_image( $item ),
			'meta'     => array(),
			'children' => array(),
			'_group'   => $group,
			'_item'    => $item,
		);

		if ( $parent ) {
			$kids[ $parent ][] = $row;
		} else {
			$rows[] = $row;
			if ( $group ) {
				$index[ $group ] = count( $rows ) - 1;
			}
		}
	}

	foreach ( $kids as $key => $list ) {
		if ( isset( $index[ $key ] ) ) {
			$rows[ $index[ $key ] ]['children'] = $list;
		} else {
			foreach ( $list as $r ) { // orphaned child (parent refunded/removed): still has to be packed
				$rows[] = $r;
			}
		}
	}

	foreach ( $rows as &$r ) {
		$r['meta'] = gwnps_item_meta( $r['_item'], ! empty( $r['children'] ) );
		foreach ( $r['children'] as &$c ) {
			$c['meta'] = gwnps_item_meta( $c['_item'], false );
			unset( $c['_item'], $c['_group'] );
		}
		unset( $c, $r['_item'], $r['_group'] );
	}
	unset( $r );

	return apply_filters( 'gwnps_rows', $rows, $order );
}

function gwnps_item_meta( WC_Order_Item_Product $item, $has_children ) {
	$out = array();
	$name = wp_strip_all_tags( $item->get_name() );
	foreach ( $item->get_all_formatted_meta_data( '_' ) as $m ) {
		$v = trim( wp_strip_all_tags( $m->display_value ) );
		if ( '' === $v || false !== stripos( $name, $v ) ) { // already in the name (e.g. "… - Single Tin")
			continue;
		}
		$out[ wp_strip_all_tags( $m->display_key ) ] = $v;
	}
	return apply_filters( 'gwnps_item_meta', $out, $item, $has_children );
}

/** Total number of things that go in the box (children count instead of their bundle). */
function gwnps_unit_count( array $rows ) {
	$n = 0;
	foreach ( $rows as $r ) {
		if ( $r['children'] ) {
			foreach ( $r['children'] as $c ) {
				$n += (int) $c['qty'];
			}
		} else {
			$n += (int) $r['qty'];
		}
	}
	return $n;
}

function gwnps_shipping_method( WC_Order $order ) {
	return $order->get_shipping_method();
}
