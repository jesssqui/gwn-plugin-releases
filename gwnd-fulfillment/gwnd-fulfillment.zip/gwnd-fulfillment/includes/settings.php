<?php
/**
 * WooCommerce → Fulfillment: one settings page with tabs.
 *   General  — switch tracking / packing slips / packing photos on or off
 *   Look     — style, logo, colours, where the look is used (with a live preview)
 *   Wording  — every customer-facing line
 *   Workflow — order status page address, help email, carriers offered, what saving tracking does
 * Add-ons add tabs with the gwnf_settings_tabs filter and render them on gwnf_settings_tab_{id}.
 */
defined( 'ABSPATH' ) || exit;

function gwnf_settings_tabs() {
	$tabs = array(
		'general' => __( 'General', 'gwnd-fulfillment' ),
		'look'    => __( 'Look', 'gwnd-fulfillment' ),
		'wording' => __( 'Wording & emails', 'gwnd-fulfillment' ),
		'flow'    => __( 'Workflow', 'gwnd-fulfillment' ),
	);
	return apply_filters( 'gwnf_settings_tabs', $tabs );
}

function gwnf_settings_url( $tab = 'general' ) {
	return admin_url( 'admin.php?page=gwnd-fulfillment&tab=' . rawurlencode( $tab ) );
}

add_action( 'admin_menu', function () {
	$title = (string) apply_filters( 'gwnf_menu_title', __( 'Fulfillment', 'gwnd-fulfillment' ) );
	add_submenu_page( 'woocommerce', $title, $title, 'manage_woocommerce', 'gwnd-fulfillment', 'gwnf_settings_page' );
}, 59 );

/* ---------------- Saving ---------------- */

add_action( 'admin_init', function () {
	register_setting( 'gwnf_general', 'gwnf_modules', array(
		'type'              => 'array',
		'default'           => array(),
		'sanitize_callback' => function ( $in ) {
			$in = is_array( $in ) ? $in : array();
			return array(
				'tracking' => empty( $in['tracking'] ) ? 'no' : 'yes',
				'slips'    => empty( $in['slips'] ) ? 'no' : 'yes',
				'photos'   => empty( $in['photos'] ) ? 'no' : 'yes',
			);
		},
	) );
	register_setting( 'gwnf_look', 'gwnf_look', array( 'type' => 'array', 'default' => array(), 'sanitize_callback' => 'gwnf_sanitize_look' ) );
	register_setting( 'gwnf_wording', 'gwnf_words', array( 'type' => 'array', 'default' => array(), 'sanitize_callback' => 'gwnf_sanitize_words' ) );
	register_setting( 'gwnf_flow', 'gwnf_flow', array( 'type' => 'array', 'default' => array(), 'sanitize_callback' => 'gwnf_sanitize_flow' ) );
} );

function gwnf_sanitize_words( $in ) {
	$in  = is_array( $in ) ? $in : array();
	$out = array();
	foreach ( gwnf_words_schema() as $k => $row ) {
		if ( ! isset( $in[ $k ] ) ) {
			continue;
		}
		$v = trim( sanitize_textarea_field( wp_unslash( (string) $in[ $k ] ) ) );
		if ( '' !== $v && $v !== $row[2] ) {
			$out[ $k ] = $v; // only the lines the store changed: defaults stay translatable
		}
	}
	return $out;
}

function gwnf_sanitize_flow( $in ) {
	$in    = is_array( $in ) ? $in : array();
	$saved = get_option( 'gwnf_flow', array() );
	$out   = is_array( $saved ) ? $saved : array();
	foreach ( gwnf_flow_defaults() as $k => $d ) {
		if ( ! array_key_exists( $k, $in ) ) {
			continue;
		}
		$v = $in[ $k ];
		if ( 'slug' === $k ) {
			$out[ $k ] = sanitize_title( wp_unslash( (string) $v ) ) ?: 'order-status';
		} elseif ( 'help_email' === $k ) {
			$out[ $k ] = sanitize_email( wp_unslash( (string) $v ) );
		} elseif ( 'carriers' === $k ) {
			$picked    = array_values( array_intersect( array_map( 'sanitize_key', (array) $v ), array_keys( gwnot_carriers() ) ) );
			$all       = array_diff( array_keys( gwnot_carriers() ), array( 'other' ) );
			$out[ $k ] = count( array_diff( $all, $picked ) ) ? $picked : array(); // all ticked = no restriction
		} elseif ( is_array( $d ) ) {
			$out[ $k ] = array_map( 'sanitize_text_field', (array) wp_unslash( $v ) );
		} elseif ( in_array( $d, array( 'yes', 'no' ), true ) ) {
			$out[ $k ] = gwnf_yn( $v );
		} else {
			$out[ $k ] = sanitize_text_field( wp_unslash( (string) $v ) );
		}
	}
	return apply_filters( 'gwnf_sanitize_flow', $out, $in );
}

/* Tracking on/off or a new page address changes the order status URLs: rebuild rewrite rules. */
foreach ( array( 'update_option_gwnf_modules', 'update_option_gwnf_flow' ) as $gwnf_hook ) {
	add_action( $gwnf_hook, function () {
		delete_option( 'gwnot_rewrite' );
	} );
}
unset( $gwnf_hook );

add_action( 'admin_notices', function () {
	if ( empty( $_GET['gwnf_replaced'] ) || ! current_user_can( 'activate_plugins' ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'GWND Fulfillment now handles shipment tracking and packing slips, so the separate GWN Order Tracking and GWN Packing Slips plugins were switched off. Your settings and tracking numbers carry over, and you can delete the old plugins.', 'gwnd-fulfillment' ) . '</p></div>';
} );

/* ---------------- Assets for the settings page ---------------- */

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( 'woocommerce_page_gwnd-fulfillment' !== $hook ) {
		return;
	}
	wp_enqueue_style( 'wp-color-picker' );
	wp_enqueue_media();
	wp_enqueue_style( 'gwnf-admin', GWNF_URL . 'assets/css/admin.css', array(), GWNF_VERSION );
	wp_enqueue_script( 'gwnf-admin', GWNF_URL . 'assets/js/admin-look.js', array( 'jquery', 'wp-color-picker' ), GWNF_VERSION, true );
	wp_localize_script( 'gwnf-admin', 'gwnfAdmin', array(
		'styles'   => array_map( function ( $s ) { return $s['values']; }, gwnf_styles() ),
		'choose'   => __( 'Choose logo', 'gwnd-fulfillment' ),
		'use'      => __( 'Use this logo', 'gwnd-fulfillment' ),
		'nologo'   => __( 'No logo', 'gwnd-fulfillment' ),
		'preview'  => gwnf_preview_base_url(),
		/* translators: %s: list of colour pairs with their contrast ratios */
		'lowText'  => __( 'Low contrast: %s. Aim for at least 4.5:1 so text is easy to read.', 'gwnd-fulfillment' ),
		'okText'   => __( 'Contrast OK: text on these colours is easy to read.', 'gwnd-fulfillment' ),
		'pairs'    => apply_filters( 'gwnf_contrast_pairs', array( array( 'brand', 'on_brand', __( 'Button text on brand', 'gwnd-fulfillment' ) ) ) ),
	) );
} );

/* ---------------- Live preview: the newest order's status page with unsaved Look values ---------------- */

function gwnf_preview_order() {
	$ids = wc_get_orders( array( 'limit' => 1, 'orderby' => 'date', 'order' => 'DESC', 'type' => 'shop_order', 'return' => 'ids', 'status' => array( 'wc-completed', 'wc-processing', 'wc-on-hold' ) ) );
	return $ids ? wc_get_order( $ids[0] ) : null;
}

function gwnf_preview_base_url() {
	$o = function_exists( 'gwnot_status_url' ) ? gwnf_preview_order() : null;
	return $o ? add_query_arg( array( 'gwnf_preview' => wp_create_nonce( 'gwnf_preview' ) ), gwnot_status_url( $o ) ) : '';
}

/* ---------------- The page ---------------- */

function gwnf_settings_page() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	$tabs = gwnf_settings_tabs();
	$tab  = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'general'; // phpcs:ignore WordPress.Security.NonceVerification
	$tab  = isset( $tabs[ $tab ] ) ? $tab : 'general';
	echo '<div class="wrap gwnf-wrap"><h1>' . esc_html( (string) apply_filters( 'gwnf_menu_title', __( 'Fulfillment', 'gwnd-fulfillment' ) ) ) . '</h1>';
	echo '<nav class="nav-tab-wrapper wp-clearfix" aria-label="' . esc_attr__( 'Fulfillment settings', 'gwnd-fulfillment' ) . '">';
	foreach ( $tabs as $id => $label ) {
		echo '<a class="nav-tab' . ( $id === $tab ? ' nav-tab-active' : '' ) . '" href="' . esc_url( gwnf_settings_url( $id ) ) . '"' . ( $id === $tab ? ' aria-current="page"' : '' ) . '>' . esc_html( $label ) . '</a>';
	}
	echo '</nav>';
	switch ( $tab ) {
		case 'general':
			gwnf_tab_general();
			break;
		case 'look':
			gwnf_tab_look();
			break;
		case 'wording':
			gwnf_tab_wording();
			break;
		case 'flow':
			gwnf_tab_flow();
			break;
		default:
			do_action( 'gwnf_settings_tab_' . $tab );
	}
	echo '</div>';
}

function gwnf_tab_general() {
	$on     = gwnf_modules();
	$saved  = get_option( 'gwnf_modules', array() );
	$forced = function ( $m ) use ( $on, $saved ) {
		$stored = 'no' !== ( ( is_array( $saved ) ? $saved : array() )[ $m ] ?? 'yes' );
		return $stored !== ! empty( $on[ $m ] );
	};
	echo '<form method="post" action="options.php">';
	settings_fields( 'gwnf_general' );
	echo '<table class="form-table" role="presentation">';
	$rows = array(
		/* translators: %s: URL of the order status page */
		'tracking' => array( __( 'Shipment tracking', 'gwnd-fulfillment' ), sprintf( esc_html__( 'Tracking box on orders, tracking in the completed email, and the private order status page at %s.', 'gwnd-fulfillment' ), '<code>' . esc_html( home_url( '/' . ( function_exists( 'gwnot_slug' ) ? gwnot_slug() : 'order-status' ) . '/' ) ) . '</code>' ) ),
		'slips'    => array( __( 'Packing slips', 'gwnd-fulfillment' ), esc_html__( 'Print packing slips from orders (never shows prices).', 'gwnd-fulfillment' ) . ( ! empty( $on['slips'] ) ? ' <a href="' . esc_url( gwnf_settings_url( 'slips' ) ) . '">' . esc_html__( 'Packing slip settings', 'gwnd-fulfillment' ) . '</a>' : '' ) ),
		'photos'   => array( __( 'Packing photos', 'gwnd-fulfillment' ), esc_html__( 'A "Packing photos" box on each order: take photos of what went in the box (opens the camera on a phone). Kept privately on the order, visible only to staff: your record if a customer says something was missing.', 'gwnd-fulfillment' ) ),
	);
	foreach ( $rows as $k => $r ) {
		echo '<tr><th scope="row">' . esc_html( $r[0] ) . '</th><td><label><input type="checkbox" name="gwnf_modules[' . esc_attr( $k ) . ']" value="yes"' . checked( ! empty( $on[ $k ] ), true, false ) . disabled( $forced( $k ), true, false ) . '> ' . esc_html__( 'On', 'gwnd-fulfillment' ) . '</label>';
		echo '<p class="description">' . wp_kses_post( $r[1] ) . ( $forced( $k ) ? ' <em>' . esc_html__( '(Set in code with the gwnf_modules filter.)', 'gwnd-fulfillment' ) . '</em>' : '' ) . '</p></td></tr>';
	}
	echo '</table>';
	echo '<p class="description">' . esc_html__( 'Switching a part off hides it everywhere. Nothing is deleted: tracking numbers, photos and slip settings come back when it\'s switched on again.', 'gwnd-fulfillment' ) . '</p>';
	submit_button();
	echo '</form>';
	do_action( 'gwnf_settings_sections' );
}

/** A colour field (with the WordPress colour picker). */
function gwnf_color_field( $key, $label, $l ) {
	$id = 'gwnf-c-' . $key;
	echo '<div class="gwnf-color"><span class="gwnf-color__label" id="' . esc_attr( $id ) . '-l">' . esc_html( $label ) . '</span><input type="text" id="' . esc_attr( $id ) . '" aria-labelledby="' . esc_attr( $id ) . '-l" class="gwnf-colorpick" data-key="' . esc_attr( $key ) . '" name="gwnf_look[' . esc_attr( $key ) . ']" value="' . esc_attr( $l[ $key ] ) . '" data-default-color="' . esc_attr( gwnf_look_defaults()[ $key ] ) . '"></div>';
}

/** Hidden "no" + checkbox "yes", so unticking saves. */
function gwnf_check_field( $name, $on, $label ) {
	echo '<label class="gwnf-check"><input type="hidden" name="' . esc_attr( $name ) . '" value="no"><input type="checkbox" name="' . esc_attr( $name ) . '" value="yes"' . checked( $on, true, false ) . '> ' . esc_html( $label ) . '</label>';
}

function gwnf_logo_field( $key, $label, $help, $l ) {
	$id  = absint( $l[ $key ] );
	$src = $id ? wp_get_attachment_image_url( $id, 'medium' ) : '';
	echo '<div class="gwnf-logo" data-key="' . esc_attr( $key ) . '"><div class="gwnf-logo__box' . ( 'logo_dark' === $key ? ' is-dark' : '' ) . '">';
	echo $src ? '<img src="' . esc_url( $src ) . '" alt="">' : '<span>' . esc_html__( 'No logo', 'gwnd-fulfillment' ) . '</span>';
	echo '</div><input type="hidden" name="gwnf_look[' . esc_attr( $key ) . ']" value="' . esc_attr( (string) $id ) . '">';
	echo '<div><strong>' . esc_html( $label ) . '</strong><p class="description">' . esc_html( $help ) . '</p>';
	echo '<button type="button" class="button gwnf-logo__pick">' . esc_html__( 'Choose logo', 'gwnd-fulfillment' ) . '</button> <button type="button" class="button-link gwnf-logo__clear">' . esc_html__( 'Remove', 'gwnd-fulfillment' ) . '</button></div></div>';
}

function gwnf_tab_look() {
	$l      = gwnf_look();
	$styles = gwnf_styles();
	echo '<form method="post" action="options.php" class="gwnf-look" id="gwnf-look">';
	settings_fields( 'gwnf_look' );
	echo '<div class="gwnf-look__cols"><div class="gwnf-look__form">';

	echo '<section class="gwnf-panel"><h2>' . esc_html__( 'Style', 'gwnd-fulfillment' ) . '</h2><p class="description">' . esc_html__( 'Pick a starting point. Change anything below and it becomes your own style.', 'gwnd-fulfillment' ) . '</p><div class="gwnf-styles" role="radiogroup" aria-label="' . esc_attr__( 'Style', 'gwnd-fulfillment' ) . '">';
	foreach ( $styles as $id => $s ) {
		echo '<label class="gwnf-style"><input type="radio" name="gwnf_look[style]" value="' . esc_attr( $id ) . '"' . checked( $l['style'], $id, false ) . '><span class="gwnf-style__name">' . esc_html( $s['label'] ) . '</span><span class="gwnf-style__desc">' . esc_html( $s['desc'] ) . '</span></label>';
	}
	if ( 'custom' === $l['style'] || has_action( 'gwnf_look_fields' ) ) {
		echo '<label class="gwnf-style gwnf-style--custom"><input type="radio" name="gwnf_look[style]" value="custom"' . checked( $l['style'], 'custom', false ) . '><span class="gwnf-style__name">' . esc_html__( 'My style', 'gwnd-fulfillment' ) . '</span><span class="gwnf-style__desc">' . esc_html__( 'Your own mix of the settings below.', 'gwnd-fulfillment' ) . '</span></label>';
	}
	echo '</div></section>';

	echo '<section class="gwnf-panel"><h2>' . esc_html__( 'Logo', 'gwnd-fulfillment' ) . '</h2>';
	gwnf_logo_field( 'logo', __( 'Logo', 'gwnd-fulfillment' ), __( 'PNG, JPG or SVG from your Media Library. Shown above the order.', 'gwnd-fulfillment' ), $l );
	gwnf_logo_field( 'logo_dark', __( 'Logo for dark backgrounds (optional)', 'gwnd-fulfillment' ), __( 'A light version, used on dark pages and colour bands. Leave empty to use the logo above everywhere.', 'gwnd-fulfillment' ), $l );
	gwnf_check_field( 'gwnf_look[logo_site]', 'yes' === $l['logo_site'], __( 'No logo chosen? Use the site logo from the theme', 'gwnd-fulfillment' ) );
	echo '<p class="gwnf-row"><label for="gwnf-logo-h">' . esc_html__( 'Logo height', 'gwnd-fulfillment' ) . '</label> <input id="gwnf-logo-h" type="number" min="16" max="160" name="gwnf_look[logo_h]" value="' . esc_attr( (string) $l['logo_h'] ) . '" class="small-text"> px &nbsp; ';
	echo '<label for="gwnf-logo-pos">' . esc_html__( 'Position', 'gwnd-fulfillment' ) . '</label> <select id="gwnf-logo-pos" name="gwnf_look[logo_pos]"><option value="left"' . selected( $l['logo_pos'], 'left', false ) . '>' . esc_html__( 'Left', 'gwnd-fulfillment' ) . '</option><option value="center"' . selected( $l['logo_pos'], 'center', false ) . '>' . esc_html__( 'Centred', 'gwnd-fulfillment' ) . '</option></select></p>';
	echo '</section>';

	echo '<section class="gwnf-panel"><h2>' . esc_html__( 'Colours', 'gwnd-fulfillment' ) . '</h2><p class="description">' . esc_html__( 'Brand: buttons, progress and highlights. Accent: badges and soft highlights. Theme default ignores these and keeps your theme\'s colours.', 'gwnd-fulfillment' ) . '</p><div class="gwnf-colors">';
	gwnf_color_field( 'brand', __( 'Brand', 'gwnd-fulfillment' ), $l );
	gwnf_color_field( 'on_brand', __( 'Text on brand (empty = automatic)', 'gwnd-fulfillment' ), $l );
	gwnf_color_field( 'accent', __( 'Accent', 'gwnd-fulfillment' ), $l );
	do_action( 'gwnf_look_colour_fields', $l );
	echo '</div><p class="gwnf-contrast" aria-live="polite"></p></section>';

	do_action( 'gwnf_look_fields', $l ); // add-ons: layout, progress display, cards, fonts, custom CSS…

	echo '<section class="gwnf-panel"><h2>' . esc_html__( 'Use this look on', 'gwnd-fulfillment' ) . '</h2>';
	gwnf_check_field( 'gwnf_look[on_status]', 'yes' === $l['on_status'], __( 'Order status page', 'gwnd-fulfillment' ) );
	gwnf_check_field( 'gwnf_look[on_account]', 'yes' === $l['on_account'], __( 'My account → order view', 'gwnd-fulfillment' ) );
	if ( defined( 'GWNET_VERSION' ) ) {
		gwnf_check_field( 'gwnf_look[on_etransfer]', 'yes' === $l['on_etransfer'], __( 'e-Transfer pay panel (colours and corners)', 'gwnd-fulfillment' ) );
	}
	gwnf_check_field( 'gwnf_look[on_emails]', 'yes' === $l['on_emails'], __( 'WooCommerce emails: use this logo and brand colour (instead of the header image and base colour in WooCommerce → Settings → Emails)', 'gwnd-fulfillment' ) );
	gwnf_check_field( 'gwnf_look[on_slips]', 'yes' === $l['on_slips'], __( 'Packing slips: use this logo when the slip settings have none', 'gwnd-fulfillment' ) );
	echo '</section>';

	submit_button();
	echo '</div>';

	$preview = gwnf_preview_base_url();
	echo '<aside class="gwnf-look__preview"><div class="gwnf-panel"><h2>' . esc_html__( 'Preview', 'gwnd-fulfillment' ) . '</h2>';
	if ( $preview ) {
		echo '<p class="description">' . esc_html__( 'Your newest order\'s status page, with the changes on the left. Nothing is saved until you click Save Changes.', 'gwnd-fulfillment' ) . '</p>';
		echo '<div class="gwnf-preview"><iframe title="' . esc_attr__( 'Order status page preview', 'gwnd-fulfillment' ) . '" src="' . esc_url( $preview ) . '"></iframe></div>';
		echo '<p><a class="gwnf-preview-open" href="' . esc_url( $preview ) . '" target="_blank" rel="noopener">' . esc_html__( 'Open the preview in a new tab', 'gwnd-fulfillment' ) . '</a></p>';
	} else {
		echo '<p class="description">' . esc_html__( 'The preview appears once the store has an order.', 'gwnd-fulfillment' ) . '</p>';
	}
	echo '</div></aside></div></form>';
}

function gwnf_tab_wording() {
	$saved = get_option( 'gwnf_words', array() );
	$saved = is_array( $saved ) ? $saved : array();
	echo '<form method="post" action="options.php" class="gwnf-words">';
	settings_fields( 'gwnf_wording' );
	echo '<p class="description">' . esc_html__( 'Leave a line empty to use the default shown in grey (which follows the site language). Anything you type is used exactly as written.', 'gwnd-fulfillment' ) . '</p>';
	$schema = gwnf_words_schema();
	foreach ( gwnf_words_groups() as $g => $glabel ) {
		echo '<h2>' . esc_html( $glabel ) . '</h2><table class="form-table" role="presentation">';
		foreach ( $schema as $k => $row ) {
			if ( $row[0] !== $g ) {
				continue;
			}
			$val  = $saved[ $k ] ?? '';
			$long = strlen( $row[2] ) > 60;
			echo '<tr><th scope="row"><label for="gwnf-w-' . esc_attr( $k ) . '">' . esc_html( $row[1] ) . '</label></th><td>';
			if ( $long ) {
				echo '<textarea id="gwnf-w-' . esc_attr( $k ) . '" name="gwnf_words[' . esc_attr( $k ) . ']" rows="2" class="large-text" placeholder="' . esc_attr( $row[2] ) . '">' . esc_textarea( $val ) . '</textarea>';
			} else {
				echo '<input type="text" id="gwnf-w-' . esc_attr( $k ) . '" name="gwnf_words[' . esc_attr( $k ) . ']" class="regular-text" value="' . esc_attr( $val ) . '" placeholder="' . esc_attr( $row[2] ) . '">';
			}
			echo '</td></tr>';
		}
		echo '</table>';
	}
	submit_button();
	echo '</form>';
}

function gwnf_tab_flow() {
	$f = gwnf_flow();
	echo '<form method="post" action="options.php">';
	settings_fields( 'gwnf_flow' );
	echo '<table class="form-table" role="presentation">';
	echo '<tr><th scope="row"><label for="gwnf-slug">' . esc_html__( 'Order status page address', 'gwnd-fulfillment' ) . '</label></th><td><code>' . esc_html( home_url( '/' ) ) . '</code><input id="gwnf-slug" type="text" name="gwnf_flow[slug]" value="' . esc_attr( $f['slug'] ) . '" class="regular-text" style="width:14em"><code>/</code><p class="description">' . esc_html__( 'Customers reach their order at this address (it\'s also in emails and on packing slip QR codes).', 'gwnd-fulfillment' ) . '</p></td></tr>';
	echo '<tr><th scope="row"><label for="gwnf-help">' . esc_html__( 'Help email', 'gwnd-fulfillment' ) . '</label></th><td><input id="gwnf-help" type="email" name="gwnf_flow[help_email]" value="' . esc_attr( $f['help_email'] ) . '" class="regular-text" placeholder="' . esc_attr( get_option( 'woocommerce_email_from_address', get_option( 'admin_email' ) ) ) . '"><p class="description">' . esc_html__( 'Shown on the order status page. Empty uses the WooCommerce "from" address.', 'gwnd-fulfillment' ) . '</p></td></tr>';
	echo '<tr><th scope="row">' . esc_html__( 'When tracking is saved', 'gwnd-fulfillment' ) . '</th><td>';
	echo '<fieldset><label><input type="radio" name="gwnf_flow[complete]" value="yes"' . checked( $f['complete'], 'yes', false ) . '> ' . esc_html__( 'Mark the order Completed (shipped) and send the completed email with tracking', 'gwnd-fulfillment' ) . '</label><br>';
	echo '<label><input type="radio" name="gwnf_flow[complete]" value="no"' . checked( $f['complete'], 'no', false ) . '> ' . esc_html__( 'Leave the status alone and send the tracking as a customer note', 'gwnd-fulfillment' ) . '</label></fieldset><p>';
	gwnf_check_field( 'gwnf_flow[notify]', 'yes' === $f['notify'], __( '"Email the customer" is ticked by default on the order screen', 'gwnd-fulfillment' ) );
	echo '</p></td></tr>';
	echo '<tr><th scope="row">' . esc_html__( 'Carriers offered', 'gwnd-fulfillment' ) . '</th><td><fieldset>';
	$chosen = (array) $f['carriers'];
	echo '<input type="hidden" name="gwnf_flow[carriers][]" value="">';
	foreach ( gwnot_carriers() as $k => $c ) {
		if ( 'other' === $k ) {
			continue;
		}
		echo '<label style="display:inline-block;min-width:11em"><input type="checkbox" name="gwnf_flow[carriers][]" value="' . esc_attr( $k ) . '"' . checked( ! $chosen || in_array( $k, $chosen, true ), true, false ) . '> ' . esc_html( $c['name'] ) . '</label> ';
	}
	echo '<p class="description">' . esc_html__( 'Only these appear in the order screen\'s carrier list ("Other" is always there). Tracking already saved keeps its carrier.', 'gwnd-fulfillment' ) . '</p></fieldset></td></tr>';
	echo '<tr><th scope="row">' . esc_html__( 'My account', 'gwnd-fulfillment' ) . '</th><td>';
	gwnf_check_field( 'gwnf_flow[account_link]', 'yes' === $f['account_link'], __( 'Link each order to its order status page', 'gwnd-fulfillment' ) );
	echo '<br>';
	gwnf_check_field( 'gwnf_flow[list_action]', 'yes' === $f['list_action'], __( 'Show a "Track" button in the orders list', 'gwnd-fulfillment' ) );
	echo '</td></tr>';
	do_action( 'gwnf_flow_fields', $f );
	echo '</table>';
	submit_button();
	echo '</form>';
}
