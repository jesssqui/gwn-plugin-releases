<?php
/**
 * Admin: "Shipment tracking" box on the order screen (HPOS + legacy) and a Tracking column in the orders list.
 *
 * Save flow (woocommerce_process_shop_order_meta):
 *   priority 30 — before WooCommerce saves the status: remove/add tracking so any status email sees it.
 *   priority 60 — after: if a number was added and "mark shipped" is ticked, complete the order
 *                 (fires the completed email) or, if it was already completed, re-send that email.
 */
defined( 'ABSPATH' ) || exit;

function gwnot_order_screen() {
	if ( function_exists( 'wc_get_container' ) && class_exists( \Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController::class )
		&& wc_get_container()->get( \Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController::class )->custom_orders_table_usage_is_enabled() ) {
		return wc_get_page_screen_id( 'shop-order' );
	}
	return 'shop_order';
}

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'gwnot-tracking', __( 'Shipment tracking', 'gwnd-fulfillment' ), 'gwnot_meta_box', gwnot_order_screen(), 'side', 'high' );
} );

function gwnot_meta_box( $obj ) {
	$order = $obj instanceof WP_Post ? wc_get_order( $obj->ID ) : $obj;
	if ( ! $order instanceof WC_Order ) {
		return;
	}
	$views    = gwnot_views( $order );
	$done     = $order->has_status( 'completed' );
	$complete = 'yes' === gwnf_flow( 'complete' );
	wp_nonce_field( 'gwnot_save', 'gwnot_nonce' );
	echo '<div class="gwnot-box">';
	if ( $views ) {
		echo '<ul class="gwnot-list">';
		foreach ( $views as $v ) {
			$l = $v['live'];
			echo '<li>';
			echo '<div class="gwnot-l1"><strong>' . esc_html( $v['carrier'] ) . '</strong> ';
			echo $v['url'] ? '<a href="' . esc_url( $v['url'] ) . '" target="_blank" rel="noopener">' . esc_html( $v['number'] ) . '</a>' : esc_html( $v['number'] );
			echo '</div>';
			if ( $l && function_exists( 'gwnot_live_pill' ) ) {
				echo '<div class="gwnot-l2">' . gwnot_live_pill( $l['stalled'] ? 'stalled' : $l['status'], $l['stalled'] ? __( 'No movement', 'gwnd-fulfillment' ) : '' ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in the pill
				if ( $l['eta'] && 'delivered' !== $l['status'] ) {
					/* translators: %s: expected delivery date */
					echo ' <span class="gwnot-eta">' . esc_html( sprintf( __( 'Expected %s', 'gwnd-fulfillment' ), gwnot_live_eta_text( $l['eta'] ) ) ) . '</span>';
				}
				echo '</div>';
				if ( $l['text'] ) {
					echo '<div class="gwnot-live">' . esc_html( $l['text'] ) . ( $l['where'] ? ' — ' . esc_html( $l['where'] ) : '' ) . ( $l['when'] ? ' · ' . esc_html( wp_date( 'M j, g:i a', $l['when'] ) ) : '' ) . '</div>';
				}
				if ( $l['error'] ) {
					echo '<div class="gwnot-err">' . esc_html( $l['error'] ) . '</div>';
				}
			}
			/* translators: %s: date */
			$added = sprintf( __( 'Added %s', 'gwnd-fulfillment' ), gwnot_date( $v['date'] ) );
			if ( $l && $l['checked'] ) {
				/* translators: %s: time since */
				$added .= ' · ' . sprintf( __( 'checked %s ago', 'gwnd-fulfillment' ), human_time_diff( $l['checked'] ) );
			}
			echo '<div class="gwnot-l3"><span class="gwnot-muted">' . esc_html( $added ) . '</span>';
			echo '<label class="gwnot-rm"><input type="checkbox" name="gwnot_remove[]" value="' . esc_attr( $v['id'] ) . '"> ' . esc_html__( 'Remove', 'gwnd-fulfillment' ) . '</label></div></li>';
		}
		echo '</ul>';
		do_action( 'gwnot_meta_box_after_list', $order, $views );
		echo '<p class="gwnot-sub">' . esc_html__( 'Add another tracking number', 'gwnd-fulfillment' ) . '</p>';
	}
	echo '<p><label for="gwnot_carrier">' . esc_html__( 'Carrier', 'gwnd-fulfillment' ) . '</label><select id="gwnot_carrier" name="gwnot_carrier" style="width:100%">';
	echo '<option value="auto" selected>' . esc_html__( 'Auto-detect from the number', 'gwnd-fulfillment' ) . '</option>';
	foreach ( gwnf_carriers_offered() as $k => $c ) {
		echo '<option value="' . esc_attr( $k ) . '">' . esc_html( $c['name'] ) . '</option>';
	}
	echo '</select></p>';
	echo '<p class="gwnot-other"><label for="gwnot_carrier_name">' . esc_html__( 'Carrier name', 'gwnd-fulfillment' ) . '</label><input type="text" id="gwnot_carrier_name" name="gwnot_carrier_name" style="width:100%"></p>';
	echo '<p class="gwnot-other"><label for="gwnot_url">' . esc_html__( 'Tracking link', 'gwnd-fulfillment' ) . '</label><input type="url" id="gwnot_url" name="gwnot_url" placeholder="https://" style="width:100%"></p>';
	echo '<p><label for="gwnot_number">' . esc_html__( 'Tracking number', 'gwnd-fulfillment' ) . '</label><input type="text" id="gwnot_number" name="gwnot_number" autocomplete="off" spellcheck="false" placeholder="' . esc_attr__( 'Scan or paste the label barcode', 'gwnd-fulfillment' ) . '" style="width:100%" data-rules="' . esc_attr( wp_json_encode( gwnot_detect_rules() ) ) . '"><span class="gwnot-detected gwnot-muted" aria-live="polite"></span></p>';
	if ( $done || ! $complete ) {
		$label  = __( 'Email the customer this tracking', 'gwnd-fulfillment' );
		$button = __( 'Save tracking', 'gwnd-fulfillment' );
	} else {
		$label  = __( 'Mark as Completed and email the customer', 'gwnd-fulfillment' );
		$button = __( 'Save tracking and mark shipped', 'gwnd-fulfillment' );
	}
	echo '<p><label><input type="checkbox" name="gwnot_notify" value="1"' . checked( 'yes', gwnf_flow( 'notify' ), false ) . '> ' . esc_html( $label ) . '</label></p>';
	echo '<p><button type="submit" class="button button-primary" name="gwnot_submit" value="1" style="width:100%">' . esc_html( $button ) . '</button></p>';
	echo '<p class="gwnot-muted">' . esc_html__( 'Customer link:', 'gwnd-fulfillment' ) . ' <a href="' . esc_url( gwnot_status_url( $order ) ) . '" target="_blank" rel="noopener">' . esc_html__( 'order status page', 'gwnd-fulfillment' ) . '</a></p>';
	echo '</div>';
	?>
	<style>
	.gwnot-box label{font-weight:600;display:block;margin-bottom:3px}.gwnot-box label:has(input[type=checkbox]){font-weight:400;display:inline}
	.gwnot-list{margin:0 0 6px}.gwnot-list li{padding:10px 0;border-bottom:1px solid #eee;margin:0;display:grid;gap:4px}
	.gwnot-l2{display:flex;flex-wrap:wrap;gap:6px;align-items:center}.gwnot-eta{font-size:12px;font-weight:600}
	.gwnot-l3{display:flex;justify-content:space-between;align-items:center;gap:8px}
	.gwnot-muted{color:#646970;font-size:12px}.gwnot-box label.gwnot-rm{display:inline-flex;gap:4px;align-items:center;white-space:nowrap;font-size:12px;font-weight:400;color:#b32d2e;margin:0}.gwnot-sub{font-weight:600;margin:10px 0 0}
	.gwnot-live{font-size:12px;line-height:1.4}.gwnot-err{color:#b32d2e;font-size:12px}.gwnot-detected{display:block;margin-top:3px;color:#007017}.gwnot-other{display:none}.gwnot-box.is-other .gwnot-other{display:block}
	</style>
	<script>
	(function(){var b=document.querySelector('.gwnot-box'),s=document.getElementById('gwnot_carrier');if(!b||!s)return;
	function t(){b.classList.toggle('is-other',s.value==='other');}s.addEventListener('change',t);t();
	if(window.jQuery){jQuery(s).on('change',t);}
	var n=document.getElementById('gwnot_number'),hint=b.querySelector('.gwnot-detected'),rules=[],msg=<?php /* translators: %s: carrier name */ echo wp_json_encode( __( 'Carrier detected: %s', 'gwnd-fulfillment' ) ); ?>;try{rules=JSON.parse(n.getAttribute('data-rules')||'[]');}catch(e){}
	// Scanning a label barcode (or pasting a number) shows which carrier it belongs to.
	function detect(){var v=(n.value||'').toUpperCase().replace(/[^A-Z0-9]/g,'');hint.textContent='';if(!v)return;
		for(var i=0;i<rules.length;i++){if(new RegExp(rules[i][1]).test(v)){var o=s.querySelector('option[value="'+rules[i][0]+'"]');if(!o)continue;if(s.value!=='auto'&&s.value!==rules[i][0]){s.value=rules[i][0];if(window.jQuery){jQuery(s).trigger('change');}t();}hint.textContent=msg.replace('%s',o.text);return;}}}
	n.addEventListener('input',detect);n.addEventListener('paste',function(){setTimeout(detect,0);});
	n.addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();detect();b.querySelector('[name=gwnot_submit]').click();}});})();
	</script>
	<?php
}

add_action( 'woocommerce_process_shop_order_meta', function ( $order_id ) {
	if ( empty( $_POST['gwnot_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['gwnot_nonce'] ) ), 'gwnot_save' ) || ! current_user_can( 'edit_shop_orders' ) ) {
		return;
	}
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return;
	}
	$GLOBALS['gwnot_prev_status'] = $order->get_status();
	foreach ( array_map( 'sanitize_key', (array) wp_unslash( $_POST['gwnot_remove'] ?? array() ) ) as $rid ) {
		gwnot_remove_shipment( $order, $rid );
	}
	$number = sanitize_text_field( wp_unslash( $_POST['gwnot_number'] ?? '' ) );
	if ( '' === trim( $number ) ) {
		return;
	}
	$res = gwnot_add_shipment( $order, sanitize_key( wp_unslash( $_POST['gwnot_carrier'] ?? 'auto' ) ), $number, array(
		'carrier_name' => sanitize_text_field( wp_unslash( $_POST['gwnot_carrier_name'] ?? '' ) ),
		'url'          => esc_url_raw( wp_unslash( $_POST['gwnot_url'] ?? '' ) ),
	) );
	if ( is_wp_error( $res ) ) {
		WC_Admin_Meta_Boxes::add_error( $res->get_error_message() );
		return;
	}
	$GLOBALS['gwnot_added'] = ! empty( $_POST['gwnot_notify'] );
}, 30 );

add_action( 'woocommerce_process_shop_order_meta', function ( $order_id ) {
	if ( empty( $GLOBALS['gwnot_added'] ) ) {
		return;
	}
	unset( $GLOBALS['gwnot_added'] );
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return;
	}
	$was_done = 'completed' === ( $GLOBALS['gwnot_prev_status'] ?? '' );
	if ( 'yes' !== gwnf_flow( 'complete' ) && ! $order->has_status( 'completed' ) ) {
		// Store keeps orders open after shipping (Workflow): just email the tracking.
		if ( function_exists( 'WC' ) && ( $mails = WC()->mailer()->get_emails() ) && isset( $mails['WC_Email_Customer_Note'] ) ) {
			$order->add_order_note( wp_strip_all_tags( gwnot_mail_panel_plain( $order ) ), true, true );
		}
		return;
	}
	if ( ! $order->has_status( 'completed' ) ) {
		gwnot_mark_shipped( $order );          // status change → completed email with tracking
	} elseif ( $was_done ) {
		gwnot_mark_shipped( $order, true );    // already completed before this save → re-send
	}                                          // else: admin set Completed in the dropdown — that email already went out with tracking
}, 60 );

/* ---------- Orders list column ---------- */
function gwnot_add_column( $cols ) {
	$out = array();
	foreach ( $cols as $k => $v ) {
		$out[ $k ] = $v;
		if ( 'order_status' === $k ) {
			$out['gwnot_tracking'] = __( 'Tracking', 'gwnd-fulfillment' );
		}
	}
	return $out;
}
function gwnot_render_column( $order ) {
	$order = $order instanceof WC_Order ? $order : wc_get_order( $order );
	$views = $order ? gwnot_views( $order ) : array();
	if ( ! $views ) {
		echo '<span class="na">–</span>';
		return;
	}
	foreach ( $views as $v ) {
		$l = $v['live'];
		echo '<div>' . ( $l && ( $l['checked'] || $l['text'] ) && function_exists( 'gwnot_live_pill' ) ? gwnot_live_pill( $l['stalled'] ? 'stalled' : $l['status'], $l['stalled'] ? __( 'No movement', 'gwnd-fulfillment' ) : '' ) . '<br>' : '' ) . '<small>' . esc_html( $v['carrier'] ) . '</small><br>'; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in the pill
		echo $v['url'] ? '<a href="' . esc_url( $v['url'] ) . '" target="_blank" rel="noopener">' . esc_html( $v['number'] ) . '</a>' : esc_html( $v['number'] );
		echo '</div>';
	}
}
add_filter( 'manage_woocommerce_page_wc-orders_columns', 'gwnot_add_column', 20 );
add_action( 'manage_woocommerce_page_wc-orders_custom_column', function ( $col, $order ) {
	if ( 'gwnot_tracking' === $col ) { gwnot_render_column( $order ); }
}, 10, 2 );
add_filter( 'manage_edit-shop_order_columns', 'gwnot_add_column', 20 );
add_action( 'manage_shop_order_posts_custom_column', function ( $col, $post_id ) {
	if ( 'gwnot_tracking' === $col ) { gwnot_render_column( $post_id ); }
}, 10, 2 );
