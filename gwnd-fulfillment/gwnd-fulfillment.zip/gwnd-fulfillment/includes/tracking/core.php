<?php
/**
 * Data model + helpers. Shipments live in order meta `_gwnot_shipments`:
 * [ [id, carrier, carrier_name, number, url, date], … ]
 */
defined( 'ABSPATH' ) || exit;

const GWNOT_META = '_gwnot_shipments';

function gwnot_slug() {
	return trim( (string) apply_filters( 'gwnot_slug', 'order-status' ), '/' );
}

/**
 * Built-in carriers: key => [name, url, countries]. {n} is replaced by the tracking number.
 * countries: ISO codes of the stores that see the carrier by default ('*' = everywhere).
 * Links go to each carrier's public tracking page; nothing is sent anywhere until the customer clicks.
 */
function gwnot_builtin_carriers() {
	return array(
		// Worldwide.
		'ups'            => array( 'name' => 'UPS', 'url' => 'https://www.ups.com/track?tracknum={n}', 'countries' => array( '*' ) ),
		'fedex'          => array( 'name' => 'FedEx', 'url' => 'https://www.fedex.com/fedextrack/?trknbr={n}', 'countries' => array( '*' ) ),
		'dhl'            => array( 'name' => 'DHL', 'url' => 'https://www.dhl.com/global-en/home/tracking.html?tracking-id={n}&submit=1', 'countries' => array( '*' ) ),
		// Canada.
		'canada-post'    => array( 'name' => 'Canada Post', 'url' => 'https://www.canadapost-postescanada.ca/track-reperage/en#/search?searchFor={n}', 'countries' => array( 'CA' ) ),
		'purolator'      => array( 'name' => 'Purolator', 'url' => 'https://www.purolator.com/en/shipping/tracker?pin={n}', 'countries' => array( 'CA' ) ),
		'canpar'         => array( 'name' => 'Canpar', 'url' => 'https://www.canpar.com/en/tracking/delivery_options.htm?barcode={n}', 'countries' => array( 'CA' ) ),
		'chit-chats'     => array( 'name' => 'Chit Chats', 'url' => 'https://chitchats.com/tracking/{n}', 'countries' => array( 'CA' ) ),
		// United States.
		'usps'           => array( 'name' => 'USPS', 'url' => 'https://tools.usps.com/go/TrackConfirmAction?tLabels={n}', 'countries' => array( 'US', 'PR' ) ),
		'ontrac'         => array( 'name' => 'OnTrac', 'url' => 'https://www.ontrac.com/tracking/?number={n}', 'countries' => array( 'US' ) ),
		// United Kingdom and Ireland.
		'royal-mail'     => array( 'name' => 'Royal Mail', 'url' => 'https://www.royalmail.com/track-your-item#/tracking-results/{n}', 'countries' => array( 'GB' ) ),
		'parcelforce'    => array( 'name' => 'Parcelforce', 'url' => 'https://www.parcelforce.com/track-trace?trackNumber={n}', 'countries' => array( 'GB' ) ),
		'evri'           => array( 'name' => 'Evri', 'url' => 'https://www.evri.com/track/parcel/{n}', 'countries' => array( 'GB' ) ),
		'dpd-uk'         => array( 'name' => 'DPD UK', 'url' => 'https://track.dpd.co.uk/parcels/{n}', 'countries' => array( 'GB' ) ),
		'an-post'        => array( 'name' => 'An Post', 'url' => 'https://www.anpost.com/Post-Parcels/Track/History?item={n}', 'countries' => array( 'IE' ) ),
		// Europe.
		'dpd'            => array( 'name' => 'DPD', 'url' => 'https://tracking.dpd.de/status/en_US/parcel/{n}', 'countries' => array( 'DE', 'AT', 'BE', 'NL', 'LU', 'FR', 'PL', 'CZ', 'SK' ) ),
		'gls'            => array( 'name' => 'GLS', 'url' => 'https://gls-group.com/track/{n}', 'countries' => array( 'DE', 'AT', 'BE', 'NL', 'FR', 'IT', 'ES', 'PT', 'DK', 'PL', 'CZ', 'HU' ) ),
		'deutsche-post'  => array( 'name' => 'Deutsche Post', 'url' => 'https://www.deutschepost.de/de/s/sendungsverfolgung.html?piececode={n}', 'countries' => array( 'DE' ) ),
		'postnl'         => array( 'name' => 'PostNL', 'url' => 'https://jouw.postnl.nl/track-and-trace/{n}', 'countries' => array( 'NL', 'BE' ) ),
		'bpost'          => array( 'name' => 'bpost', 'url' => 'https://track.bpost.cloud/btr/web/#/search?itemCode={n}', 'countries' => array( 'BE' ) ),
		'colissimo'      => array( 'name' => 'La Poste / Colissimo', 'url' => 'https://www.laposte.fr/outils/suivre-vos-envois?code={n}', 'countries' => array( 'FR' ) ),
		'correos'        => array( 'name' => 'Correos', 'url' => 'https://www.correos.es/es/en/tools/tracker/items/details?tracking-number={n}', 'countries' => array( 'ES' ) ),
		'poste-italiane' => array( 'name' => 'Poste Italiane', 'url' => 'https://www.poste.it/cerca/index.html#/risultati-spedizioni/{n}', 'countries' => array( 'IT' ) ),
		'postnord'       => array( 'name' => 'PostNord', 'url' => 'https://tracking.postnord.com/tracking.html?id={n}', 'countries' => array( 'SE', 'DK', 'NO', 'FI' ) ),
		'inpost'         => array( 'name' => 'InPost', 'url' => 'https://inpost.pl/sledzenie-przesylek?number={n}', 'countries' => array( 'PL' ) ),
		// Australia and New Zealand.
		'australia-post' => array( 'name' => 'Australia Post', 'url' => 'https://auspost.com.au/mypost/track/details/{n}', 'countries' => array( 'AU' ) ),
		'startrack'      => array( 'name' => 'StarTrack', 'url' => 'https://startrack.com.au/track/details/{n}', 'countries' => array( 'AU' ) ),
		'aramex'         => array( 'name' => 'Aramex', 'url' => 'https://www.aramex.com/track/results?ShipmentNumber={n}', 'countries' => array( 'AU', 'NZ', 'AE', 'SA' ) ),
		'sendle'         => array( 'name' => 'Sendle', 'url' => 'https://track.sendle.com/tracking?ref={n}', 'countries' => array( 'AU', 'US' ) ),
		'nz-post'        => array( 'name' => 'NZ Post', 'url' => 'https://www.nzpost.co.nz/tools/tracking?trackid={n}', 'countries' => array( 'NZ' ) ),
	);
}

/**
 * All carriers the store can pick from: built-in, then the store's own (Workflow → Your own carriers), then "Other".
 * key => [name, url, countries, custom?]. Filter: gwnot_carriers.
 */
function gwnot_carriers() {
	$list = gwnot_builtin_carriers();
	foreach ( (array) ( function_exists( 'gwnf_flow' ) ? gwnf_flow( 'custom_carriers' ) : array() ) as $c ) {
		if ( empty( $c['name'] ) ) {
			continue;
		}
		$key          = 'my-' . sanitize_title( $c['name'] );
		$list[ $key ] = array( 'name' => $c['name'], 'url' => (string) ( $c['url'] ?? '' ), 'countries' => array( '*' ), 'custom' => true );
	}
	$list['other'] = array( 'name' => __( 'Other carrier', 'gwnd-fulfillment' ), 'url' => '', 'countries' => array( '*' ) );
	return apply_filters( 'gwnot_carriers', $list );
}

/** Universal fallback page for carriers without a link (Workflow → "Link other carriers to 17TRACK"). */
function gwnot_fallback_url( $number ) {
	if ( ! function_exists( 'gwnf_flow' ) || 'yes' !== gwnf_flow( 'fallback_17track' ) ) {
		return '';
	}
	return (string) apply_filters( 'gwnot_fallback_url', 'https://t.17track.net/en#nums=' . rawurlencode( $number ), $number );
}

/** Raw shipments stored on an order. */
function gwnot_shipments( $order ) {
	if ( ! $order instanceof WC_Order ) {
		return array();
	}
	$s = $order->get_meta( GWNOT_META, true );
	return is_array( $s ) ? array_values( $s ) : array();
}

/** A shipment ready for display: carrier name, number, tracking url, date. */
function gwnot_view( $s ) {
	$c   = gwnot_carriers();
	$key = $s['carrier'] ?? 'other';
	$name = ( 'other' === $key || ! isset( $c[ $key ] ) ) ? ( ! empty( $s['carrier_name'] ) ? $s['carrier_name'] : 'Carrier' ) : $c[ $key ]['name'];
	$url  = ! empty( $s['url'] ) ? $s['url'] : '';
	if ( ! $url && ! empty( $c[ $key ]['url'] ) ) {
		$url = str_replace( '{n}', rawurlencode( $s['number'] ), $c[ $key ]['url'] );
	}
	if ( ! $url && ! empty( $s['number'] ) ) {
		$url = gwnot_fallback_url( $s['number'] );
	}
	return array(
		'id'      => $s['id'] ?? '',
		'carrier' => $name,
		'number'  => $s['number'] ?? '',
		'url'     => $url,
		'date'    => (int) ( $s['date'] ?? 0 ),
	);
}

function gwnot_views( $order ) {
	return (array) apply_filters( 'gwnot_views', array_map( 'gwnot_view', gwnot_shipments( $order ) ), $order );
}

/**
 * Public API: add a tracking number to an order. Returns the stored shipment or WP_Error.
 * Does not change the order status (see gwnot_mark_shipped()).
 */
function gwnot_add_shipment( $order, $carrier, $number, $args = array() ) {
	$order  = $order instanceof WC_Order ? $order : wc_get_order( $order );
	$number = gwnot_clean_number( sanitize_text_field( (string) $number ) );
	if ( ! $order ) {
		return new WP_Error( 'gwnot_order', __( 'Order not found.', 'gwnd-fulfillment' ) );
	}
	if ( '' === $number ) {
		return new WP_Error( 'gwnot_number', __( 'Tracking number is empty.', 'gwnd-fulfillment' ) );
	}
	$carrier = sanitize_key( (string) $carrier );
	if ( '' === $carrier || 'auto' === $carrier ) {
		$carrier = gwnot_detect_carrier( $number ) ?: 'other';
	}
	if ( ! isset( gwnot_carriers()[ $carrier ] ) ) {
		$args['carrier_name'] = $args['carrier_name'] ?? $carrier;
		$carrier              = 'other';
	}
	$list = gwnot_shipments( $order );
	foreach ( $list as $s ) {
		if ( $s['number'] === $number ) {
			return new WP_Error( 'gwnot_dupe', __( 'That tracking number is already on this order.', 'gwnd-fulfillment' ) );
		}
	}
	$ship = array(
		'id'           => strtolower( wp_generate_password( 8, false ) ),
		'carrier'      => $carrier,
		'carrier_name' => 'other' === $carrier ? sanitize_text_field( $args['carrier_name'] ?? '' ) : ( ! empty( gwnot_carriers()[ $carrier ]['custom'] ) ? gwnot_carriers()[ $carrier ]['name'] : '' ),
		'number'       => $number,
		'url'          => 'other' === $carrier ? esc_url_raw( $args['url'] ?? '' ) : '',
		'date'         => ! empty( $args['date'] ) ? (int) $args['date'] : time(),
		'source'       => sanitize_key( $args['source'] ?? 'manual' ),
	);
	$list[] = $ship;
	$order->update_meta_data( GWNOT_META, $list );
	$v = gwnot_view( $ship );
	/* translators: 1: carrier, 2: tracking number, 3: " (imported)" or nothing */
	$order->add_order_note( sprintf( __( 'Tracking added: %1$s %2$s%3$s', 'gwnd-fulfillment' ), $v['carrier'], $v['number'], 'import' === $ship['source'] ? __( ' (imported)', 'gwnd-fulfillment' ) : '' ) );
	$order->save();
	update_option( 'gwnot_last_carrier', $carrier, false );
	do_action( 'gwnot_shipment_added', $order, $ship );
	return $ship;
}

function gwnot_remove_shipment( $order, $id ) {
	$list = gwnot_shipments( $order );
	$keep = array();
	foreach ( $list as $s ) {
		if ( ( $s['id'] ?? '' ) === $id ) {
			$v = gwnot_view( $s );
			/* translators: 1: carrier, 2: tracking number */ $order->add_order_note( sprintf( __( 'Tracking removed: %1$s %2$s', 'gwnd-fulfillment' ), $v['carrier'], $v['number'] ) );
			continue;
		}
		$keep[] = $s;
	}
	if ( count( $keep ) === count( $list ) ) {
		return false;
	}
	$keep ? $order->update_meta_data( GWNOT_META, $keep ) : $order->delete_meta_data( GWNOT_META );
	$order->save();
	return true;
}

/**
 * Mark an order shipped: Completed (fires the completed email, which carries the tracking).
 * If it is already Completed, re-sends the completed email when $notify is true.
 */
function gwnot_mark_shipped( $order, $notify = true ) {
	$order = wc_get_order( $order instanceof WC_Order ? $order->get_id() : $order ); // fresh copy with the new meta
	if ( ! $order ) {
		return false;
	}
	if ( ! $order->has_status( 'completed' ) ) {
		$order->update_status( 'completed', __( 'Order shipped.', 'gwnd-fulfillment' ) );
		return true;
	}
	if ( $notify ) {
		$mails = WC()->mailer()->get_emails();
		if ( isset( $mails['WC_Email_Customer_Completed_Order'] ) ) {
			$mails['WC_Email_Customer_Completed_Order']->trigger( $order->get_id(), $order );
			$order->add_order_note( __( 'Shipping email with tracking re-sent to the customer.', 'gwnd-fulfillment' ) );
		}
	}
	return true;
}

/** Private order status URL (works logged out — protected by the order key). */
function gwnot_status_url( $order ) {
	$id = $order->get_id();
	if ( get_option( 'permalink_structure' ) ) {
		$url = home_url( user_trailingslashit( gwnot_slug() . '/' . $id ) );
	} else {
		$url = add_query_arg( 'gwnot', $id, home_url( '/' ) );
	}
	return add_query_arg( 'key', $order->get_order_key(), $url );
}

function gwnot_lookup_url() {
	return get_option( 'permalink_structure' ) ? home_url( user_trailingslashit( gwnot_slug() ) ) : add_query_arg( 'gwnot', 'lookup', home_url( '/' ) );
}

/** Can the current visitor see this order? */
function gwnot_can_view( $order, $key = '' ) {
	if ( ! $order instanceof WC_Order ) {
		return false;
	}
	if ( $key && hash_equals( $order->get_order_key(), (string) $key ) ) {
		return true;
	}
	$uid = get_current_user_id();
	if ( $uid && (int) $order->get_customer_id() === $uid ) {
		return true;
	}
	return current_user_can( 'manage_woocommerce' );
}

function gwnot_date( $ts ) {
	return $ts ? wp_date( get_option( 'date_format' ), $ts ) : '';
}

/* ---------- Rewrite: /order-status/ and /order-status/{id}/ ---------- */
add_action( 'init', function () {
	$slug = preg_quote( gwnot_slug(), '#' );
	add_rewrite_rule( '^' . $slug . '/?$', 'index.php?gwnot=lookup', 'top' );
	add_rewrite_rule( '^' . $slug . '/([0-9]+)/?$', 'index.php?gwnot=$matches[1]', 'top' );
	$sig = gwnot_slug() . '|' . GWNOT_VERSION;
	if ( get_option( 'gwnot_rewrite' ) !== $sig ) {
		flush_rewrite_rules( false );
		update_option( 'gwnot_rewrite', $sig, true );
	}
}, 20 );
add_filter( 'query_vars', function ( $v ) {
	$v[] = 'gwnot';
	return $v;
} );
