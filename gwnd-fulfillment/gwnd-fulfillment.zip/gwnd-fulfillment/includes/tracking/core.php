<?php
/**
 * Data model + helpers. Shipments live in order meta `_gwnot_shipments`:
 * [ [id, carrier, carrier_name, number, url, date], … ]
 */
defined( 'ABSPATH' ) || exit;

const GWNOT_META = '_gwnot_shipments';

function gwnot_slug() {
	return trim( (string) apply_filters( 'gwnot_slug', 'order-status' ), '/' );
}

/** Carriers: key => [name, url]. {n} is replaced by the tracking number. */
function gwnot_carriers() {
	return apply_filters( 'gwnot_carriers', array(
		'canada-post' => array( 'name' => 'Canada Post', 'url' => 'https://www.canadapost-postescanada.ca/track-reperage/en#/search?searchFor={n}' ),
		'purolator'   => array( 'name' => 'Purolator', 'url' => 'https://www.purolator.com/en/shipping/tracker?pin={n}' ),
		'ups'         => array( 'name' => 'UPS', 'url' => 'https://www.ups.com/track?loc=en_CA&tracknum={n}' ),
		'fedex'       => array( 'name' => 'FedEx', 'url' => 'https://www.fedex.com/fedextrack/?trknbr={n}' ),
		'canpar'      => array( 'name' => 'Canpar', 'url' => 'https://www.canpar.com/en/tracking/delivery_options.htm?barcode={n}' ),
		'chit-chats'  => array( 'name' => 'Chit Chats', 'url' => 'https://chitchats.com/tracking/{n}' ),
		'other'       => array( 'name' => 'Other carrier', 'url' => '' ),
	) );
}

/** Raw shipments stored on an order. */
function gwnot_shipments( $order ) {
	if ( ! $order instanceof WC_Order ) {
		return array();
	}
	$s = $order->get_meta( GWNOT_META, true );
	return is_array( $s ) ? array_values( $s ) : array();
}

/** A shipment ready for display: carrier name, number, tracking url, date. */
function gwnot_view( $s ) {
	$c   = gwnot_carriers();
	$key = $s['carrier'] ?? 'other';
	$name = ( 'other' === $key || ! isset( $c[ $key ] ) ) ? ( ! empty( $s['carrier_name'] ) ? $s['carrier_name'] : 'Carrier' ) : $c[ $key ]['name'];
	$url  = ! empty( $s['url'] ) ? $s['url'] : '';
	if ( ! $url && ! empty( $c[ $key ]['url'] ) ) {
		$url = str_replace( '{n}', rawurlencode( $s['number'] ), $c[ $key ]['url'] );
	}
	return array(
		'id'      => $s['id'] ?? '',
		'carrier' => $name,
		'number'  => $s['number'] ?? '',
		'url'     => $url,
		'date'    => (int) ( $s['date'] ?? 0 ),
		'live'    => function_exists( 'gwnot_live_view' ) ? gwnot_live_view( $s ) : array(),
	);
}

function gwnot_views( $order ) {
	return array_map( 'gwnot_view', gwnot_shipments( $order ) );
}

/**
 * Public API: add a tracking number to an order. Returns the stored shipment or WP_Error.
 * Does not change the order status (see gwnot_mark_shipped()).
 */
function gwnot_add_shipment( $order, $carrier, $number, $args = array() ) {
	$order  = $order instanceof WC_Order ? $order : wc_get_order( $order );
	$number = gwnot_clean_number( sanitize_text_field( (string) $number ) );
	if ( ! $order ) {
		return new WP_Error( 'gwnot_order', 'Order not found.' );
	}
	if ( '' === $number ) {
		return new WP_Error( 'gwnot_number', 'Tracking number is empty.' );
	}
	$carrier = sanitize_key( (string) $carrier );
	if ( '' === $carrier || 'auto' === $carrier ) {
		$carrier = gwnot_detect_carrier( $number ) ?: 'other';
	}
	if ( ! isset( gwnot_carriers()[ $carrier ] ) ) {
		$args['carrier_name'] = $args['carrier_name'] ?? $carrier;
		$carrier              = 'other';
	}
	$list = gwnot_shipments( $order );
	foreach ( $list as $s ) {
		if ( $s['number'] === $number ) {
			return new WP_Error( 'gwnot_dupe', 'That tracking number is already on this order.' );
		}
	}
	$ship = array(
		'id'           => strtolower( wp_generate_password( 8, false ) ),
		'carrier'      => $carrier,
		'carrier_name' => 'other' === $carrier ? sanitize_text_field( $args['carrier_name'] ?? '' ) : '',
		'number'       => $number,
		'url'          => 'other' === $carrier ? esc_url_raw( $args['url'] ?? '' ) : '',
		'date'         => ! empty( $args['date'] ) ? (int) $args['date'] : time(),
		'source'       => sanitize_key( $args['source'] ?? 'manual' ),
	);
	$list[] = $ship;
	$order->update_meta_data( GWNOT_META, $list );
	$v = gwnot_view( $ship );
	$order->add_order_note( sprintf( 'Tracking added: %1$s %2$s%3$s', $v['carrier'], $v['number'], 'import' === $ship['source'] ? ' (imported)' : '' ) );
	$order->save();
	update_option( 'gwnot_last_carrier', $carrier, false );
	do_action( 'gwnot_shipment_added', $order, $ship );
	return $ship;
}

function gwnot_remove_shipment( $order, $id ) {
	$list = gwnot_shipments( $order );
	$keep = array();
	foreach ( $list as $s ) {
		if ( ( $s['id'] ?? '' ) === $id ) {
			$v = gwnot_view( $s );
			$order->add_order_note( sprintf( 'Tracking removed: %1$s %2$s', $v['carrier'], $v['number'] ) );
			continue;
		}
		$keep[] = $s;
	}
	if ( count( $keep ) === count( $list ) ) {
		return false;
	}
	$keep ? $order->update_meta_data( GWNOT_META, $keep ) : $order->delete_meta_data( GWNOT_META );
	$order->save();
	return true;
}

/**
 * Mark an order shipped: Completed (fires the completed email, which carries the tracking).
 * If it is already Completed, re-sends the completed email when $notify is true.
 */
function gwnot_mark_shipped( $order, $notify = true ) {
	$order = wc_get_order( $order instanceof WC_Order ? $order->get_id() : $order ); // fresh copy with the new meta
	if ( ! $order ) {
		return false;
	}
	if ( ! $order->has_status( 'completed' ) ) {
		$order->update_status( 'completed', 'Order shipped.' );
		return true;
	}
	if ( $notify ) {
		$mails = WC()->mailer()->get_emails();
		if ( isset( $mails['WC_Email_Customer_Completed_Order'] ) ) {
			$mails['WC_Email_Customer_Completed_Order']->trigger( $order->get_id(), $order );
			$order->add_order_note( 'Shipping email with tracking re-sent to the customer.' );
		}
	}
	return true;
}

/** Private order status URL (works logged out — protected by the order key). */
function gwnot_status_url( $order ) {
	$id = $order->get_id();
	if ( get_option( 'permalink_structure' ) ) {
		$url = home_url( user_trailingslashit( gwnot_slug() . '/' . $id ) );
	} else {
		$url = add_query_arg( 'gwnot', $id, home_url( '/' ) );
	}
	return add_query_arg( 'key', $order->get_order_key(), $url );
}

function gwnot_lookup_url() {
	return get_option( 'permalink_structure' ) ? home_url( user_trailingslashit( gwnot_slug() ) ) : add_query_arg( 'gwnot', 'lookup', home_url( '/' ) );
}

/** Can the current visitor see this order? */
function gwnot_can_view( $order, $key = '' ) {
	if ( ! $order instanceof WC_Order ) {
		return false;
	}
	if ( $key && hash_equals( $order->get_order_key(), (string) $key ) ) {
		return true;
	}
	$uid = get_current_user_id();
	if ( $uid && (int) $order->get_customer_id() === $uid ) {
		return true;
	}
	return current_user_can( 'manage_woocommerce' );
}

function gwnot_date( $ts ) {
	return $ts ? wp_date( get_option( 'date_format' ), $ts ) : '';
}

/* ---------- Rewrite: /order-status/ and /order-status/{id}/ ---------- */
add_action( 'init', function () {
	$slug = preg_quote( gwnot_slug(), '#' );
	add_rewrite_rule( '^' . $slug . '/?$', 'index.php?gwnot=lookup', 'top' );
	add_rewrite_rule( '^' . $slug . '/([0-9]+)/?$', 'index.php?gwnot=$matches[1]', 'top' );
	$sig = gwnot_slug() . '|' . GWNOT_VERSION;
	if ( get_option( 'gwnot_rewrite' ) !== $sig ) {
		flush_rewrite_rules( false );
		update_option( 'gwnot_rewrite', $sig, true );
	}
}, 20 );
add_filter( 'query_vars', function ( $v ) {
	$v[] = 'gwnot';
	return $v;
} );
