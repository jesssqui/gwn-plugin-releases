<?php
/**
 * Front end: the order status page (/order-status/{id}/?key=…), the order lookup form (/order-status/),
 * tracking on My Account → View order, and a "Track" action in the My Account orders list.
 */
defined( 'ABSPATH' ) || exit;

function gwnot_is_page() {
	return '' !== (string) get_query_var( 'gwnot' );
}

function gwnot_btn( $variant = 'primary' ) {
	return trim( 'ot-btn ot-btn--' . $variant . ' ' . apply_filters( 'gwnot_button_class', '', $variant ) );
}

function gwnot_help_email() {
	return (string) apply_filters( 'gwnot_help_email', get_option( 'woocommerce_email_from_address', get_option( 'admin_email' ) ) );
}

/** Headline + lead for an order. */
function gwnot_status_copy( $order ) {
	$views = gwnot_views( $order );
	switch ( $order->get_status() ) {
		case 'pending':
		case 'on-hold':
			$c = array( gwnf_w( 'head_waiting' ), gwnf_w( 'lead_waiting' ) );
			break;
		case 'processing':
			$c = array( gwnf_w( 'head_processing' ), gwnf_w( 'lead_processing' ) );
			break;
		case 'completed':
			$live     = function_exists( 'gwnot_live_order_status' ) ? gwnot_live_order_status( $order ) : '';
			$livecopy = (array) apply_filters( 'gwnot_live_copy', array(), $order );
			if ( isset( $livecopy[ $live ] ) ) {
				$c = $livecopy[ $live ];
				break;
			}
			$c = $views
				? array( gwnf_w( 'head_shipped' ), gwnf_w( 'lead_shipped', array( 'date' => gwnot_date( $views[ count( $views ) - 1 ]['date'] ) ) ) )
				: array( gwnf_w( 'head_complete' ), gwnf_w( 'lead_complete' ) );
			break;
		case 'cancelled':
			$c = array( gwnf_w( 'head_cancelled' ), gwnf_w( 'lead_cancelled' ) );
			break;
		case 'refunded':
			$c = array( __( 'Order refunded', 'gwnd-fulfillment' ), __( 'This order has been refunded.', 'gwnd-fulfillment' ) );
			break;
		case 'failed':
			$c = array( __( 'Payment didn\'t go through', 'gwnd-fulfillment' ), __( 'This order wasn\'t paid. You can try again or place a new order.', 'gwnd-fulfillment' ) );
			break;
		default:
			$c = array( wc_get_order_status_name( $order->get_status() ), '' );
	}
	return apply_filters( 'gwnot_status_copy', array( 'title' => $c[0], 'lead' => $c[1] ), $order );
}

/** Progress steps: [label, date, state] where state is done|current|todo. */
function gwnot_steps( $order ) {
	$status  = $order->get_status();
	$views   = gwnot_views( $order );
	$paid    = $order->get_date_paid() ? $order->get_date_paid()->getTimestamp() : 0;
	$shipped = $views ? $views[0]['date'] : ( $order->get_date_completed() ? $order->get_date_completed()->getTimestamp() : 0 );
	$is_paid = $paid || in_array( $status, array( 'processing', 'completed' ), true );
	$is_ship = 'completed' === $status;
	$steps   = array(
		array( gwnf_w( 'step_placed' ), gwnot_date( $order->get_date_created() ? $order->get_date_created()->getTimestamp() : 0 ), 'done' ),
		array( $is_paid ? gwnf_w( 'step_paid' ) : gwnf_w( 'step_waiting' ), $is_paid ? gwnot_date( $paid ) : '', $is_paid ? 'done' : 'current' ),
		array( $is_ship ? gwnf_w( 'step_shipped' ) : gwnf_w( 'step_packing' ), $is_ship ? gwnot_date( $shipped ) : ( $is_paid ? gwnf_w( 'step_ships_in' ) : '' ), $is_ship ? 'done' : ( $is_paid ? 'current' : 'todo' ) ),
		array( gwnf_w( 'step_onway' ), $is_ship && $views ? __( 'Track below', 'gwnd-fulfillment' ) : '', $is_ship ? 'current' : 'todo' ),
	);
	return apply_filters( 'gwnot_steps', $steps, $order );
}

/* ---------- Page chrome: classic themes use header.php/footer.php; block themes (Twenty Twenty-Four etc.) need their template parts ---------- */
function gwnot_is_block_theme() {
	return (bool) apply_filters( 'gwnot_is_block_theme', function_exists( 'wp_is_block_theme' ) && wp_is_block_theme() );
}
function gwnot_block_part( $area ) {
	ob_start();
	block_template_part( $area );
	return (string) ob_get_clean();
}
function gwnot_get_header() {
	if ( ! gwnot_is_block_theme() ) {
		get_header();
		return;
	}
	// Render the parts before wp_head() so the styles their blocks need are enqueued in time.
	$header                        = gwnot_block_part( 'header' );
	$GLOBALS['gwnot_block_footer'] = gwnot_block_part( 'footer' );
	?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class( 'ot-page' ); ?>>
<?php wp_body_open(); ?>
<div class="wp-site-blocks">
<?php
	echo $header; // phpcs:ignore WordPress.Security.EscapeOutput -- rendered block markup
	echo '<div class="wp-block-group has-global-padding is-layout-constrained">';
}
function gwnot_get_footer() {
	if ( ! gwnot_is_block_theme() ) {
		get_footer();
		return;
	}
	echo '</div>';
	echo $GLOBALS['gwnot_block_footer'] ?? ''; // phpcs:ignore WordPress.Security.EscapeOutput
	echo "</div>\n";
	wp_footer();
	echo "</body>\n</html>\n";
}

/* ---------- Routing ---------- */
add_action( 'template_redirect', function () {
	if ( ! gwnot_is_page() ) {
		return;
	}
	nocache_headers();
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}
	do_action( 'litespeed_control_set_nocache', 'order status page' );
	header( 'X-Robots-Tag: noindex, nofollow' );
	header( 'Referrer-Policy: no-referrer' ); // the URL carries the order key — don't leak it to carrier sites

	// Lookup form submit.
	if ( 'POST' === sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ?? '' ) ) && isset( $_POST['gwnot_lookup'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified in gwnot_handle_lookup()
		$GLOBALS['gwnot_error'] = gwnot_handle_lookup();
	}
	status_header( 200 );
	// Not the home page: stop themes and menus treating it as one (body classes, aria-current, home-only styles).
	$GLOBALS['wp_query']->is_home = false;
	add_filter( 'body_class', function ( $c ) {
		return array_values( array_diff( $c, array( 'home', 'blog' ) ) );
	} );
	$tpl = locate_template( 'gwn-order-tracking/order-status.php' ) ?: GWNOT_DIR . 'templates/order-status.php';
	$q   = get_query_var( 'gwnot' );
	$key = isset( $_GET['key'] ) ? sanitize_text_field( wp_unslash( $_GET['key'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- the order key is the access check (gwnot_can_view), like WooCommerce's order-received link
	$order = ( 'lookup' !== $q && ctype_digit( (string) $q ) ) ? wc_get_order( (int) $q ) : null;
	if ( $order && ( ! gwnot_can_view( $order, $key ) || 'shop_order' !== $order->get_type() ) ) {
		if ( ! isset( $GLOBALS['gwnot_error'] ) && ( $key || ! is_user_logged_in() ) ) {
			$GLOBALS['gwnot_error'] = $key ? __( 'That order link isn\'t valid. Look your order up below.', 'gwnd-fulfillment' ) : '';
		}
		$order = null;
	}
	$GLOBALS['gwnot_order'] = $order;
	include $tpl;
	exit;
}, 5 );

function gwnot_handle_lookup() {
	if ( empty( $_POST['gwnot_lnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['gwnot_lnonce'] ) ), 'gwnot_lookup' ) ) {
		return __( 'Your session expired. Please try again.', 'gwnd-fulfillment' );
	}
	// Real visitor IP behind CDNs/proxies (Hostinger hCDN, Cloudflare) — otherwise every shopper shares the CDN's IP and one limit.
	$ip   = (string) apply_filters( 'gwnot_lookup_ip', class_exists( 'WC_Geolocation' ) ? WC_Geolocation::get_ip_address() : sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ?? '' ) ) );
	$ip   = preg_replace( '/[^0-9a-f:.]/i', '', (string) $ip );
	$tk   = 'gwnot_lk_' . md5( $ip );
	$hits = (int) get_transient( $tk );
	// A site-wide cap on failed lookups too: the per-visitor limit uses the IP that proxies and CDNs pass
	// along, which a visitor can fake, so this is what stops someone stepping through order numbers.
	$all  = (int) get_transient( 'gwnot_lk_all' );
	$cap  = (int) apply_filters( 'gwnot_lookup_failure_cap', 30 );
	if ( $hits >= 10 || $all >= $cap ) {
		return __( 'Too many tries. Please wait 15 minutes and try again.', 'gwnd-fulfillment' );
	}
	set_transient( $tk, $hits + 1, 15 * MINUTE_IN_SECONDS );
	set_transient( 'gwnot_lk_all', $all + 1, 15 * MINUTE_IN_SECONDS );
	$num   = ltrim( sanitize_text_field( wp_unslash( $_POST['gwnot_order'] ?? '' ) ), '#' );
	$email = strtolower( sanitize_email( wp_unslash( $_POST['gwnot_email'] ?? '' ) ) );
	$id    = (int) apply_filters( 'woocommerce_shortcode_order_tracking_order_id', $num ); // same hook WooCommerce's tracking form uses (custom order numbers)
	$order = $id ? wc_get_order( $id ) : null;
	if ( $order && 'shop_order' === $order->get_type() && $email && strtolower( $order->get_billing_email() ) === $email ) {
		delete_transient( $tk );
		set_transient( 'gwnot_lk_all', max( 0, $all ), 15 * MINUTE_IN_SECONDS ); // a successful lookup doesn't count against the site-wide cap
		wp_safe_redirect( gwnot_status_url( $order ) );
		exit;
	}
	return __( 'We couldn\'t find an order with that number and email. Check your order confirmation email and try again.', 'gwnd-fulfillment' );
}

add_filter( 'document_title_parts', function ( $t ) {
	if ( gwnot_is_page() ) {
		/* translators: %s: order number */
		$t['title'] = ! empty( $GLOBALS['gwnot_order'] ) ? sprintf( __( 'Order #%s', 'gwnd-fulfillment' ), $GLOBALS['gwnot_order']->get_order_number() ) : __( 'Order status', 'gwnd-fulfillment' );
	}
	return $t;
} );
add_filter( 'wp_robots', function ( $r ) {
	if ( gwnot_is_page() ) {
		$r['noindex']  = true;
		$r['nofollow'] = true;
	}
	return $r;
} );
add_filter( 'body_class', function ( $c ) {
	if ( gwnot_is_page() ) {
		$c[] = 'ot-page';
	}
	return $c;
} );
add_action( 'wp_head', function () {
	if ( gwnot_is_page() ) {
		echo '<meta name="referrer" content="no-referrer">' . "\n";
	}
}, 6 );

/* ---------- Shared bits ---------- */
function gwnot_shipments_html( $order ) {
	$views = gwnot_views( $order );
	if ( ! $views ) {
		return '';
	}
	$h = '<div class="ot-ships">';
	foreach ( $views as $v ) {
		$h .= '<div class="ot-ship"><div class="ot-ship__info">';
		/* translators: 1: carrier, 2: date */
		$h .= '<p class="ot-ship__k">' . esc_html( sprintf( __( '%1$s · shipped %2$s', 'gwnd-fulfillment' ), $v['carrier'], gwnot_date( $v['date'] ) ) ) . '</p>';
		$h .= '<p class="ot-ship__num"><span>' . esc_html( $v['number'] ) . '</span> <button type="button" class="ot-copy" data-copy="' . esc_attr( $v['number'] ) . '">' . esc_html__( 'Copy', 'gwnd-fulfillment' ) . '</button></p>';
		$h .= '</div>';
		if ( $v['url'] ) {
			$h .= '<a class="' . esc_attr( gwnot_btn( 'primary' ) ) . '" href="' . esc_url( $v['url'] ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( gwnf_w( 'track_button' ) ) . ' <span aria-hidden="true">↗</span></a>';
		}
		$h .= '</div>';
	}
	return $h . '</div>';
}

/** Kept for themes that call it; the copy script is now enqueued (assets/js/status.js). */
function gwnot_copy_js() {
	return '';
}

/* ---------- My Account ---------- */
add_action( 'woocommerce_view_order', function ( $order_id ) {
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return;
	}
	$look = gwnf_look_on( 'account' ) && function_exists( 'gwnf_look_classes' );
	$link = 'yes' === gwnf_flow( 'account_link' );
	if ( ! gwnot_views( $order ) && ! $link ) {
		return;
	}
	echo '<section class="ot-account' . ( $look ? ' ' . esc_attr( gwnf_look_classes() ) : '' ) . '"' . ( $look && gwnf_look_vars() ? ' style="' . esc_attr( gwnf_look_vars() ) . '"' : '' ) . '>';
	if ( gwnot_views( $order ) ) {
		echo '<h2 class="ot-account__title">' . esc_html( gwnf_w( 'tracking_title' ) ) . '</h2>' . gwnot_shipments_html( $order ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped inside
	}
	if ( $link ) {
		echo '<p class="ot-account__link"><a href="' . esc_url( gwnot_status_url( $order ) ) . '">' . esc_html( gwnf_w( 'account_link' ) ) . ' <span aria-hidden="true">→</span></a></p>';
	}
	echo '</section>';
}, 5 );

/* "Track" in the My account orders list only (the order page already has its own Track package button). */
add_filter( 'woocommerce_my_account_my_orders_actions', function ( $actions, $order ) {
	if ( 'yes' !== gwnf_flow( 'list_action' ) || ( function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url( 'view-order' ) ) ) {
		return $actions;
	}
	if ( gwnot_views( $order ) ) {
		$actions = array( 'ot-track' => array( 'url' => gwnot_status_url( $order ), 'name' => __( 'Track', 'gwnd-fulfillment' ) ) ) + $actions;
	}
	return $actions;
}, 10, 2 );

/** Kept for themes that call it: the styles now live in assets/css/status.css. */
function gwnot_css() {
	return '';
}
