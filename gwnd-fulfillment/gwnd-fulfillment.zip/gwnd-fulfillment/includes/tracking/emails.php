<?php
/**
 * Customer emails: tracking panel + "View your order" button.
 *  - customer_completed_order: tracking (carrier, number, Track package) + order status button.
 *  - customer_processing_order: a small "check your order status anytime" link.
 * Email-safe: tables + inline-able CSS, colours from WooCommerce → Settings → Emails.
 */
defined( 'ABSPATH' ) || exit;

function gwnot_mail_colors() {
	$base = get_option( 'woocommerce_email_base_color', '#7f54b3' );
	$text = get_option( 'woocommerce_email_text_color', '#3c3c3c' );
	return array( 'base' => $base, 'on_base' => wc_light_or_dark( $base, '#000000', '#ffffff' ), 'text' => $text );
}

/** Bulletproof button. */
function gwnot_mail_button( $url, $label, $class = 'ot-mail-btn' ) {
	return '<table role="presentation" cellpadding="0" cellspacing="0" border="0" class="ot-mail-btnwrap"><tr><td class="' . esc_attr( $class ) . '"><a href="' . esc_url( $url ) . '" target="_blank">' . esc_html( $label ) . '</a></td></tr></table>';
}

function gwnot_mail_panel( $order ) {
	$views = gwnot_views( $order );
	$h  = '<table class="ot-mail" role="presentation" cellpadding="0" cellspacing="0" width="100%">';
	if ( $views ) {
		$h .= '<tr><td class="ot-mail__head"><p class="ot-mail__kicker">' . esc_html( count( $views ) > 1 ? __( 'Your packages', 'gwnd-fulfillment' ) : __( 'Your package', 'gwnd-fulfillment' ) ) . '</p><p class="ot-mail__title">' . esc_html( gwnf_w( 'mail_box_title' ) ) . '</p></td></tr>';
		foreach ( $views as $v ) {
			$h .= '<tr><td class="ot-mail__row">';
			/* translators: %s: carrier name */
			$h .= '<p class="ot-mail__k">' . esc_html( sprintf( __( '%s tracking number', 'gwnd-fulfillment' ), $v['carrier'] ) ) . '</p>';
			$h .= '<p class="ot-mail__num">' . esc_html( $v['number'] ) . '</p>';
			if ( $v['url'] ) {
				$h .= gwnot_mail_button( $v['url'], gwnf_w( 'track_button' ) );
			}
			$h .= '</td></tr>';
		}
		$h .= '<tr><td class="ot-mail__foot"><p>' . esc_html( gwnf_w( 'mail_note' ) ) . '</p>';
	} else {
		$h .= '<tr><td class="ot-mail__foot"><p>' . esc_html__( 'See your order details anytime:', 'gwnd-fulfillment' ) . '</p>';
	}
	$h .= gwnot_mail_button( gwnot_status_url( $order ), gwnf_w( 'mail_view_button' ), 'ot-mail-btn ot-mail-btn--alt' ) . '</td></tr></table>';
	return $h;
}

function gwnot_mail_panel_plain( $order ) {
	$t = "\n";
	foreach ( gwnot_views( $order ) as $v ) {
		/* translators: %s: carrier name */
		$t .= sprintf( __( '%s tracking number', 'gwnd-fulfillment' ), $v['carrier'] ) . ': ' . $v['number'] . "\n";
		if ( $v['url'] ) {
			$t .= gwnf_w( 'track_button' ) . ': ' . $v['url'] . "\n";
		}
		$t .= "\n";
	}
	return $t . gwnf_w( 'mail_view_button' ) . ': ' . gwnot_status_url( $order ) . "\n\n";
}

add_action( 'woocommerce_email_before_order_table', function ( $order, $sent_to_admin, $plain, $email = null ) {
	if ( $sent_to_admin || ! $order instanceof WC_Order || ! $email ) {
		return;
	}
	$fresh = wc_get_order( $order->get_id() ) ?: $order; // tracking may have been saved on another copy of the order
	if ( 'customer_completed_order' === $email->id ) {
		echo $plain ? gwnot_mail_panel_plain( $fresh ) : gwnot_mail_panel( $fresh ); // phpcs:ignore
	} elseif ( 'customer_processing_order' === $email->id ) {
		$url = gwnot_status_url( $fresh );
		echo $plain ? "\n" . gwnf_w( 'mail_processing' ) . ' ' . $url . "\n\n" : '<p class="ot-mail-line">' . esc_html( gwnf_w( 'mail_processing' ) ) . '</p>' . gwnot_mail_button( $url, gwnf_w( 'mail_view_button' ), 'ot-mail-btn ot-mail-btn--alt' ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped above
	}
}, 8, 4 );

/* Shipped wording when tracking exists — only when the store kept WooCommerce's default subject/heading. */
add_filter( 'woocommerce_email_subject_customer_completed_order', function ( $subject, $order, $email = null ) {
	if ( ! $order instanceof WC_Order || ! gwnot_views( wc_get_order( $order->get_id() ) ) || ( $email && $email->get_option( 'subject' ) ) ) {
		return $subject;
	}
	return gwnf_w( 'mail_subject', array( 'site' => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ), 'order' => $order->get_order_number() ) );
}, 20, 3 );
add_filter( 'woocommerce_email_heading_customer_completed_order', function ( $heading, $order, $email = null ) {
	if ( ! $order instanceof WC_Order || ! gwnot_views( wc_get_order( $order->get_id() ) ) || ( $email && $email->get_option( 'heading' ) ) ) {
		return $heading;
	}
	return gwnf_w( 'mail_heading' );
}, 20, 3 );

add_filter( 'woocommerce_email_styles', function ( $css ) {
	$c = gwnot_mail_colors();
	return $css . "
#body_content_inner .ot-mail { border: 2px solid {$c['text']} !important; border-radius: 16px !important; border-collapse: separate !important; margin: 6px 0 26px !important; overflow: hidden; }
#body_content_inner .ot-mail__head { background-color: {$c['base']} !important; padding: 18px 22px !important; }
#body_content_inner .ot-mail__kicker { margin: 0 0 4px !important; font-size: 11px !important; font-weight: bold !important; letter-spacing: 1px; text-transform: uppercase; color: {$c['on_base']} !important; }
#body_content_inner .ot-mail__title { margin: 0 !important; font-size: 21px !important; font-weight: 800 !important; line-height: 1.2 !important; color: {$c['on_base']} !important; }
#body_content_inner .ot-mail__row { background-color: #ffffff !important; padding: 16px 22px !important; border-bottom: 1px solid #e7e7ec !important; }
#body_content_inner .ot-mail__k { margin: 0 0 2px !important; font-size: 11px !important; font-weight: bold !important; text-transform: uppercase; letter-spacing: 1px; color: {$c['text']} !important; }
#body_content_inner .ot-mail__num { margin: 0 0 12px !important; font-size: 19px !important; font-weight: bold !important; letter-spacing: .5px; color: {$c['text']} !important; word-break: break-all; }
#body_content_inner .ot-mail__foot { background-color: #ffffff !important; padding: 16px 22px 20px !important; }
#body_content_inner .ot-mail__foot p { margin: 0 0 12px !important; font-size: 14px !important; color: {$c['text']} !important; }
#body_content_inner .ot-mail-btnwrap { border-collapse: separate !important; margin: 0 !important; }
#body_content_inner .ot-mail-btn { background-color: {$c['base']} !important; border-radius: 999px !important; padding: 0 !important; }
#body_content_inner .ot-mail-btn a { display: inline-block; padding: 12px 24px !important; color: {$c['on_base']} !important; font-weight: bold !important; font-size: 15px !important; text-decoration: none !important; }
#body_content_inner .ot-mail-btn--alt { background-color: #ffffff !important; border: 2px solid {$c['text']} !important; }
#body_content_inner .ot-mail-btn--alt a { color: {$c['text']} !important; padding: 10px 22px !important; }
#body_content_inner .ot-mail-line { font-size: 14px !important; margin: 0 0 20px !important; }
";
}, 15 );

/*
 * Shipped email: swap WooCommerce's "We have finished processing your order." for the store's own line,
 * only while a completed email for an order with tracking is being written.
 */
add_action( 'woocommerce_email_header', function ( $heading, $email = null ) {
	$GLOBALS['gwnot_mail_intro'] = $email && 'customer_completed_order' === $email->id && $email->object instanceof WC_Order && gwnot_views( wc_get_order( $email->object->get_id() ) );
}, 1, 2 );
add_action( 'woocommerce_email_footer', function () {
	$GLOBALS['gwnot_mail_intro'] = false;
}, 99 );
add_filter( 'gettext_woocommerce', function ( $t, $text ) {
	if ( ! empty( $GLOBALS['gwnot_mail_intro'] ) && 'We have finished processing your order.' === $text ) {
		return gwnf_w( 'mail_shipped_intro' );
	}
	return $t;
}, 10, 2 );
