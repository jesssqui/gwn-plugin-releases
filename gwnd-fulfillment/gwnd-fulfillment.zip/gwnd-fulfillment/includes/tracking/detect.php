<?php
/**
 * Work out the carrier from a tracking number, so scanning or pasting a label barcode is enough.
 * Returns a carrier key from gwnot_carriers() or '' when the number doesn't clearly belong to one.
 * Filter: gwnot_detect_carrier (string $carrier, string $number).
 */
defined( 'ABSPATH' ) || exit;

function gwnot_clean_number( $number ) {
	return strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) $number ) );
}

/** Rules as [carrier, regex]; first match wins. Shared with the order screen's JavaScript. */
function gwnot_detect_rules() {
	return apply_filters( 'gwnot_detect_rules', array(
		array( 'ups', '^1Z[0-9A-Z]{16}$' ),                 // UPS: 1Z + 16
		array( 'canada-post', '^[A-Z]{2}[0-9]{9}CA$' ),     // Canada Post international (UPU S10, e.g. LM123456789CA)
		array( 'canada-post', '^[0-9]{16}$' ),              // Canada Post domestic PIN (e.g. 7023 2100 3941 4604)
		array( 'canpar', '^D[0-9]{19,21}$' ),               // Canpar barcode
		array( 'purolator', '^[A-Z]{3}[0-9]{9}$' ),         // Purolator PIN with letter prefix
		array( 'purolator', '^[0-9]{12}$' ),                // Purolator 12-digit PIN (FedEx also uses 12 digits — Purolator is far more common in Canada)
		array( 'fedex', '^([0-9]{15}|[0-9]{20}|[0-9]{22})$' ),
	) );
}

function gwnot_detect_carrier( $number ) {
	$n     = gwnot_clean_number( $number );
	$found = '';
	foreach ( gwnot_detect_rules() as $r ) {
		if ( preg_match( '/' . $r[1] . '/', $n ) && isset( gwnot_carriers()[ $r[0] ] ) ) {
			$found = $r[0];
			break;
		}
	}
	return (string) apply_filters( 'gwnot_detect_carrier', $found, $n );
}
