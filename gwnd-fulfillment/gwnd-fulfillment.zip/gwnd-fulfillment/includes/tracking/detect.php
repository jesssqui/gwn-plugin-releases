<?php
/**
 * Work out the carrier from a tracking number, so scanning or pasting a label barcode is enough.
 * Returns a carrier key from gwnot_carriers() or '' when the number doesn't clearly belong to one.
 * Filter: gwnot_detect_carrier (string $carrier, string $number).
 */
defined( 'ABSPATH' ) || exit;

function gwnot_clean_number( $number ) {
	return strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) $number ) );
}

/**
 * Rules as [carrier, regex]; first match among the carriers the store offers wins (so a 12-digit number is
 * Purolator for a Canadian store and FedEx for an American one). Shared with the order screen's JavaScript.
 */
function gwnot_detect_rules() {
	$rules = array(
		array( 'ups', '^1Z[0-9A-Z]{16}$' ),                       // UPS: 1Z + 16
		// International postal items (UPU S10, e.g. LM123456789CA): the last two letters are the posting country.
		array( 'canada-post', '^[A-Z]{2}[0-9]{9}CA$' ),
		array( 'usps', '^[A-Z]{2}[0-9]{9}US$' ),
		array( 'royal-mail', '^[A-Z]{2}[0-9]{9}GB$' ),
		array( 'an-post', '^[A-Z]{2}[0-9]{9}IE$' ),
		array( 'australia-post', '^[A-Z]{2}[0-9]{9}AU$' ),
		array( 'nz-post', '^[A-Z]{2}[0-9]{9}NZ$' ),
		array( 'deutsche-post', '^[A-Z]{2}[0-9]{9}DE$' ),
		array( 'colissimo', '^[A-Z]{2}[0-9]{9}FR$' ),
		array( 'postnl', '^[A-Z]{2}[0-9]{9}NL$' ),
		array( 'bpost', '^[A-Z]{2}[0-9]{9}BE$' ),
		array( 'correos', '^[A-Z]{2}[0-9]{9}ES$' ),
		array( 'poste-italiane', '^[A-Z]{2}[0-9]{9}IT$' ),
		array( 'postnord', '^[A-Z]{2}[0-9]{9}(SE|DK|NO|FI)$' ),
		// Domestic formats.
		array( 'usps', '^9[2-5][0-9]{20}$' ),                      // USPS 22-digit (starts 92–95)
		array( 'usps', '^420[0-9]{5}9[2-5][0-9]{20}$' ),           // USPS with the ZIP prefix from the barcode
		array( 'canada-post', '^[0-9]{16}$' ),                     // Canada Post domestic PIN
		array( 'canpar', '^D[0-9]{19,21}$' ),                      // Canpar barcode
		array( 'purolator', '^[A-Z]{3}[0-9]{9}$' ),                // Purolator PIN with letter prefix
		array( 'purolator', '^[0-9]{12}$' ),                       // Purolator 12-digit PIN (Canada)
		array( 'fedex', '^([0-9]{12}|[0-9]{15}|[0-9]{20}|[0-9]{22})$' ),
		array( 'dhl', '^(JJD|JVGL|JD)[0-9A-Z]{8,24}$' ),           // DHL Parcel / eCommerce
		array( 'dhl', '^[0-9]{10}$' ),                             // DHL Express waybill
		array( 'ontrac', '^(C|D)[0-9]{14}$' ),
		array( 'evri', '^[A-Z0-9]{2}[0-9]{14}$' ),
		array( 'dpd-uk', '^[0-9]{14}$' ),
		array( 'dpd', '^[0-9]{14}$' ),
		array( 'gls', '^[0-9]{11}$' ),
		array( 'parcelforce', '^[A-Z]{2}[0-9]{7}$' ),
	);
	$offered = function_exists( 'gwnf_carriers_offered' ) ? gwnf_carriers_offered() : gwnot_carriers();
	$rules   = array_values( array_filter( $rules, function ( $r ) use ( $offered ) {
		return isset( $offered[ $r[0] ] );
	} ) );
	return apply_filters( 'gwnot_detect_rules', $rules );
}

function gwnot_detect_carrier( $number ) {
	$n     = gwnot_clean_number( $number );
	$found = '';
	foreach ( gwnot_detect_rules() as $r ) {
		if ( preg_match( '/' . $r[1] . '/', $n ) && isset( gwnot_carriers()[ $r[0] ] ) ) {
			$found = $r[0];
			break;
		}
	}
	return (string) apply_filters( 'gwnot_detect_carrier', $found, $n );
}
