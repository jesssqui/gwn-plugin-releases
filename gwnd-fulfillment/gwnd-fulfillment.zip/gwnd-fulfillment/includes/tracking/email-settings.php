<?php
/**
 * WooCommerce → Fulfillment → Emails: wording, colours, box and button style, what the emails show,
 * a live preview of the real WooCommerce email (with unsaved changes) and "Send me a test".
 */
defined( 'ABSPATH' ) || exit;

add_action( 'admin_init', function () {
	register_setting( 'gwnf_mail', 'gwnf_mail', array( 'type' => 'array', 'default' => array(), 'sanitize_callback' => 'gwnf_sanitize_mail' ) );
	register_setting( 'gwnf_mail', 'gwnf_words', array( 'type' => 'array', 'default' => array(), 'sanitize_callback' => 'gwnf_sanitize_words' ) );
} );

add_filter( 'gwnf_settings_tabs', function ( $tabs ) {
	$out = array();
	foreach ( $tabs as $id => $label ) {
		$out[ $id ] = $label;
		if ( 'wording' === $id ) {
			$out['emails'] = __( 'Emails', 'gwnd-fulfillment' );
		}
	}
	return $out;
}, 5 );

/** The WooCommerce emails the tab previews: id => [WC class, label]. */
function gwnf_mail_kinds() {
	return array(
		'shipped'    => array( 'WC_Email_Customer_Completed_Order', __( 'Shipped (order completed with tracking)', 'gwnd-fulfillment' ) ),
		'processing' => array( 'WC_Email_Customer_Processing_Order', __( 'Order received (processing)', 'gwnd-fulfillment' ) ),
	);
}

/** Newest order to preview with: one with tracking for the shipped email when there is one. */
function gwnf_mail_preview_order( $kind ) {
	$ids = wc_get_orders( array( 'limit' => 30, 'orderby' => 'date', 'order' => 'DESC', 'type' => 'shop_order', 'return' => 'ids', 'status' => array( 'wc-completed', 'wc-processing', 'wc-on-hold' ) ) );
	if ( ! $ids ) {
		return null;
	}
	if ( 'shipped' === $kind ) {
		foreach ( $ids as $id ) {
			$o = wc_get_order( $id );
			if ( $o && gwnot_shipments( $o ) ) {
				return $o;
			}
		}
	}
	return wc_get_order( $ids[0] );
}

/** A made-up shipment so the shipped preview has a tracking box even before anything has shipped. */
function gwnf_mail_sample_views( $views, $order ) {
	if ( $views ) {
		return $views;
	}
	$offered = gwnf_carriers_offered();
	unset( $offered['other'] );
	$key = (string) array_key_first( $offered );
	return array( gwnot_view( array( 'id' => 'sample', 'carrier' => $key ?: 'other', 'carrier_name' => __( 'Your carrier', 'gwnd-fulfillment' ), 'number' => 'SAMPLE123456789', 'date' => time() ) ) );
}

/**
 * Render one WooCommerce email for an order: [subject, html].
 * $values (optional): unsaved ['mail' => …, 'words' => …] from the tab.
 */
function gwnf_mail_render( $kind, $values = array() ) {
	$kinds = gwnf_mail_kinds();
	$order = gwnf_mail_preview_order( $kind );
	$all   = WC()->mailer()->get_emails();
	$class = $kinds[ $kind ][0] ?? '';
	if ( ! $order || ! isset( $all[ $class ] ) ) {
		return null;
	}
	if ( $values ) {
		$mail  = gwnf_sanitize_mail( $values['mail'] ?? array() );
		$words = array();
		foreach ( (array) ( $values['words'] ?? array() ) as $k => $v ) {
			$words[ sanitize_key( $k ) ] = trim( sanitize_textarea_field( (string) $v ) );
		}
		add_filter( 'gwnf_mail_values', function () use ( $mail ) {
			return $mail;
		} );
		add_filter( 'gwnf_word', function ( $text, $key, $vars ) use ( $words ) {
			if ( ! array_key_exists( $key, $words ) ) {
				return $text;
			}
			$t = '' !== $words[ $key ] ? $words[ $key ] : ( gwnf_words_schema()[ $key ][2] ?? '' );
			foreach ( (array) $vars as $k => $v ) {
				$t = str_replace( '{' . $k . '}', (string) $v, $t );
			}
			return $t;
		}, 10, 3 );
	}
	if ( 'shipped' === $kind ) {
		add_filter( 'gwnot_views', 'gwnf_mail_sample_views', 10, 2 );
	}
	$email            = $all[ $class ];
	$email->object    = $order;
	$email->recipient = $order->get_billing_email();
	$email->placeholders['{order_date}']   = wc_format_datetime( $order->get_date_created() );
	$email->placeholders['{order_number}'] = $order->get_order_number();
	if ( method_exists( $email, 'setup_locale' ) ) {
		$email->setup_locale();
	}
	$subject = $email->get_subject();
	$html    = $email->style_inline( $email->get_content_html() );
	if ( method_exists( $email, 'restore_locale' ) ) {
		$email->restore_locale();
	}
	remove_filter( 'gwnot_views', 'gwnf_mail_sample_views', 10 );
	return array( $subject, $html, $order, $email );
}

/* Preview page (iframe): admin-post.php?action=gwnf_mail_preview&kind=shipped&v={json} */
add_action( 'admin_post_gwnf_mail_preview', function () {
	if ( ! current_user_can( 'manage_woocommerce' ) || ! check_admin_referer( 'gwnf_mail_preview' ) ) {
		wp_die( esc_html__( 'Not allowed.', 'gwnd-fulfillment' ), 403 );
	}
	$kind   = sanitize_key( wp_unslash( $_GET['kind'] ?? 'shipped' ) );
	$values = json_decode( wp_unslash( (string) ( $_GET['v'] ?? '' ) ), true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each value is sanitized in gwnf_mail_render()
	$r      = gwnf_mail_render( $kind, is_array( $values ) ? $values : array() );
	nocache_headers();
	header( 'Content-Type: text/html; charset=utf-8' );
	if ( ! $r ) {
		echo '<p style="font:14px sans-serif;padding:20px">' . esc_html__( 'The preview appears once the store has an order.', 'gwnd-fulfillment' ) . '</p>';
		exit;
	}
	echo '<div style="font:13px/1.4 -apple-system,BlinkMacSystemFont,sans-serif;background:#1d2327;color:#fff;padding:10px 16px"><span style="opacity:.7">' . esc_html__( 'Subject:', 'gwnd-fulfillment' ) . '</span> ' . esc_html( $r[0] ) . '</div>';
	echo $r[1]; // phpcs:ignore WordPress.Security.EscapeOutput -- WooCommerce's own email HTML
	exit;
} );

/* Send me a test (saved settings) to the signed-in manager. */
add_action( 'admin_post_gwnf_mail_test', function () {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die( esc_html__( 'Not allowed.', 'gwnd-fulfillment' ), 403 );
	}
	check_admin_referer( 'gwnf_mail_test' );
	$kind = sanitize_key( wp_unslash( $_POST['kind'] ?? 'shipped' ) );
	$to   = wp_get_current_user()->user_email;
	$r    = gwnf_mail_render( $kind );
	$ok   = false;
	if ( $r && $to ) {
		$email = $r[3];
		$ok    = $email->send( $to, '[' . __( 'Test', 'gwnd-fulfillment' ) . '] ' . $r[0], $r[1], $email->get_headers(), array() );
	}
	set_transient( 'gwnf_mail_test_' . get_current_user_id(), $ok ? $to : 'fail', 5 * MINUTE_IN_SECONDS );
	if ( $ok ) {
		update_option( 'gwnf_mail_tested', 1, false ); // setup checklist
	}
	wp_safe_redirect( add_query_arg( 'kind', $kind, gwnf_settings_url( 'emails' ) ) );
	exit;
} );

function gwnf_mail_radio( $key, $value, $label, $m ) {
	echo '<label class="gwnf-radio"><input type="radio" name="gwnf_mail[' . esc_attr( $key ) . ']" value="' . esc_attr( $value ) . '"' . checked( $m[ $key ], $value, false ) . '> ' . esc_html( $label ) . '</label>';
}

add_action( 'gwnf_settings_tab_emails', function () {
	$m     = gwnf_mail();
	$saved = get_option( 'gwnf_words', array() );
	$saved = is_array( $saved ) ? $saved : array();
	$kind  = sanitize_key( wp_unslash( $_GET['kind'] ?? 'shipped' ) ); // phpcs:ignore WordPress.Security.NonceVerification
	$kind  = isset( gwnf_mail_kinds()[ $kind ] ) ? $kind : 'shipped';

	$sent = get_transient( 'gwnf_mail_test_' . get_current_user_id() );
	if ( $sent ) {
		delete_transient( 'gwnf_mail_test_' . get_current_user_id() );
		/* translators: %s: email address */
		echo 'fail' === $sent ? '<div class="notice notice-error inline"><p>' . esc_html__( 'The test email couldn\'t be sent. Check that the site can send email (an SMTP plugin usually fixes this).', 'gwnd-fulfillment' ) . '</p></div>' : '<div class="notice notice-success inline"><p>' . esc_html( sprintf( __( 'Test email sent to %s.', 'gwnd-fulfillment' ), $sent ) ) . '</p></div>';
	}

	echo '<form method="post" action="options.php" class="gwnf-look gwnf-mail" id="gwnf-mail">';
	settings_fields( 'gwnf_mail' );
	echo '<div class="gwnf-look__cols"><div class="gwnf-look__form">';

	echo '<section class="gwnf-panel"><h2>' . esc_html__( 'Logo and colours', 'gwnd-fulfillment' ) . '</h2><fieldset>';
	gwnf_mail_radio( 'colors', 'woo', __( 'Use WooCommerce\'s email settings (header image and base colour in WooCommerce → Settings → Emails)', 'gwnd-fulfillment' ), $m );
	echo '<br>';
	/* translators: %s: link to the Look tab */
	gwnf_mail_radio( 'colors', 'brand', __( 'Use my logo and brand colour from the Look tab', 'gwnd-fulfillment' ), $m );
	echo '</fieldset><div class="gwnf-colors" style="margin-top:12px">';
	echo '<div class="gwnf-color"><span class="gwnf-color__label">' . esc_html__( 'Tracking box and button colour (empty = the email\'s base colour)', 'gwnd-fulfillment' ) . '</span><input type="text" class="gwnf-mail-color" name="gwnf_mail[accent]" value="' . esc_attr( $m['accent'] ) . '" data-default-color=""></div>';
	echo '</div></section>';

	echo '<section class="gwnf-panel"><h2>' . esc_html__( 'Tracking box', 'gwnd-fulfillment' ) . '</h2>';
	echo '<p class="gwnf-row"><strong>' . esc_html__( 'Box', 'gwnd-fulfillment' ) . '</strong><br>';
	gwnf_mail_radio( 'box', 'outline', __( 'Outlined, coloured header', 'gwnd-fulfillment' ), $m );
	gwnf_mail_radio( 'box', 'filled', __( 'Soft grey panel', 'gwnd-fulfillment' ), $m );
	gwnf_mail_radio( 'box', 'plain', __( 'No box, just a coloured line', 'gwnd-fulfillment' ), $m );
	echo '</p><p class="gwnf-row"><strong>' . esc_html__( 'Buttons', 'gwnd-fulfillment' ) . '</strong><br>';
	gwnf_mail_radio( 'buttons', 'pill', __( 'Pill', 'gwnd-fulfillment' ), $m );
	gwnf_mail_radio( 'buttons', 'rounded', __( 'Rounded', 'gwnd-fulfillment' ), $m );
	gwnf_mail_radio( 'buttons', 'square', __( 'Square', 'gwnd-fulfillment' ), $m );
	echo '</p><p class="gwnf-row"><strong>' . esc_html__( 'Show', 'gwnd-fulfillment' ) . '</strong><br>';
	gwnf_check_field( 'gwnf_mail[show_number]', 'yes' === $m['show_number'], __( 'The tracking number', 'gwnd-fulfillment' ) );
	gwnf_check_field( 'gwnf_mail[show_track]', 'yes' === $m['show_track'], __( 'The Track package button (opens the carrier\'s tracking page)', 'gwnd-fulfillment' ) );
	gwnf_check_field( 'gwnf_mail[show_view]', 'yes' === $m['show_view'], __( 'The View your order button (your order status page)', 'gwnd-fulfillment' ) );
	gwnf_check_field( 'gwnf_mail[shipped_copy]', 'yes' === $m['shipped_copy'], __( 'Shipped wording: use the subject, heading and first line below when the order has tracking', 'gwnd-fulfillment' ) );
	gwnf_check_field( 'gwnf_mail[processing_link]', 'yes' === $m['processing_link'], __( 'Order received email: add the status line and View your order button', 'gwnd-fulfillment' ) );
	echo '</p></section>';

	echo '<section class="gwnf-panel"><h2>' . esc_html__( 'Wording', 'gwnd-fulfillment' ) . '</h2>';
	echo '<p class="description">' . esc_html__( 'Leave a line empty to use the default shown in grey. You can use {first_name}, {order} and {site}.', 'gwnd-fulfillment' ) . '</p><table class="form-table gwnf-mail-words" role="presentation">';
	foreach ( gwnf_words_schema() as $k => $row ) {
		if ( 'email' !== $row[0] ) {
			continue;
		}
		$val  = $saved[ $k ] ?? '';
		$long = strlen( $row[2] ) > 60 || '' === $row[2];
		echo '<tr><th scope="row"><label for="gwnf-w-' . esc_attr( $k ) . '">' . esc_html( $row[1] ) . '</label></th><td>';
		if ( $long ) {
			echo '<textarea id="gwnf-w-' . esc_attr( $k ) . '" name="gwnf_words[' . esc_attr( $k ) . ']" rows="' . ( '' === $row[2] ? 3 : 2 ) . '" class="large-text" placeholder="' . esc_attr( $row[2] ) . '">' . esc_textarea( $val ) . '</textarea>';
		} else {
			echo '<input type="text" id="gwnf-w-' . esc_attr( $k ) . '" name="gwnf_words[' . esc_attr( $k ) . ']" class="large-text" value="' . esc_attr( $val ) . '" placeholder="' . esc_attr( $row[2] ) . '">';
		}
		echo '</td></tr>';
	}
	echo '</table>';
	echo '<p class="description">' . wp_kses( sprintf(
		/* translators: %s: link to WooCommerce email settings */
		__( 'The Track package button text is on the Wording tab. Each email\'s own subject and heading in %s win over these when they\'re filled in.', 'gwnd-fulfillment' ),
		'<a href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=email' ) ) . '">' . esc_html__( 'WooCommerce → Settings → Emails', 'gwnd-fulfillment' ) . '</a>'
	), array( 'a' => array( 'href' => true ) ) ) . '</p></section>';

	submit_button();
	echo '</div>';

	$base = wp_nonce_url( admin_url( 'admin-post.php?action=gwnf_mail_preview' ), 'gwnf_mail_preview' );
	echo '<aside class="gwnf-look__preview"><div class="gwnf-panel"><h2>' . esc_html__( 'Preview', 'gwnd-fulfillment' ) . '</h2>';
	echo '<p class="gwnf-mail-kinds">';
	foreach ( gwnf_mail_kinds() as $id => $k ) {
		echo '<label class="gwnf-radio"><input type="radio" name="gwnf_mail_kind" value="' . esc_attr( $id ) . '"' . checked( $kind, $id, false ) . '> ' . esc_html( $k[1] ) . '</label> ';
	}
	echo '</p><p class="description">' . esc_html__( 'Your newest order in the real WooCommerce email, with the changes on the left. Before anything has shipped, a sample tracking number is shown.', 'gwnd-fulfillment' ) . '</p>';
	echo '<div class="gwnf-preview gwnf-preview--mail" data-base="' . esc_attr( $base ) . '"><iframe title="' . esc_attr__( 'Email preview', 'gwnd-fulfillment' ) . '" src="' . esc_url( add_query_arg( 'kind', $kind, $base ) ) . '"></iframe></div>';
	echo '</div></aside></div></form>';

	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="gwnf-mail-test">';
	wp_nonce_field( 'gwnf_mail_test' );
	echo '<input type="hidden" name="action" value="gwnf_mail_test"><input type="hidden" name="kind" value="' . esc_attr( $kind ) . '">';
	/* translators: %s: email address */
	submit_button( sprintf( __( 'Send me a test (%s)', 'gwnd-fulfillment' ), wp_get_current_user()->user_email ), 'secondary', 'submit', false );
	echo ' <span class="description">' . esc_html__( 'Sends the saved version of the email shown in the preview.', 'gwnd-fulfillment' ) . '</span></form>';
} );
