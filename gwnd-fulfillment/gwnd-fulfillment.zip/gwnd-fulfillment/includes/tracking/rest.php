<?php
/**
 * REST API for shipping tools / scripts (WooCommerce API keys work — the `wc-` namespace prefix
 * lets WooCommerce authenticate it). Needs a key/user with edit_shop_orders.
 *
 *   GET    /wp-json/wc-tracking/v1/orders/{id}
 *   POST   /wp-json/wc-tracking/v1/orders/{id}   {carrier, tracking_number, carrier_name?, tracking_url?, mark_shipped?=true, notify?=true}
 *   DELETE /wp-json/wc-tracking/v1/orders/{id}/{shipment_id}
 * carrier: canada-post | purolator | ups | fedex | canpar | chit-chats | other
 */
defined( 'ABSPATH' ) || exit;

add_action( 'rest_api_init', function () {
	$perm = function () {
		return current_user_can( 'edit_shop_orders' );
	};
	$get_order = function ( $id ) {
		$o = wc_get_order( (int) $id );
		return ( $o && 'shop_order' === $o->get_type() ) ? $o : null;
	};
	$out = function ( $order ) {
		return array(
			'order_id'   => $order->get_id(),
			'status'     => $order->get_status(),
			'status_url' => gwnot_status_url( $order ),
			'shipments'  => array_map( function ( $v ) {
				return array( 'id' => $v['id'], 'carrier' => $v['carrier'], 'tracking_number' => $v['number'], 'tracking_url' => $v['url'], 'date_shipped' => gmdate( 'c', $v['date'] ) );
			}, gwnot_views( $order ) ),
			'carriers'   => array_keys( gwnot_carriers() ),
		);
	};

	register_rest_route( 'wc-tracking/v1', '/orders/(?P<id>\d+)', array(
		array(
			'methods'             => 'GET',
			'permission_callback' => $perm,
			'callback'            => function ( WP_REST_Request $r ) use ( $get_order, $out ) {
				$o = $get_order( $r['id'] );
				return $o ? $out( $o ) : new WP_Error( 'not_found', 'Order not found.', array( 'status' => 404 ) );
			},
		),
		array(
			'methods'             => 'POST',
			'permission_callback' => $perm,
			'callback'            => function ( WP_REST_Request $r ) use ( $get_order, $out ) {
				$o = $get_order( $r['id'] );
				if ( ! $o ) {
					return new WP_Error( 'not_found', 'Order not found.', array( 'status' => 404 ) );
				}
				$was_done = $o->has_status( 'completed' );
				$res = gwnot_add_shipment( $o, (string) ( $r->get_param( 'carrier' ) ?: 'auto' ), (string) $r->get_param( 'tracking_number' ), array(
					'carrier_name' => (string) $r->get_param( 'carrier_name' ),
					'url'          => (string) $r->get_param( 'tracking_url' ),
				) );
				if ( is_wp_error( $res ) ) {
					$res->add_data( array( 'status' => 400 ) );
					return $res;
				}
				$mark   = null === $r->get_param( 'mark_shipped' ) ? true : rest_sanitize_boolean( $r->get_param( 'mark_shipped' ) );
				$notify = null === $r->get_param( 'notify' ) ? true : rest_sanitize_boolean( $r->get_param( 'notify' ) );
				if ( $mark ) {
					gwnot_mark_shipped( $o, $was_done && $notify );
				}
				return $out( wc_get_order( $o->get_id() ) );
			},
		),
	) );

	register_rest_route( 'wc-tracking/v1', '/orders/(?P<id>\d+)/(?P<sid>[a-z0-9]+)', array(
		'methods'             => 'DELETE',
		'permission_callback' => $perm,
		'callback'            => function ( WP_REST_Request $r ) use ( $get_order, $out ) {
			$o = $get_order( $r['id'] );
			if ( ! $o || ! gwnot_remove_shipment( $o, sanitize_key( $r['sid'] ) ) ) {
				return new WP_Error( 'not_found', 'Shipment not found.', array( 'status' => 404 ) );
			}
			return $out( wc_get_order( $o->get_id() ) );
		},
	) );
} );
