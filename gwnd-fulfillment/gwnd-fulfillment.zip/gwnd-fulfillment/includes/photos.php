<?php
/**
 * Packing photos: staff take or upload photos of what went in the box, kept on the order as a record
 * for "something was missing" complaints.
 *
 * Storage: wp-content/uploads/gwnd-packing-photos/{order id}/ — NOT the Media Library. The folder is
 * locked (deny rules for Apache/LiteSpeed + random file names for servers that ignore them) and photos
 * are only served through admin-post.php to users who can edit orders.
 * Each photo is re-saved on upload (max 2000px, JPEG/WebP quality 82), which also strips EXIF/GPS data.
 *
 * Order meta _gwnf_photos: list of [ id, file, thumb, mime, w, h, bytes, time, user ].
 * Filters: gwnf_photo_max_px (int), gwnf_photos_dir (string), gwnf_photo_can_view / gwnf_photo_can_delete (bool, $order).
 */
defined( 'ABSPATH' ) || exit;

const GWNF_PHOTOS_META = '_gwnf_photos';

/* ---------- Storage ---------- */

function gwnf_photos_base() {
	$up = wp_upload_dir( null, false );
	return trailingslashit( apply_filters( 'gwnf_photos_dir', trailingslashit( $up['basedir'] ) . 'gwnd-packing-photos' ) );
}

/** Make the folder and lock it down. */
function gwnf_photos_prepare_dir( $order_id ) {
	$base = gwnf_photos_base();
	if ( ! is_dir( $base ) ) {
		wp_mkdir_p( $base );
	}
	if ( ! file_exists( $base . '.htaccess' ) ) {
		file_put_contents( $base . '.htaccess', "# Packing photos are private — served only to signed-in staff.\n<IfModule mod_authz_core.c>\n\tRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n\tOrder deny,allow\n\tDeny from all\n</IfModule>\nOptions -Indexes\n" ); // phpcs:ignore
	}
	if ( ! file_exists( $base . 'index.php' ) ) {
		file_put_contents( $base . 'index.php', "<?php // Silence.\n" ); // phpcs:ignore
	}
	$dir = $base . absint( $order_id ) . '/';
	if ( ! is_dir( $dir ) ) {
		wp_mkdir_p( $dir );
		file_put_contents( $dir . 'index.php', "<?php // Silence.\n" ); // phpcs:ignore
	}
	return $dir;
}

function gwnf_photos( $order ) {
	$order = $order instanceof WC_Order ? $order : wc_get_order( $order );
	$list  = $order ? $order->get_meta( GWNF_PHOTOS_META, true ) : array();
	return is_array( $list ) ? array_values( $list ) : array();
}

function gwnf_photo_can_view( $order ) {
	return (bool) apply_filters( 'gwnf_photo_can_view', current_user_can( 'edit_shop_orders' ), $order );
}

function gwnf_photo_can_delete( $order ) {
	return (bool) apply_filters( 'gwnf_photo_can_delete', current_user_can( 'edit_shop_orders' ), $order );
}

function gwnf_photo_url( $order_id, $photo_id, $size = 'full' ) {
	return add_query_arg( array( 'action' => 'gwnf_photo', 'order' => absint( $order_id ), 'photo' => $photo_id, 'size' => 'thumb' === $size ? 'thumb' : 'full' ), admin_url( 'admin-post.php' ) );
}

/**
 * Save one uploaded image to an order.
 *
 * @param WC_Order $order
 * @param string   $tmp   Path of the uploaded file.
 * @param string   $name  Original file name (for the type check only).
 * @return array|WP_Error The stored photo.
 */
function gwnf_add_photo( $order, $tmp, $name = '' ) {
	if ( ! is_readable( $tmp ) ) {
		return new WP_Error( 'gwnf_photo', 'The upload could not be read.' );
	}
	$check = wp_check_filetype_and_ext( $tmp, $name ?: basename( $tmp ) );
	$type  = $check['type'] ?: ( function_exists( 'mime_content_type' ) ? mime_content_type( $tmp ) : '' );
	if ( ! in_array( $type, array( 'image/jpeg', 'image/png', 'image/webp', 'image/heic', 'image/heif', 'image/avif', 'image/gif' ), true ) ) {
		return new WP_Error( 'gwnf_photo', 'Only photos can be added (JPEG, PNG, WebP, HEIC).' );
	}
	$editor = wp_get_image_editor( $tmp );
	if ( is_wp_error( $editor ) ) {
		return new WP_Error( 'gwnf_photo', 'This server can\'t read that photo' . ( in_array( $type, array( 'image/heic', 'image/heif' ), true ) ? ' (HEIC). On iPhone, set Settings → Camera → Formats → Most Compatible, or take the photo from this page.' : '.' ) );
	}
	if ( method_exists( $editor, 'maybe_exif_rotate' ) ) {
		$editor->maybe_exif_rotate(); // phones save sideways + an orientation flag; the re-save drops the flag
	}
	$max = (int) apply_filters( 'gwnf_photo_max_px', 2000 );
	$editor->resize( $max, $max, false );
	$editor->set_quality( 82 );
	$out_mime = 'image/png' === $type ? 'image/png' : ( $editor::supports_mime_type( 'image/webp' ) && 'image/webp' === $type ? 'image/webp' : 'image/jpeg' );
	$ext      = array( 'image/png' => 'png', 'image/webp' => 'webp', 'image/jpeg' => 'jpg' )[ $out_mime ];
	$dir      = gwnf_photos_prepare_dir( $order->get_id() );
	$id       = strtolower( wp_generate_password( 16, false, false ) );
	$file     = 'order-' . $order->get_id() . '-' . $id . '.' . $ext;
	$saved    = $editor->save( $dir . $file, $out_mime );
	if ( is_wp_error( $saved ) ) {
		return $saved;
	}
	$size  = $editor->get_size();
	$thumb = '';
	$t     = wp_get_image_editor( $dir . $file );
	if ( ! is_wp_error( $t ) ) {
		$t->resize( 480, 480, false );
		$t->set_quality( 75 );
		$tsaved = $t->save( $dir . 'thumb-' . $file, $out_mime );
		if ( ! is_wp_error( $tsaved ) ) {
			$thumb = 'thumb-' . $file;
		}
	}
	$user  = wp_get_current_user();
	$photo = array(
		'id'    => $id,
		'file'  => $file,
		'thumb' => $thumb,
		'mime'  => $out_mime,
		'w'     => (int) $size['width'],
		'h'     => (int) $size['height'],
		'bytes' => (int) filesize( $dir . $file ),
		'time'  => time(),
		'user'  => $user && $user->exists() ? $user->display_name : 'system',
	);
	$list   = gwnf_photos( $order );
	$list[] = $photo;
	$order->update_meta_data( GWNF_PHOTOS_META, $list );
	$order->save();
	return $photo;
}

/** @return true|WP_Error */
function gwnf_delete_photo( $order, $photo_id ) {
	$list = gwnf_photos( $order );
	$keep = array();
	$gone = null;
	foreach ( $list as $p ) {
		if ( $p['id'] === $photo_id ) {
			$gone = $p;
		} else {
			$keep[] = $p;
		}
	}
	if ( ! $gone ) {
		return new WP_Error( 'gwnf_photo', 'Photo not found.' );
	}
	$dir = gwnf_photos_base() . $order->get_id() . '/';
	wp_delete_file( $dir . $gone['file'] );
	if ( $gone['thumb'] ) {
		wp_delete_file( $dir . $gone['thumb'] );
	}
	$keep ? $order->update_meta_data( GWNF_PHOTOS_META, $keep ) : $order->delete_meta_data( GWNF_PHOTOS_META );
	$order->save();
	$user = wp_get_current_user();
	$order->add_order_note( sprintf( 'Packing photo from %s deleted by %s.', wp_date( 'M j, g:i a', $gone['time'] ), $user && $user->exists() ? $user->display_name : 'system' ) );
	return true;
}

/* When an order is permanently deleted, its photos go with it (trashing keeps them). */
function gwnf_photos_purge( $order_id ) {
	$dir = gwnf_photos_base() . absint( $order_id ) . '/';
	if ( absint( $order_id ) && is_dir( $dir ) ) {
		foreach ( (array) glob( $dir . '*' ) as $f ) {
			wp_delete_file( $f );
		}
		@rmdir( $dir ); // phpcs:ignore
	}
}
add_action( 'woocommerce_before_delete_order', 'gwnf_photos_purge' );
add_action( 'before_delete_post', function ( $post_id ) {
	if ( 'shop_order' === get_post_type( $post_id ) ) {
		gwnf_photos_purge( $post_id );
	}
} );

/* ---------- Serving (staff only) ---------- */

add_action( 'admin_post_gwnf_photo', function () {
	$order = wc_get_order( absint( $_GET['order'] ?? 0 ) ); // phpcs:ignore WordPress.Security.NonceVerification
	if ( ! $order || ! gwnf_photo_can_view( $order ) ) {
		wp_die( 'You are not allowed to view this photo.', 403 );
	}
	$want = sanitize_key( wp_unslash( $_GET['photo'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
	foreach ( gwnf_photos( $order ) as $p ) {
		if ( $p['id'] !== $want ) {
			continue;
		}
		$name = ( 'thumb' === ( $_GET['size'] ?? '' ) && $p['thumb'] ) ? $p['thumb'] : $p['file']; // phpcs:ignore
		$path = gwnf_photos_base() . $order->get_id() . '/' . basename( $name );
		if ( ! is_readable( $path ) ) {
			break;
		}
		nocache_headers();
		header( 'Content-Type: ' . $p['mime'] );
		header( 'Content-Length: ' . filesize( $path ) );
		header( 'Content-Disposition: inline; filename="order-' . $order->get_order_number() . '-' . $p['id'] . '.' . pathinfo( $path, PATHINFO_EXTENSION ) . '"' );
		header( 'X-Robots-Tag: noindex, nofollow' );
		header( 'Cache-Control: private, max-age=3600' );
		readfile( $path ); // phpcs:ignore
		exit;
	}
	wp_die( 'Photo not found.', 404 );
} );

/* ---------- Upload / delete (AJAX from the order screen) ---------- */

add_action( 'wp_ajax_gwnf_photo_upload', function () {
	check_ajax_referer( 'gwnf_photos', 'nonce' );
	$order = wc_get_order( absint( $_POST['order'] ?? 0 ) );
	if ( ! $order || ! current_user_can( 'edit_shop_orders' ) ) {
		wp_send_json_error( array( 'message' => 'Not allowed.' ), 403 );
	}
	$files  = $_FILES['photos'] ?? null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$added  = 0;
	$errors = array();
	if ( $files && is_array( $files['name'] ) ) {
		foreach ( $files['name'] as $i => $name ) {
			if ( UPLOAD_ERR_OK !== (int) $files['error'][ $i ] ) {
				$errors[] = sanitize_file_name( $name ) . ': upload failed' . ( in_array( (int) $files['error'][ $i ], array( UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE ), true ) ? ' (too big for this server)' : '' ) . '.';
				continue;
			}
			if ( ! is_uploaded_file( $files['tmp_name'][ $i ] ) ) {
				continue;
			}
			$r = gwnf_add_photo( $order, $files['tmp_name'][ $i ], $name );
			if ( is_wp_error( $r ) ) {
				$errors[] = sanitize_file_name( $name ) . ': ' . $r->get_error_message();
			} else {
				$added++;
				$order = wc_get_order( $order->get_id() );
			}
		}
	}
	if ( $added ) {
		gwnf_photos_note( $order, $added );
	}
	wp_send_json_success( array( 'html' => gwnf_photos_grid( wc_get_order( $order->get_id() ) ), 'added' => $added, 'errors' => $errors ) );
} );

add_action( 'wp_ajax_gwnf_photo_delete', function () {
	check_ajax_referer( 'gwnf_photos', 'nonce' );
	$order = wc_get_order( absint( $_POST['order'] ?? 0 ) );
	if ( ! $order || ! gwnf_photo_can_delete( $order ) ) {
		wp_send_json_error( array( 'message' => 'Not allowed.' ), 403 );
	}
	$r = gwnf_delete_photo( $order, sanitize_key( wp_unslash( $_POST['photo'] ?? '' ) ) );
	if ( is_wp_error( $r ) ) {
		wp_send_json_error( array( 'message' => $r->get_error_message() ) );
	}
	wp_send_json_success( array( 'html' => gwnf_photos_grid( wc_get_order( $order->get_id() ) ) ) );
} );

/**
 * "N packing photos added by X." — photos upload one per request, so a burst from the same person within
 * a few minutes updates one note instead of adding a note per photo.
 */
function gwnf_photos_note( $order, $added ) {
	$user = wp_get_current_user();
	$who  = $user && $user->exists() ? $user->display_name : 'system';
	$key  = 'gwnf_ph_note_' . $order->get_id() . '_' . get_current_user_id();
	$prev = get_transient( $key );
	if ( is_array( $prev ) && ! empty( $prev['note'] ) ) {
		$total = (int) $prev['count'] + (int) $added;
		/* translators: 1: number of photos, 2: person */
		$text  = sprintf( _n( '%1$d packing photo added by %2$s.', '%1$d packing photos added by %2$s.', $total, 'gwnd-fulfillment' ), $total, $who );
		wp_update_comment( array( 'comment_ID' => (int) $prev['note'], 'comment_content' => $text ) );
		set_transient( $key, array( 'note' => (int) $prev['note'], 'count' => $total ), 5 * MINUTE_IN_SECONDS );
		return;
	}
	/* translators: 1: number of photos, 2: person */
	$id = $order->add_order_note( sprintf( _n( '%1$d packing photo added by %2$s.', '%1$d packing photos added by %2$s.', $added, 'gwnd-fulfillment' ), $added, $who ) );
	set_transient( $key, array( 'note' => (int) $id, 'count' => (int) $added ), 5 * MINUTE_IN_SECONDS );
}

/* ---------- Order screen box ---------- */

function gwnf_order_screen() {
	if ( class_exists( \Automattic\WooCommerce\Utilities\OrderUtil::class ) && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ) {
		return wc_get_page_screen_id( 'shop-order' );
	}
	return 'shop_order';
}

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'gwnf-photos', 'Packing photos', 'gwnf_photos_box', gwnf_order_screen(), 'normal', 'default' );
} );

function gwnf_photos_grid( $order ) {
	$list = gwnf_photos( $order );
	if ( ! $list ) {
		return '<p class="gwnf-ph-empty">No packing photos yet. Take a photo of what\'s going in the box before you seal it — it\'s your record if the customer says something was missing.</p>';
	}
	$can_delete = gwnf_photo_can_delete( $order );
	$h          = '<ul class="gwnf-ph-grid">';
	foreach ( $list as $p ) {
		$full = gwnf_photo_url( $order->get_id(), $p['id'] );
		$h   .= '<li><a href="' . esc_url( $full ) . '" target="_blank" rel="noopener" title="Open full size"><img loading="lazy" src="' . esc_url( gwnf_photo_url( $order->get_id(), $p['id'], 'thumb' ) ) . '" alt="Packing photo"></a>'
			. '<span class="gwnf-ph-meta">' . esc_html( wp_date( 'M j, Y g:i a', $p['time'] ) ) . '<br>' . esc_html( $p['user'] ) . '</span>'
			. ( $can_delete ? '<button type="button" class="button-link gwnf-ph-del" data-photo="' . esc_attr( $p['id'] ) . '">Delete</button>' : '' )
			. '</li>';
	}
	return $h . '</ul>';
}

function gwnf_photos_box( $obj ) {
	$order = $obj instanceof WP_Post ? wc_get_order( $obj->ID ) : $obj;
	if ( ! $order instanceof WC_Order ) {
		return;
	}
	if ( ! gwnf_photo_can_view( $order ) ) {
		echo '<p>You don\'t have access to packing photos.</p>';
		return;
	}
	?>
	<div class="gwnf-ph" data-order="<?php echo esc_attr( $order->get_id() ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'gwnf_photos' ) ); ?>">
		<div class="gwnf-ph-bar">
			<label class="button button-primary gwnf-ph-add">
				<span class="dashicons dashicons-camera" aria-hidden="true"></span> Add photos
				<input type="file" accept="image/*" capture="environment" multiple hidden>
			</label>
			<label class="button gwnf-ph-add">
				Upload from files / gallery
				<input type="file" accept="image/*" multiple hidden>
			</label>
			<span class="gwnf-ph-status" role="status" aria-live="polite"></span>
		</div>
		<div class="gwnf-ph-list"><?php echo gwnf_photos_grid( $order ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
		<p class="gwnf-ph-fine">Only staff can see these. Photos are shrunk before uploading, so full-size phone photos are fine.</p>
	</div>
	<style>
	.gwnf-ph-bar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:4px 0 12px}
	.gwnf-ph-add .dashicons{vertical-align:middle;margin-top:-2px}
	.gwnf-ph-status{color:#50575e}.gwnf-ph-status.is-error{color:#b32d2e}
	.gwnf-ph-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:12px;margin:0}
	.gwnf-ph-grid li{margin:0;background:#f6f7f7;border:1px solid #dcdcde;border-radius:6px;padding:6px;position:relative}
	.gwnf-ph-grid img{display:block;width:100%;aspect-ratio:1/1;object-fit:cover;border-radius:4px;background:#e5e5e5}
	.gwnf-ph-meta{display:block;font-size:11px;line-height:1.4;color:#50575e;margin-top:5px}
	.gwnf-ph-del{position:absolute;right:8px;bottom:6px;color:#b32d2e!important;font-size:11px}
	.gwnf-ph-empty,.gwnf-ph-fine{color:#646970}.gwnf-ph-fine{font-size:12px;margin:12px 0 0}
	@media (max-width:782px){.gwnf-ph-bar .button{min-height:44px;line-height:42px;padding:0 16px}}
	</style>
	<script>
	(function(){
		var box=document.querySelector('.gwnf-ph'); if(!box){return;}
		var list=box.querySelector('.gwnf-ph-list'), status=box.querySelector('.gwnf-ph-status');
		function say(t,err){status.textContent=t;status.classList.toggle('is-error',!!err);}
		function post(fd,done){
			fd.append('order',box.dataset.order); fd.append('nonce',box.dataset.nonce);
			fetch(ajaxurl,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json();}).then(done).catch(function(){say('Something went wrong — check your connection and try again.',true);});
		}
		// Shrink in the browser first (max 2000px, JPEG): phone photos are 3–8 MB, more than many hosts accept,
		// and slow on cellular. Also drops EXIF/GPS. Falls back to the original file if the browser can't.
		var MAX=<?php echo (int) apply_filters( 'gwnf_photo_max_px', 2000 ); ?>;
		function shrink(file){
			if(!window.createImageBitmap||!/^image\/(jpeg|png|webp|heic|heif)$/i.test(file.type)){return Promise.resolve(file);}
			return createImageBitmap(file,{imageOrientation:'from-image'}).then(function(bmp){
				var k=Math.min(1,MAX/Math.max(bmp.width,bmp.height)), c=document.createElement('canvas');
				c.width=Math.round(bmp.width*k); c.height=Math.round(bmp.height*k);
				c.getContext('2d').drawImage(bmp,0,0,c.width,c.height);
				var png=/png$/i.test(file.type);
				return new Promise(function(res){c.toBlob(function(b){res(b&&b.size<file.size?new File([b],file.name.replace(/\.\w+$/,'')+(png?'.png':'.jpg'),{type:b.type}):file);},png?'image/png':'image/jpeg',0.85);});
			}).catch(function(){return file;});
		}
		box.querySelectorAll('input[type=file]').forEach(function(inp){
			inp.addEventListener('change',function(){
				var files=Array.prototype.slice.call(inp.files), n=files.length, done=0, added=0, errs=[];
				if(!n){return;}
				inp.value='';
				// One photo per request so several big photos never hit the server's total upload limit.
				(function next(){
					if(done>=n){
						var msg=added?(added+' photo'+(added>1?'s':'')+' saved.'):'';
						if(errs.length){say((msg?msg+' ':'')+errs.join(' '),true);}else{say(msg);}
						return;
					}
					say('Uploading photo '+(done+1)+' of '+n+'…');
					shrink(files[done]).then(function(f){
						var fd=new FormData(); fd.append('action','gwnf_photo_upload'); fd.append('photos[]',f,f.name);
						post(fd,function(r){
							done++;
							if(r&&r.success){list.innerHTML=r.data.html; added+=r.data.added; errs=errs.concat(r.data.errors||[]);}
							else{errs.push((r&&r.data&&r.data.message)||'Upload failed.');}
							next();
						});
					});
				})();
			});
		});
		list.addEventListener('click',function(e){
			var b=e.target.closest('.gwnf-ph-del'); if(!b){return;}
			if(!window.confirm('Delete this packing photo? This can\'t be undone.')){return;}
			var fd=new FormData(); fd.append('action','gwnf_photo_delete'); fd.append('photo',b.dataset.photo);
			post(fd,function(r){ if(r&&r.success){list.innerHTML=r.data.html;say('Photo deleted.');}else{say((r&&r.data&&r.data.message)||'Could not delete.',true);} });
		});
	})();
	</script>
	<?php
}

/* ---------- Orders list: photo count ---------- */

function gwnf_photos_column( $cols ) {
	$out = array();
	foreach ( $cols as $k => $v ) {
		$out[ $k ] = $v;
		if ( 'order_status' === $k ) {
			$out['gwnf_photos'] = '<span class="dashicons dashicons-camera" title="' . esc_attr__( 'Packing photos', 'gwnd-fulfillment' ) . '"></span><span class="screen-reader-text">' . esc_html__( 'Packing photos', 'gwnd-fulfillment' ) . '</span>';
		}
	}
	if ( ! isset( $out['gwnf_photos'] ) ) {
		$out['gwnf_photos'] = __( 'Photos', 'gwnd-fulfillment' );
	}
	return $out;
}
function gwnf_photos_cell( $order ) {
	$n = $order ? count( gwnf_photos( $order ) ) : 0;
	/* translators: %d: number of photos */
	echo $n ? '<span class="gwnf-photo-count" title="' . esc_attr( sprintf( _n( '%d packing photo', '%d packing photos', $n, 'gwnd-fulfillment' ), $n ) ) . '"><span class="dashicons dashicons-camera" aria-hidden="true"></span> ' . (int) $n . '</span>' : '<span aria-hidden="true" style="color:#c3c4c7">—</span>';
}
add_filter( 'manage_woocommerce_page_wc-orders_columns', 'gwnf_photos_column', 21 );
add_action( 'manage_woocommerce_page_wc-orders_custom_column', function ( $col, $order ) {
	if ( 'gwnf_photos' === $col ) {
		gwnf_photos_cell( $order );
	}
}, 10, 2 );
add_filter( 'manage_edit-shop_order_columns', 'gwnf_photos_column', 21 );
add_action( 'manage_shop_order_posts_custom_column', function ( $col, $post_id ) {
	if ( 'gwnf_photos' === $col ) {
		gwnf_photos_cell( wc_get_order( $post_id ) );
	}
}, 10, 2 );
add_action( 'admin_head', function () {
	echo '<style>.column-gwnf_photos{width:52px;text-align:center!important}.gwnf-photo-count{white-space:nowrap;color:#2c3338}.gwnf-photo-count .dashicons{font-size:16px;width:16px;height:16px;vertical-align:text-bottom;color:#646970}</style>';
} );
