<?php
/**
 * Admin-only branding: who made it and where the docs live, plus the helper that puts admin CSS/JS
 * through WordPress's queue.
 *
 * The credit shows on the Plugins screen and the Fulfillment settings screen, and only while
 * GWND Fulfillment Pro isn't active: Pro has its own credit line and white-label settings (Branding tab),
 * and those win. Never on the storefront, the order status page, packing slips or customer emails.
 */
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'gwnf_admin_inline' ) ) {
	/**
	 * Admin CSS/JS go through WordPress's queue (wp_add_inline_style / wp_add_inline_script on
	 * gwnf-admin-N handles) instead of being printed as raw style/script tags. Called while a screen
	 * renders: styles added after the head print right away, scripts in the footer.
	 *
	 * @param string $type 'css' or 'js'.
	 * @param string $code The code, without the surrounding tags.
	 * @param array  $deps Script handles the code needs (JS only).
	 */
	function gwnf_admin_inline( $type, $code, $deps = array() ) {
		static $n = 0;
		$code = trim( (string) $code );
		if ( '' === $code ) {
			return;
		}
		$handle = 'gwnf-admin-' . ( ++$n ); // One handle per block, so a block added after another was printed still prints.
		if ( 'css' === $type ) {
			wp_register_style( $handle, false, array(), GWNF_VERSION );
			wp_enqueue_style( $handle );
			wp_add_inline_style( $handle, $code );
			if ( did_action( 'admin_print_styles' ) && ! did_action( 'admin_print_footer_scripts' ) ) {
				wp_print_styles( $handle ); // Past the head: print it here so the screen isn't unstyled until the footer.
			}
			return;
		}
		wp_register_script( $handle, false, (array) $deps, GWNF_VERSION, true );
		wp_enqueue_script( $handle );
		wp_add_inline_script( $handle, $code );
	}
}

/** Show our credit? Not when Pro is active (its Branding settings decide). */
function gwnf_show_credit() {
	return ! defined( 'GWNFP_FILE' ) && (bool) apply_filters( 'gwnf_show_credit', true );
}

/** Is the current admin screen the Fulfillment settings screen? */
function gwnf_is_own_screen() {
	$s = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	return $s && 'woocommerce_page_gwnd-fulfillment' === $s->id;
}

/** Small mark + credit line for the footer of the settings screen. */
function gwnf_brand_line() {
	return sprintf(
		'<span class="gwnf-brand"><img src="%1$s" width="18" height="18" alt=""> %2$s</span>',
		esc_url( GWNF_URL . 'assets/gwnd-mark.svg' ),
		wp_kses(
			sprintf(
				/* translators: 1: plugin name and version, 2: link to the studio, 3: link to docs */
				__( '%1$s is free from %2$s. %3$s', 'gwnd-fulfillment' ),
				'<b>GWND Fulfillment ' . esc_html( GWNF_VERSION ) . '</b>',
				'<a href="https://greatwhitenorthdesign.ca/" target="_blank" rel="noopener">Great White North Design</a>',
				'<a href="' . esc_url( GWNF_HOME ) . '" target="_blank" rel="noopener">' . esc_html__( 'Docs & support', 'gwnd-fulfillment' ) . '</a>'
			),
			array( 'b' => array(), 'a' => array( 'href' => array(), 'target' => array(), 'rel' => array() ) )
		)
	);
}

/* Plugins screen: docs link under the description. */
add_filter( 'plugin_row_meta', function ( $meta, $file ) {
	if ( plugin_basename( GWNF_FILE ) === $file && gwnf_show_credit() ) {
		$meta[] = '<a href="' . esc_url( GWNF_HOME ) . '" target="_blank" rel="noopener">' . esc_html__( 'Docs & support', 'gwnd-fulfillment' ) . '</a>';
	}
	return $meta;
}, 10, 2 );

/* Settings screen: replace the "Thank you for creating with WordPress" line with the credit. */
add_filter( 'admin_footer_text', function ( $text ) {
	return gwnf_is_own_screen() && gwnf_show_credit() ? gwnf_brand_line() : $text;
}, 15 );

/* Settings screen: the mark beside the page title, and the footer line's layout. */
add_action( 'admin_enqueue_scripts', function () {
	if ( ! gwnf_is_own_screen() || ! gwnf_show_credit() ) {
		return;
	}
	$mark = esc_url( GWNF_URL . 'assets/gwnd-mark.svg' );
	gwnf_admin_inline(
		'css',
		'.gwnf-brand{display:inline-flex;align-items:center;gap:8px;font-style:normal}.gwnf-brand img{display:block}'
		. '.gwnf-wrap>h1{display:flex;align-items:center;gap:10px}'
		. '.gwnf-wrap>h1::before{content:"";width:28px;height:28px;flex:0 0 28px;background:url("' . $mark . '") no-repeat center/contain}'
	);
} );
