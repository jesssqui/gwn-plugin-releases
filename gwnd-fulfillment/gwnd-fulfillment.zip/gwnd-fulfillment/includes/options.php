<?php
/**
 * Store-editable wording and workflow choices, read by the status page, My account, emails and the order screen.
 *
 * Options:
 *   gwnf_words — key => text. Blank means "use the default" (which is translatable).
 *   gwnf_flow  — workflow choices (see gwnf_flow_defaults()).
 */
defined( 'ABSPATH' ) || exit;

/**
 * Every editable line: key => [group, label, default]. Defaults go through __() so they translate;
 * once a store types its own text, that text is used as is.
 */
function gwnf_words_schema() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}
	$s = array(
		// Order status page.
		'lookup_title'     => array( 'page', __( 'Lookup: headline', 'gwnd-fulfillment' ), __( 'Find your order', 'gwnd-fulfillment' ) ),
		'lookup_lead'      => array( 'page', __( 'Lookup: intro', 'gwnd-fulfillment' ), __( 'Enter your order number and the email you used at checkout. Your order number is in your confirmation email.', 'gwnd-fulfillment' ) ),
		'lookup_button'    => array( 'page', __( 'Lookup: button', 'gwnd-fulfillment' ), __( 'Find my order', 'gwnd-fulfillment' ) ),
		'head_waiting'     => array( 'page', __( 'Waiting for payment: headline', 'gwnd-fulfillment' ), __( 'Waiting for payment', 'gwnd-fulfillment' ) ),
		'lead_waiting'     => array( 'page', __( 'Waiting for payment: text', 'gwnd-fulfillment' ), __( 'We\'ll start packing your order as soon as your payment arrives. Payment instructions are in your order email.', 'gwnd-fulfillment' ) ),
		'head_processing'  => array( 'page', __( 'Paid, packing: headline', 'gwnd-fulfillment' ), __( 'Order confirmed', 'gwnd-fulfillment' ) ),
		'lead_processing'  => array( 'page', __( 'Paid, packing: text', 'gwnd-fulfillment' ), __( 'We\'re getting your order ready. You\'ll get an email with tracking as soon as it ships.', 'gwnd-fulfillment' ) ),
		'head_shipped'     => array( 'page', __( 'Shipped: headline', 'gwnd-fulfillment' ), __( 'Your order is on its way', 'gwnd-fulfillment' ) ),
		'lead_shipped'     => array( 'page', __( 'Shipped: text ({date} = ship date)', 'gwnd-fulfillment' ), __( 'Shipped {date}. Use the tracking below to follow your package.', 'gwnd-fulfillment' ) ),
		'head_complete'    => array( 'page', __( 'Completed, no tracking: headline', 'gwnd-fulfillment' ), __( 'Order complete', 'gwnd-fulfillment' ) ),
		'lead_complete'    => array( 'page', __( 'Completed, no tracking: text', 'gwnd-fulfillment' ), __( 'Your order has been completed. Thanks for shopping with us!', 'gwnd-fulfillment' ) ),
		'head_cancelled'   => array( 'page', __( 'Cancelled: headline', 'gwnd-fulfillment' ), __( 'Order cancelled', 'gwnd-fulfillment' ) ),
		'lead_cancelled'   => array( 'page', __( 'Cancelled: text', 'gwnd-fulfillment' ), __( 'This order was cancelled. If that\'s a surprise, get in touch and we\'ll sort it out.', 'gwnd-fulfillment' ) ),
		'step_placed'      => array( 'steps', __( 'Step 1', 'gwnd-fulfillment' ), __( 'Order placed', 'gwnd-fulfillment' ) ),
		'step_waiting'     => array( 'steps', __( 'Step 2 (unpaid)', 'gwnd-fulfillment' ), __( 'Waiting for payment', 'gwnd-fulfillment' ) ),
		'step_paid'        => array( 'steps', __( 'Step 2 (paid)', 'gwnd-fulfillment' ), __( 'Payment received', 'gwnd-fulfillment' ) ),
		'step_packing'     => array( 'steps', __( 'Step 3 (not shipped)', 'gwnd-fulfillment' ), __( 'Packing', 'gwnd-fulfillment' ) ),
		'step_shipped'     => array( 'steps', __( 'Step 3 (shipped)', 'gwnd-fulfillment' ), __( 'Shipped', 'gwnd-fulfillment' ) ),
		'step_onway'       => array( 'steps', __( 'Step 4', 'gwnd-fulfillment' ), __( 'On its way', 'gwnd-fulfillment' ) ),
		'step_delivered'   => array( 'steps', __( 'Step 4 (delivered)', 'gwnd-fulfillment' ), __( 'Delivered', 'gwnd-fulfillment' ) ),
		'step_ships_in'    => array( 'steps', __( 'Under "Packing" while paid', 'gwnd-fulfillment' ), __( 'Ships within 1–2 business days', 'gwnd-fulfillment' ) ),
		'tracking_title'   => array( 'page', __( 'Tracking card title', 'gwnd-fulfillment' ), __( 'Tracking', 'gwnd-fulfillment' ) ),
		'track_button'     => array( 'page', __( 'Track button', 'gwnd-fulfillment' ), __( 'Track package', 'gwnd-fulfillment' ) ),
		'items_title'      => array( 'page', __( 'Order card title', 'gwnd-fulfillment' ), __( 'Your order', 'gwnd-fulfillment' ) ),
		'help_title'       => array( 'page', __( 'Help card title', 'gwnd-fulfillment' ), __( 'Questions?', 'gwnd-fulfillment' ) ),
		'help_text'        => array( 'page', __( 'Help card text ({email} = help email)', 'gwnd-fulfillment' ), __( 'Email us at {email} with your order number and we\'ll help you out.', 'gwnd-fulfillment' ) ),
		'shop_button'      => array( 'page', __( 'Shop button', 'gwnd-fulfillment' ), __( 'Keep shopping', 'gwnd-fulfillment' ) ),
		'account_link'     => array( 'page', __( 'My account: link to the status page', 'gwnd-fulfillment' ), __( 'Open the order status page', 'gwnd-fulfillment' ) ),
		// Emails.
		'mail_box_title'   => array( 'email', __( 'Tracking box title', 'gwnd-fulfillment' ), __( 'On its way to you', 'gwnd-fulfillment' ) ),
		'mail_shipped_intro' => array( 'email', __( 'Shipped email: first line (replaces WooCommerce\'s "We have finished processing your order.")', 'gwnd-fulfillment' ), __( 'Good news: it\'s packed and on its way.', 'gwnd-fulfillment' ) ),
		'mail_heading'     => array( 'email', __( 'Shipped email: heading', 'gwnd-fulfillment' ), __( 'Your order is on its way!', 'gwnd-fulfillment' ) ),
		'mail_subject'     => array( 'email', __( 'Shipped email: subject ({site}, {order})', 'gwnd-fulfillment' ), __( 'Your {site} order #{order} has shipped', 'gwnd-fulfillment' ) ),
		'mail_note'        => array( 'email', __( 'Under the tracking number', 'gwnd-fulfillment' ), __( 'Tracking can take up to 24 hours to show movement after it ships. You can always see your order and tracking here:', 'gwnd-fulfillment' ) ),
		'mail_view_button' => array( 'email', __( 'View order button', 'gwnd-fulfillment' ), __( 'View your order', 'gwnd-fulfillment' ) ),
		'mail_processing'  => array( 'email', __( 'Processing email: status line', 'gwnd-fulfillment' ), __( 'Check your order status anytime. We\'ll email you tracking as soon as it ships.', 'gwnd-fulfillment' ) ),
	);
	$s = apply_filters( 'gwnf_words_schema', $s );
	if ( did_action( 'init' ) ) {
		$cache = $s; // add-ons have registered their lines by now
	}
	return $s;
}

function gwnf_words_groups() {
	return apply_filters( 'gwnf_words_groups', array(
		'page'  => __( 'Order status page and My account', 'gwnd-fulfillment' ),
		'steps' => __( 'Progress steps', 'gwnd-fulfillment' ),
		'email' => __( 'Emails', 'gwnd-fulfillment' ),
	) );
}

/** One line of customer-facing text: the store's own wording, else the default. */
function gwnf_w( $key, $vars = array() ) {
	static $saved = null;
	if ( null === $saved || ! did_action( 'init' ) ) {
		$saved = get_option( 'gwnf_words', array() );
		$saved = is_array( $saved ) ? $saved : array();
	}
	$schema = gwnf_words_schema();
	$text   = isset( $saved[ $key ] ) && '' !== trim( (string) $saved[ $key ] ) ? (string) $saved[ $key ] : ( $schema[ $key ][2] ?? '' );
	foreach ( $vars as $k => $v ) {
		$text = str_replace( '{' . $k . '}', (string) $v, $text );
	}
	return (string) apply_filters( 'gwnf_word', $text, $key, $vars );
}

/* ---------------- Workflow ---------------- */

function gwnf_flow_defaults() {
	return apply_filters( 'gwnf_flow_defaults', array(
		'slug'          => 'order-status',
		'help_email'    => '',
		'carriers'      => array(), // empty = all
		'notify'        => 'yes',   // "email the customer" ticked by default on the order screen
		'complete'      => 'yes',   // saving tracking marks the order Completed (shipped)
		'account_link'  => 'yes',   // My account → order: link to the status page
		'list_action'   => 'yes',   // My account → orders list: "Track" button
	) );
}

function gwnf_flow( $key = null ) {
	static $f = null;
	if ( null === $f ) {
		$saved = get_option( 'gwnf_flow', array() );
		$f     = wp_parse_args( is_array( $saved ) ? $saved : array(), gwnf_flow_defaults() );
	}
	return null === $key ? $f : ( $f[ $key ] ?? null );
}

/* Feed the workflow choices into the existing filters, so themes can still override them. */
add_filter( 'gwnot_slug', function ( $slug ) {
	$s = sanitize_title( (string) gwnf_flow( 'slug' ) );
	return $s ? $s : $slug;
}, 5 );

add_filter( 'gwnot_help_email', function ( $email ) {
	$e = sanitize_email( (string) gwnf_flow( 'help_email' ) );
	return $e ? $e : $email;
}, 5 );

/** Carriers offered in the order screen dropdown (Workflow → Carriers). Stored shipments always keep their carrier. */
function gwnf_carriers_offered() {
	$all  = gwnot_carriers();
	$keep = array_filter( (array) gwnf_flow( 'carriers' ) );
	if ( ! $keep ) {
		return $all;
	}
	$keep[] = 'other';
	return array_intersect_key( $all, array_flip( $keep ) );
}
