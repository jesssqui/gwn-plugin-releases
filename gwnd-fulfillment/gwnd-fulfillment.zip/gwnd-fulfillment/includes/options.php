<?php
/**
 * Store-editable wording and workflow choices, read by the status page, My account, emails and the order screen.
 *
 * Options:
 *   gwnf_words — key => text. Blank means "use the default" (which is translatable).
 *   gwnf_flow  — workflow choices (see gwnf_flow_defaults()).
 */
defined( 'ABSPATH' ) || exit;

/**
 * Every editable line: key => [group, label, default]. Defaults go through __() so they translate;
 * once a store types its own text, that text is used as is.
 */
function gwnf_words_schema() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}
	$s = array(
		// Order status page.
		'lookup_title'     => array( 'page', __( 'Lookup: headline', 'gwnd-fulfillment' ), __( 'Find your order', 'gwnd-fulfillment' ) ),
		'lookup_lead'      => array( 'page', __( 'Lookup: intro', 'gwnd-fulfillment' ), __( 'Enter your order number and the email you used at checkout. Your order number is in your confirmation email.', 'gwnd-fulfillment' ) ),
		'lookup_button'    => array( 'page', __( 'Lookup: button', 'gwnd-fulfillment' ), __( 'Find my order', 'gwnd-fulfillment' ) ),
		'head_waiting'     => array( 'page', __( 'Waiting for payment: headline', 'gwnd-fulfillment' ), __( 'Waiting for payment', 'gwnd-fulfillment' ) ),
		'lead_waiting'     => array( 'page', __( 'Waiting for payment: text', 'gwnd-fulfillment' ), __( 'We\'ll start packing your order as soon as your payment arrives. Payment instructions are in your order email.', 'gwnd-fulfillment' ) ),
		'head_processing'  => array( 'page', __( 'Paid, packing: headline', 'gwnd-fulfillment' ), __( 'Order confirmed', 'gwnd-fulfillment' ) ),
		'lead_processing'  => array( 'page', __( 'Paid, packing: text', 'gwnd-fulfillment' ), __( 'We\'re getting your order ready. You\'ll get an email with tracking as soon as it ships.', 'gwnd-fulfillment' ) ),
		'head_shipped'     => array( 'page', __( 'Shipped: headline', 'gwnd-fulfillment' ), __( 'Your order is on its way', 'gwnd-fulfillment' ) ),
		'lead_shipped'     => array( 'page', __( 'Shipped: text ({date} = ship date)', 'gwnd-fulfillment' ), __( 'Shipped {date}. Use the tracking below to follow your package.', 'gwnd-fulfillment' ) ),
		'head_complete'    => array( 'page', __( 'Completed, no tracking: headline', 'gwnd-fulfillment' ), __( 'Order complete', 'gwnd-fulfillment' ) ),
		'lead_complete'    => array( 'page', __( 'Completed, no tracking: text', 'gwnd-fulfillment' ), __( 'Your order has been completed. Thanks for shopping with us!', 'gwnd-fulfillment' ) ),
		'head_cancelled'   => array( 'page', __( 'Cancelled: headline', 'gwnd-fulfillment' ), __( 'Order cancelled', 'gwnd-fulfillment' ) ),
		'lead_cancelled'   => array( 'page', __( 'Cancelled: text', 'gwnd-fulfillment' ), __( 'This order was cancelled. If that\'s a surprise, get in touch and we\'ll sort it out.', 'gwnd-fulfillment' ) ),
		'step_placed'      => array( 'steps', __( 'Step 1', 'gwnd-fulfillment' ), __( 'Order placed', 'gwnd-fulfillment' ) ),
		'step_waiting'     => array( 'steps', __( 'Step 2 (unpaid)', 'gwnd-fulfillment' ), __( 'Waiting for payment', 'gwnd-fulfillment' ) ),
		'step_paid'        => array( 'steps', __( 'Step 2 (paid)', 'gwnd-fulfillment' ), __( 'Payment received', 'gwnd-fulfillment' ) ),
		'step_packing'     => array( 'steps', __( 'Step 3 (not shipped)', 'gwnd-fulfillment' ), __( 'Packing', 'gwnd-fulfillment' ) ),
		'step_shipped'     => array( 'steps', __( 'Step 3 (shipped)', 'gwnd-fulfillment' ), __( 'Shipped', 'gwnd-fulfillment' ) ),
		'step_onway'       => array( 'steps', __( 'Step 4', 'gwnd-fulfillment' ), __( 'On its way', 'gwnd-fulfillment' ) ),
		'step_delivered'   => array( 'steps', __( 'Step 4 (delivered)', 'gwnd-fulfillment' ), __( 'Delivered', 'gwnd-fulfillment' ) ),
		'step_ships_in'    => array( 'steps', __( 'Under "Packing" while paid', 'gwnd-fulfillment' ), __( 'Ships within 1–2 business days', 'gwnd-fulfillment' ) ),
		'tracking_title'   => array( 'page', __( 'Tracking card title', 'gwnd-fulfillment' ), __( 'Tracking', 'gwnd-fulfillment' ) ),
		'track_button'     => array( 'page', __( 'Track button', 'gwnd-fulfillment' ), __( 'Track package', 'gwnd-fulfillment' ) ),
		'items_title'      => array( 'page', __( 'Order card title', 'gwnd-fulfillment' ), __( 'Your order', 'gwnd-fulfillment' ) ),
		'help_title'       => array( 'page', __( 'Help card title', 'gwnd-fulfillment' ), __( 'Questions?', 'gwnd-fulfillment' ) ),
		'help_text'        => array( 'page', __( 'Help card text ({email} = help email)', 'gwnd-fulfillment' ), __( 'Email us at {email} with your order number and we\'ll help you out.', 'gwnd-fulfillment' ) ),
		'shop_button'      => array( 'page', __( 'Shop button', 'gwnd-fulfillment' ), __( 'Keep shopping', 'gwnd-fulfillment' ) ),
		'account_link'     => array( 'page', __( 'My account: link to the status page', 'gwnd-fulfillment' ), __( 'Open the order status page', 'gwnd-fulfillment' ) ),
		// Emails.
		'mail_box_title'   => array( 'email', __( 'Tracking box title', 'gwnd-fulfillment' ), __( 'On its way to you', 'gwnd-fulfillment' ) ),
		'mail_subject'     => array( 'email', __( 'Shipped email: subject', 'gwnd-fulfillment' ), __( 'Your {site} order #{order} has shipped', 'gwnd-fulfillment' ) ),
		'mail_heading'     => array( 'email', __( 'Shipped email: heading', 'gwnd-fulfillment' ), __( 'Your order is on its way!', 'gwnd-fulfillment' ) ),
		'mail_shipped_intro' => array( 'email', __( 'Shipped email: first line', 'gwnd-fulfillment' ), __( 'Good news: it\'s packed and on its way.', 'gwnd-fulfillment' ) ),
		'mail_note'        => array( 'email', __( 'Under the tracking number', 'gwnd-fulfillment' ), __( 'Tracking can take up to 24 hours to show movement after it ships. You can always see your order and tracking here:', 'gwnd-fulfillment' ) ),
		'mail_view_button' => array( 'email', __( 'View order button', 'gwnd-fulfillment' ), __( 'View your order', 'gwnd-fulfillment' ) ),
		'mail_footer'      => array( 'email', __( 'Shipped email: extra message under the tracking (returns, a discount code, a thank-you…)', 'gwnd-fulfillment' ), '' ),
		'mail_processing'  => array( 'email', __( 'Processing email: status line', 'gwnd-fulfillment' ), __( 'Check your order status anytime. We\'ll email you tracking as soon as it ships.', 'gwnd-fulfillment' ) ),
	);
	$s = apply_filters( 'gwnf_words_schema', $s );
	if ( did_action( 'init' ) ) {
		$cache = $s; // add-ons have registered their lines by now
	}
	return $s;
}

function gwnf_words_groups() {
	return apply_filters( 'gwnf_words_groups', array(
		'page'  => __( 'Order status page and My account', 'gwnd-fulfillment' ),
		'steps' => __( 'Progress steps', 'gwnd-fulfillment' ),
		'email' => __( 'Emails', 'gwnd-fulfillment' ),
	) );
}

/** One line of customer-facing text: the store's own wording, else the default. */
function gwnf_w( $key, $vars = array() ) {
	static $saved = null;
	if ( null === $saved || ! did_action( 'init' ) ) {
		$saved = get_option( 'gwnf_words', array() );
		$saved = is_array( $saved ) ? $saved : array();
	}
	$schema = gwnf_words_schema();
	$text   = isset( $saved[ $key ] ) && '' !== trim( (string) $saved[ $key ] ) ? (string) $saved[ $key ] : ( $schema[ $key ][2] ?? '' );
	foreach ( $vars as $k => $v ) {
		$text = str_replace( '{' . $k . '}', (string) $v, $text );
	}
	return (string) apply_filters( 'gwnf_word', $text, $key, $vars );
}

/* ---------------- Workflow ---------------- */

function gwnf_flow_defaults() {
	return apply_filters( 'gwnf_flow_defaults', array(
		'slug'          => 'order-status',
		'help_email'    => '',
		'carriers'      => array(), // empty = the carriers for the store's country plus UPS, FedEx and DHL
		'custom_carriers' => array(), // the store's own: [ [name, url with {n}], … ]
		'fallback_17track' => 'no', // carriers without a link (Other) link to 17TRACK's tracking page
		'notify'        => 'yes',   // "email the customer" ticked by default on the order screen
		'complete'      => 'yes',   // saving tracking marks the order Completed (shipped)
		'account_link'  => 'yes',   // My account → order: link to the status page
		'list_action'   => 'yes',   // My account → orders list: "Track" button
	) );
}

function gwnf_flow( $key = null ) {
	static $f = null;
	if ( null === $f ) {
		$saved = get_option( 'gwnf_flow', array() );
		$f     = wp_parse_args( is_array( $saved ) ? $saved : array(), gwnf_flow_defaults() );
	}
	return null === $key ? $f : ( $f[ $key ] ?? null );
}

/* Feed the workflow choices into the existing filters, so themes can still override them. */
add_filter( 'gwnot_slug', function ( $slug ) {
	$s = sanitize_title( (string) gwnf_flow( 'slug' ) );
	return $s ? $s : $slug;
}, 5 );

add_filter( 'gwnot_help_email', function ( $email ) {
	$e = sanitize_email( (string) gwnf_flow( 'help_email' ) );
	return $e ? $e : $email;
}, 5 );

/** The store's country (WooCommerce → Settings → General). */
function gwnf_store_country() {
	return function_exists( 'WC' ) && WC()->countries ? WC()->countries->get_base_country() : '';
}

/** Carriers that fit the store's country: its local carriers, the worldwide ones and the store's own. */
function gwnf_carriers_for_country( $country = '' ) {
	$country = $country ?: gwnf_store_country();
	return array_filter( gwnot_carriers(), function ( $c ) use ( $country ) {
		$in = (array) ( $c['countries'] ?? array( '*' ) );
		return ! empty( $c['custom'] ) || in_array( '*', $in, true ) || in_array( $country, $in, true );
	} );
}

/**
 * Carriers offered in the order screen dropdown (Workflow → Carriers). Nothing picked = the ones for the
 * store's country. Stored shipments always keep their carrier. The store's own carriers and "Other" are always offered.
 */
function gwnf_carriers_offered() {
	$all  = gwnot_carriers();
	$keep = array_filter( (array) gwnf_flow( 'carriers' ) );
	if ( ! $keep ) {
		return gwnf_carriers_for_country();
	}
	return array_filter( $all, function ( $c, $k ) use ( $keep ) {
		return 'other' === $k || ! empty( $c['custom'] ) || in_array( $k, $keep, true );
	}, ARRAY_FILTER_USE_BOTH );
}

/* ---------------- Emails (WooCommerce → Fulfillment → Emails) ---------------- */

function gwnf_mail_defaults() {
	$look = get_option( 'gwnf_look', array() );
	return apply_filters( 'gwnf_mail_defaults', array(
		'colors'          => is_array( $look ) && 'yes' === ( $look['on_emails'] ?? 'no' ) ? 'brand' : 'woo', // woo | brand
		'accent'          => '',        // box and button colour; empty = the email base colour
		'box'             => 'outline', // outline | filled | plain
		'buttons'         => 'pill',    // pill | rounded | square
		'show_number'     => 'yes',     // tracking number in the box
		'show_track'      => 'yes',     // Track package button
		'show_view'       => 'yes',     // View your order button
		'processing_link' => 'yes',     // status line + button in the processing email
		'shipped_copy'    => 'yes',     // shipped subject, heading and first line when the order has tracking
	) );
}

/** Email settings. Filter gwnf_mail_values lets the Emails tab preview show unsaved values. */
function gwnf_mail( $key = null ) {
	$saved = get_option( 'gwnf_mail', array() );
	$m     = (array) apply_filters( 'gwnf_mail_values', wp_parse_args( is_array( $saved ) ? $saved : array(), gwnf_mail_defaults() ) );
	return null === $key ? $m : ( $m[ $key ] ?? null );
}

function gwnf_sanitize_mail( $in ) {
	$in  = is_array( $in ) ? $in : array();
	$d   = gwnf_mail_defaults();
	$out = array();
	$pick = array(
		'colors'  => array( 'woo', 'brand' ),
		'box'     => array( 'outline', 'filled', 'plain' ),
		'buttons' => array( 'pill', 'rounded', 'square' ),
	);
	foreach ( $d as $k => $def ) {
		$v = isset( $in[ $k ] ) ? wp_unslash( $in[ $k ] ) : $def;
		if ( isset( $pick[ $k ] ) ) {
			$out[ $k ] = in_array( $v, $pick[ $k ], true ) ? $v : $def;
		} elseif ( 'accent' === $k ) {
			$out[ $k ] = (string) sanitize_hex_color( (string) $v );
		} else {
			$out[ $k ] = 'yes' === $v ? 'yes' : 'no';
		}
	}
	return $out;
}

/**
 * Can the current user work on this order? The general "edit orders" right plus WooCommerce's per-order
 * check, so marketplace plugins that limit vendors to their own orders are respected.
 */
function gwnf_can_edit_order( $order ) {
	$id = $order instanceof WC_Order ? $order->get_id() : absint( $order );
	return (bool) apply_filters( 'gwnf_can_edit_order', $id && current_user_can( 'edit_shop_orders' ) && current_user_can( 'edit_shop_order', $id ), $id );
}
