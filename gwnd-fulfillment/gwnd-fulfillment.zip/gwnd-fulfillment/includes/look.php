<?php
/**
 * Look: how the customer-facing pages look (order status page, My account order view, and, when switched on,
 * the e-Transfer pay panel, WooCommerce emails and packing slips).
 *
 * Option gwnf_look (see gwnf_look_defaults()). The free plugin ships two styles:
 *   theme — light structural styling that inherits the theme (and any theme skin) — the default;
 *   clean — thin lines, white cards, the store's brand colour.
 * Add-ons register more with the gwnf_styles filter and add their CSS with gwnf_look_css.
 *
 * Every style is a set of values for the same few settings (layout, progress display, card style, corners,
 * fonts, colours), so a store can start from a style and make it its own.
 */
defined( 'ABSPATH' ) || exit;

function gwnf_look_defaults() {
	return apply_filters( 'gwnf_look_defaults', array(
		'style'      => 'theme',
		'layout'     => 'stacked',
		'progress'   => 'cards',
		'cards'      => 'outline',
		'radius'     => 12,
		'head_font'  => '',
		'body_font'  => '',
		'head_case'  => 'none',
		'highlight'  => 'no',
		'tilt'       => 'no',
		'bg'         => '',
		'on_bg'      => '',
		'surface'    => '#ffffff',
		'on_surface' => '#1d1d22',
		'brand'      => '#1f3a5f',
		'on_brand'   => '',
		'accent'     => '#dce7f5',
		'line'       => '',
		'logo'       => 0,
		'logo_dark'  => 0,
		'logo_site'  => 'no',
		'logo_h'     => 40,
		'logo_pos'   => 'left',
		'on_status'  => 'yes',
		'on_account' => 'yes',
		'on_etransfer' => 'yes',
		'on_emails'  => 'no',
		'on_slips'   => 'yes',
		'custom_css' => '',
	) );
}

/** Styles a store can start from: id => [label, description, values]. */
function gwnf_styles() {
	return apply_filters( 'gwnf_styles', array(
		'theme' => array(
			'label'  => __( 'Theme default', 'gwnd-fulfillment' ),
			'desc'   => __( 'Light touch: your theme\'s fonts and colours.', 'gwnd-fulfillment' ),
			'values' => array( 'layout' => 'stacked', 'progress' => 'cards', 'cards' => 'outline', 'radius' => 12, 'bg' => '', 'on_bg' => '', 'head_font' => '', 'body_font' => '', 'head_case' => 'none', 'highlight' => 'no', 'tilt' => 'no' ),
		),
		'clean' => array(
			'label'  => __( 'Clean', 'gwnd-fulfillment' ),
			'desc'   => __( 'Thin lines, white cards, lots of space.', 'gwnd-fulfillment' ),
			'values' => array( 'layout' => 'stacked', 'progress' => 'bar', 'cards' => 'outline', 'radius' => 8, 'bg' => '', 'on_bg' => '', 'surface' => '#ffffff', 'on_surface' => '#1c1c1a', 'line' => '#e3e3e0', 'accent' => '#dce7f5', 'head_font' => '', 'body_font' => '', 'head_case' => 'none', 'highlight' => 'no', 'tilt' => 'no' ),
		),
	) );
}

/** Choices each setting allows. Add-ons add more (gwnf_look_choices). */
function gwnf_look_choices() {
	return apply_filters( 'gwnf_look_choices', array(
		'layout'   => array( 'stacked' => __( 'Stacked', 'gwnd-fulfillment' ) ),
		'progress' => array( 'cards' => __( 'Step cards', 'gwnd-fulfillment' ), 'bar' => __( 'Bar', 'gwnd-fulfillment' ) ),
		'cards'    => array( 'outline' => __( 'Outline', 'gwnd-fulfillment' ) ),
	) );
}

/** The store's look, with defaults filled in and values checked against what's installed. */
function gwnf_look( $key = null ) {
	static $l = null;
	if ( null === $l ) {
		$saved = get_option( 'gwnf_look', array() );
		$prev  = gwnf_look_preview_values();
		if ( $prev ) {
			$saved = $prev; // unsaved values from the Look tab's live preview
		}
		$l     = wp_parse_args( is_array( $saved ) ? $saved : array(), gwnf_look_defaults() );
		$styles = gwnf_styles();
		if ( ! isset( $styles[ $l['style'] ] ) && 'custom' !== $l['style'] ) {
			$l['style'] = 'theme';
		}
		// A named style sets the structure; the store's own brand colours and logo always win.
		if ( isset( $styles[ $l['style'] ] ) ) {
			$l = array_merge( $l, array_diff_key( $styles[ $l['style'] ]['values'], array_flip( array( 'brand', 'on_brand', 'accent' ) ) ) );
		}
		foreach ( gwnf_look_choices() as $k => $opts ) {
			if ( ! isset( $opts[ $l[ $k ] ] ) ) {
				$l[ $k ] = (string) key( $opts );
			}
		}
		$l = apply_filters( 'gwnf_look', $l );
	}
	return null === $key ? $l : ( $l[ $key ] ?? null );
}

function gwnf_look_on( $place ) {
	return 'yes' === gwnf_look( 'on_' . $place );
}

/** Is a hex colour dark (so text and logos on it should be light)? */
function gwnf_is_dark( $hex ) {
	$hex = ltrim( (string) $hex, '#' );
	if ( 3 === strlen( $hex ) ) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}
	if ( ! preg_match( '/^[0-9a-f]{6}$/i', $hex ) ) {
		return false;
	}
	list( $r, $g, $b ) = array_map( 'hexdec', str_split( $hex, 2 ) );
	return ( 0.299 * $r + 0.587 * $g + 0.114 * $b ) < 150;
}

/** CSS custom properties for the current look ('' for Theme default, which leaves colours to the theme). */
function gwnf_look_vars() {
	$l = gwnf_look();
	if ( 'theme' === $l['style'] ) {
		return '';
	}
	$brand    = sanitize_hex_color( $l['brand'] ) ?: '#1f3a5f';
	$on_brand = sanitize_hex_color( $l['on_brand'] ) ?: ( gwnf_is_dark( $brand ) ? '#ffffff' : '#111111' );
	$vars     = array(
		'--ot-accent'    => $brand,
		'--ot-on-accent' => $on_brand,
		'--ot-hl'        => sanitize_hex_color( $l['accent'] ) ?: '#dce7f5',
		'--ot-bg'        => sanitize_hex_color( $l['surface'] ) ?: '#ffffff',
		'--ot-ink'       => sanitize_hex_color( $l['on_surface'] ) ?: '#1d1d22',
		'--ot-r'         => absint( $l['radius'] ) . 'px',
		'--ot-r-sm'      => min( absint( $l['radius'] ), 10 ) . 'px',
	);
	if ( $l['line'] && sanitize_hex_color( $l['line'] ) ) {
		$vars['--ot-line'] = sanitize_hex_color( $l['line'] );
	}
	if ( $l['bg'] && sanitize_hex_color( $l['bg'] ) ) {
		$vars['--ot-page']    = sanitize_hex_color( $l['bg'] );
		$vars['--ot-on-page'] = sanitize_hex_color( $l['on_bg'] ) ?: ( gwnf_is_dark( $l['bg'] ) ? '#f2f2f2' : '#1d1d22' );
	}
	foreach ( array( 'head_font' => '--ot-font-h', 'body_font' => '--ot-font-b' ) as $k => $var ) {
		if ( $l[ $k ] ) {
			$vars[ $var ] = "'" . preg_replace( '/[^A-Za-z0-9 \-]/', '', $l[ $k ] ) . "', system-ui, sans-serif";
		}
	}
	$vars = apply_filters( 'gwnf_look_vars', $vars, $l );
	$css  = '';
	foreach ( $vars as $k => $v ) {
		$css .= $k . ':' . $v . ';';
	}
	return $css;
}

/** Classes on the page wrapper: one per choice, so styles are just CSS. */
function gwnf_look_classes() {
	$l = gwnf_look();
	$c = array(
		'ot--style-' . sanitize_html_class( $l['style'] ),
		'ot--layout-' . sanitize_html_class( $l['layout'] ),
		'ot--progress-' . sanitize_html_class( $l['progress'] ),
		'ot--cards-' . sanitize_html_class( $l['cards'] ),
	);
	if ( 'uppercase' === $l['head_case'] ) {
		$c[] = 'ot--upper';
	}
	if ( 'yes' === $l['highlight'] ) {
		$c[] = 'ot--hl';
	}
	if ( 'yes' === $l['tilt'] ) {
		$c[] = 'ot--tilt';
	}
	if ( 'center' === $l['logo_pos'] ) {
		$c[] = 'ot--logo-center';
	}
	if ( $l['bg'] ) {
		$c[] = 'ot--page-bg';
	}
	return implode( ' ', apply_filters( 'gwnf_look_classes', $c, $l ) );
}

/**
 * The store logo, sized and with a light version for dark backgrounds.
 *
 * @param bool $on_dark The logo sits on a dark background.
 */
function gwnf_logo_html( $on_dark = false, $class = 'ot-logo' ) {
	$l  = gwnf_look();
	$id = absint( $on_dark && $l['logo_dark'] ? $l['logo_dark'] : $l['logo'] );
	if ( ! $id && 'yes' === $l['logo_site'] ) {
		$id = absint( get_theme_mod( 'custom_logo' ) );
	}
	if ( ! $id ) {
		return '';
	}
	$h   = max( 16, min( 160, absint( $l['logo_h'] ) ) );
	$img = wp_get_attachment_image( $id, 'medium', false, array(
		'class'   => 'ot-logo__img',
		'alt'     => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
		'style'   => 'height:' . $h . 'px;width:auto',
		'loading' => 'eager',
	) );
	return $img ? '<a class="' . esc_attr( $class ) . '" href="' . esc_url( home_url( '/' ) ) . '">' . $img . '</a>' : '';
}

/* ---------------- Front-end assets (status page + My account order view) ---------------- */

function gwnf_look_page_needs_assets() {
	if ( function_exists( 'gwnot_is_page' ) && gwnot_is_page() ) {
		return true; // the status page always needs its base styles
	}
	return function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url( 'view-order' );
}

add_action( 'wp_enqueue_scripts', function () {
	if ( ! function_exists( 'gwnot_is_page' ) || ! gwnf_look_page_needs_assets() ) {
		return;
	}
	// Priority 1: registered before the theme's stylesheet, so theme skins can still override.
	wp_enqueue_style( 'gwnf-status', GWNF_URL . 'assets/css/status.css', array(), GWNF_VERSION );
	$extra = (string) apply_filters( 'gwnf_look_css', '' );
	$custom = trim( (string) gwnf_look( 'custom_css' ) );
	if ( $custom ) {
		$extra .= "\n" . wp_strip_all_tags( $custom );
	}
	if ( $extra ) {
		wp_add_inline_style( 'gwnf-status', $extra );
	}
	wp_enqueue_script( 'gwnf-status', GWNF_URL . 'assets/js/status.js', array(), GWNF_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
	wp_localize_script( 'gwnf-status', 'gwnfStatus', array(
		'copied' => __( 'Copied!', 'gwnd-fulfillment' ),
		'copy'   => __( 'Copy', 'gwnd-fulfillment' ),
		'prompt' => __( 'Tracking number', 'gwnd-fulfillment' ),
	) );
	do_action( 'gwnf_look_enqueue', gwnf_look() );
}, 1 );

/* ---------------- Emails: the store's logo and brand colour (opt-in) ---------------- */

add_filter( 'pre_option_woocommerce_email_header_image', function ( $pre ) {
	if ( ! function_exists( 'gwnf_look' ) || ! gwnf_look_on( 'emails' ) ) {
		return $pre;
	}
	$id = absint( gwnf_look( 'logo' ) ) ?: ( 'yes' === gwnf_look( 'logo_site' ) ? absint( get_theme_mod( 'custom_logo' ) ) : 0 );
	$src = $id ? wp_get_attachment_image_url( $id, 'medium' ) : '';
	return $src ? $src : $pre;
} );
add_filter( 'pre_option_woocommerce_email_base_color', function ( $pre ) {
	if ( ! function_exists( 'gwnf_look' ) || ! gwnf_look_on( 'emails' ) || 'theme' === gwnf_look( 'style' ) ) {
		return $pre;
	}
	return sanitize_hex_color( gwnf_look( 'brand' ) ) ?: $pre;
} );

/* ---------------- Packing slips: the store logo when the slip has none of its own ---------------- */

add_filter( 'gwnps_logo_id', function ( $id ) {
	if ( $id || ! gwnf_look_on( 'slips' ) ) {
		return $id;
	}
	$l = gwnf_look();
	return absint( $l['logo'] ) ?: ( 'yes' === $l['logo_site'] ? absint( get_theme_mod( 'custom_logo' ) ) : 0 );
} );

/* ---------------- e-Transfer pay panel: follow the store's colours (when GWN e-Transfer is active) ---------------- */

add_filter( 'gwnet_settings', function ( $s ) {
	if ( ! gwnf_look_on( 'etransfer' ) || 'theme' === gwnf_look( 'style' ) ) {
		return $s;
	}
	$l                    = gwnf_look();
	$s['color_accent']    = sanitize_hex_color( $l['brand'] ) ?: $s['color_accent'];
	$s['color_highlight'] = sanitize_hex_color( $l['accent'] ) ?: $s['color_highlight'];
	$s['color_text']      = sanitize_hex_color( $l['on_surface'] ) ?: $s['color_text'];
	$s['color_panel']     = sanitize_hex_color( $l['surface'] ) ?: $s['color_panel'];
	$s['radius']          = absint( $l['radius'] );
	$s['shadow']          = in_array( $l['cards'], array( 'heavy', 'torn' ), true ) ? 'hard' : ( 'shadow' === $l['cards'] ? 'soft' : 'none' );
	return $s;
} );

/* ---------------- Saving + live preview ---------------- */

/** yes/no from a posted value. */
function gwnf_yn( $v ) {
	return in_array( $v, array( 'yes', '1', 1, true, 'on' ), true ) ? 'yes' : 'no';
}

/**
 * Look: only keys the form sent change; the rest keep their saved value (so a field an add-on owns
 * isn't wiped when its add-on is switched off and the free form is saved).
 */
function gwnf_sanitize_look( $in ) {
	$in      = is_array( $in ) ? $in : array();
	$saved   = get_option( 'gwnf_look', array() );
	$out     = is_array( $saved ) ? $saved : array();
	$def     = gwnf_look_defaults();
	$choices = gwnf_look_choices();
	$styles  = gwnf_styles();
	foreach ( $in as $k => $v ) {
		if ( ! array_key_exists( $k, $def ) ) {
			continue;
		}
		$v = is_string( $v ) ? wp_unslash( $v ) : $v;
		switch ( true ) {
			case 'style' === $k:
				$out[ $k ] = ( isset( $styles[ $v ] ) || 'custom' === $v ) ? $v : 'theme';
				break;
			case isset( $choices[ $k ] ):
				$out[ $k ] = isset( $choices[ $k ][ $v ] ) ? $v : (string) key( $choices[ $k ] );
				break;
			case in_array( $k, array( 'bg', 'on_bg', 'surface', 'on_surface', 'brand', 'on_brand', 'accent', 'line' ), true ):
				$out[ $k ] = (string) sanitize_hex_color( $v );
				break;
			case in_array( $k, array( 'logo', 'logo_dark' ), true ):
				$out[ $k ] = absint( $v );
				break;
			case 'radius' === $k:
				$out[ $k ] = min( 40, absint( $v ) );
				break;
			case 'logo_h' === $k:
				$out[ $k ] = max( 16, min( 160, absint( $v ) ) );
				break;
			case in_array( $k, array( 'head_font', 'body_font' ), true ):
				$out[ $k ] = preg_replace( '/[^A-Za-z0-9 \-]/', '', (string) $v );
				break;
			case 'logo_pos' === $k:
				$out[ $k ] = 'center' === $v ? 'center' : 'left';
				break;
			case 'head_case' === $k:
				$out[ $k ] = 'uppercase' === $v ? 'uppercase' : 'none';
				break;
			case 'custom_css' === $k:
				$out[ $k ] = current_user_can( 'unfiltered_html' ) ? wp_strip_all_tags( (string) $v ) : ( $out[ $k ] ?? '' );
				break;
			default:
				$out[ $k ] = gwnf_yn( $v );
		}
	}
	return apply_filters( 'gwnf_sanitize_look', $out, $in );
}

/**
 * Look tab live preview: the settings page's iframe passes the unsaved form as JSON (gwnf_look) with a nonce
 * (gwnf_preview). Only for shop managers; nothing is stored.
 */
function gwnf_look_preview_values() {
	static $v = null;
	if ( null !== $v ) {
		return $v;
	}
	$v = array();
	if ( empty( $_GET['gwnf_preview'] ) || empty( $_GET['gwnf_look'] ) || ! is_user_logged_in() ) { // phpcs:ignore WordPress.Security.NonceVerification -- verified below
		return $v;
	}
	if ( ! current_user_can( 'manage_woocommerce' ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['gwnf_preview'] ) ), 'gwnf_preview' ) ) {
		return $v;
	}
	$in = json_decode( wp_unslash( (string) $_GET['gwnf_look'] ), true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized by gwnf_sanitize_look()
	if ( is_array( $in ) ) {
		unset( $in['custom_css'] );
		$v = gwnf_sanitize_look( $in );
	}
	return $v;
}
