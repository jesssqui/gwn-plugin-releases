<?php
/**
 * Business-day timing: give customers N business days to pay instead of N hours, and show the
 * deadline as a date ("Send by Friday, Nov 20") rather than a countdown.
 *
 * Settings live on the e-Transfer payment settings (Timing section): due_mode (hours|days), due_days,
 * biz_days (1 = Monday … 7 = Sunday), biz_close (HH:MM, store time).
 */
defined( 'ABSPATH' ) || exit;

add_filter( 'gwnet_form_fields', function ( $f, $d ) {
	$new = array(
		'due_mode'  => array( 'title' => __( 'Deadline counts', 'gwn-email-money-transfer' ), 'type' => 'select', 'default' => 'hours', 'options' => array( 'hours' => __( 'Hours (use "Auto-cancel after" above)', 'gwn-email-money-transfer' ), 'days' => __( 'Business days', 'gwn-email-money-transfer' ) ) ),
		'due_days'  => array( 'title' => __( 'Business days to pay', 'gwn-email-money-transfer' ), 'type' => 'number', 'default' => 3, 'custom_attributes' => array( 'min' => 1, 'max' => 15 ), 'description' => __( 'The deadline is closing time on this business day, counting the day of the order if it came in before closing.', 'gwn-email-money-transfer' ) ),
		'biz_days'  => array( 'title' => __( 'Business days', 'gwn-email-money-transfer' ), 'type' => 'multiselect', 'class' => 'wc-enhanced-select', 'default' => array( '1', '2', '3', '4', '5' ), 'options' => array( '1' => __( 'Monday', 'gwn-email-money-transfer' ), '2' => __( 'Tuesday', 'gwn-email-money-transfer' ), '3' => __( 'Wednesday', 'gwn-email-money-transfer' ), '4' => __( 'Thursday', 'gwn-email-money-transfer' ), '5' => __( 'Friday', 'gwn-email-money-transfer' ), '6' => __( 'Saturday', 'gwn-email-money-transfer' ), '7' => __( 'Sunday', 'gwn-email-money-transfer' ) ) ),
		'biz_close' => array( 'title' => __( 'Closing time', 'gwn-email-money-transfer' ), 'type' => 'time', 'default' => '21:00', 'description' => __( 'Store time zone (Settings → General).', 'gwn-email-money-transfer' ) ),
	);
	$out = array();
	foreach ( $f as $k => $v ) {
		$out[ $k ] = $v;
		if ( 'cancel_hours' === $k ) {
			$out += $new;
		}
	}
	return $out;
}, 10, 2 );

function gwnetp_days_mode() {
	return 'days' === gwnet_s( 'due_mode' );
}

/** Closing time on the Nth business day from $start (timestamp). */
function gwnetp_business_deadline( $start, $n ) {
	$tz    = wp_timezone();
	$days  = array_map( 'intval', (array) ( gwnet_s( 'biz_days' ) ?: array( 1, 2, 3, 4, 5 ) ) );
	$days  = $days ? $days : array( 1, 2, 3, 4, 5 );
	$close = preg_match( '/^(\d{1,2}):(\d{2})$/', (string) gwnet_s( 'biz_close' ), $m ) ? array( (int) $m[1], (int) $m[2] ) : array( 21, 0 );
	$d     = ( new DateTimeImmutable( '@' . (int) $start ) )->setTimezone( $tz );
	$count = 0;
	for ( $i = 0; $i < 60; $i++ ) {
		$day      = $d->modify( '+' . $i . ' days' );
		$close_at = $day->setTime( $close[0], $close[1] );
		if ( ! in_array( (int) $day->format( 'N' ), $days, true ) || ( 0 === $i && $start >= $close_at->getTimestamp() ) ) {
			continue;
		}
		if ( ++$count >= max( 1, (int) $n ) ) {
			return $close_at->getTimestamp();
		}
	}
	return (int) $start + max( 1, (int) $n ) * DAY_IN_SECONDS;
}

add_filter( 'gwnet_due_time', function ( $due, $start ) {
	return gwnetp_days_mode() ? gwnetp_business_deadline( $start, (int) gwnet_s( 'due_days' ) ) : $due;
}, 10, 2 );

add_filter( 'gwnet_live_countdown', function ( $on ) {
	return gwnetp_days_mode() ? false : $on;
} );

add_filter( 'gwnet_left_text', function ( $t, $ts ) {
	return gwnetp_days_mode() ? wp_date( 'l, M j', $ts ) : $t;
}, 10, 2 );

add_filter( 'gwnet_deadline_phrase', function ( $p, $order ) {
	if ( ! gwnetp_days_mode() ) {
		return $p;
	}
	/* translators: %s: date */
	return $order ? sprintf( __( 'by %s', 'gwn-email-money-transfer' ), wp_date( 'l, M j', gwnet_due( $order ) ) ) : sprintf( _n( 'within %d business day', 'within %d business days', (int) gwnet_s( 'due_days' ), 'gwn-email-money-transfer' ), (int) gwnet_s( 'due_days' ) );
}, 10, 2 );

add_filter( 'gwnet_hold_phrase', function ( $p ) {
	if ( ! gwnetp_days_mode() ) {
		return $p;
	}
	$n = (int) gwnet_s( 'due_days' );
	/* translators: %d: number of business days */
	return sprintf( _n( 'We hold your items for %d business day.', 'We hold your items for %d business days.', $n, 'gwn-email-money-transfer' ), $n );
} );

/* With business days, "Auto-cancel after (hours)" isn't the deadline: keep cancelling on (any non-zero value). */
add_filter( 'gwnet_settings', function ( $s ) {
	if ( 'days' === ( $s['due_mode'] ?? '' ) && empty( $s['cancel_hours'] ) ) {
		$s['cancel_hours'] = 72;
	}
	return $s;
}, 5 );

/* Settings screen: the business-day rows only show when "Deadline counts" is Business days. */
add_action( 'admin_footer', function () {
	if ( ! isset( $_GET['section'] ) || GWNET_ID !== $_GET['section'] ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	?>
	<script>
	( function () {
		var p = 'woocommerce_<?php echo esc_js( GWNET_ID ); ?>_', mode = document.getElementById( p + 'due_mode' );
		if ( ! mode ) { return; }
		function sync() {
			[ 'due_days', 'biz_days', 'biz_close' ].forEach( function ( k ) {
				var el = document.getElementById( p + k ), tr = el && el.closest( 'tr' );
				if ( tr ) { tr.style.display = 'days' === mode.value ? '' : 'none'; }
			} );
		}
		mode.addEventListener( 'change', sync );
		if ( window.jQuery ) { jQuery( mode ).on( 'change', sync ); }
		sync();
	}() );
	</script>
	<?php
} );
