<?php
/**
 * Settings, order helpers, scheduling (reminder + auto-cancel), actions and the "I've sent it" REST route.
 *
 * Order meta: _etr_answer, _etr_due, _etr_sent, _etr_reminded, _etr_overdue, _etr_expired,
 *             _etr_paid_at, _etr_paid_amount, _etr_paid_by, _etr_ref
 */
defined( 'ABSPATH' ) || exit;

/* =========================================================================
 * Settings
 * ========================================================================= */

function gwnet_defaults() {
	return array(
		'enabled'         => 'yes',
		'title'           => __( 'e-Transfer', 'gwn-email-money-transfer' ),
		'recipient_email' => '',
		'recipient_name'  => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
		'autodeposit'     => 'no',
		'question'        => __( 'What is the code for your order?', 'gwn-email-money-transfer' ),
		'answer_mode'     => 'random', // random | order (prefix + order number) | fixed
		'answer_prefix'   => 'ORDER',
		'answer_fixed'    => '',
		'reminder_hours'  => 24,
		'cancel_hours'    => 72,
		'confirm_time'    => __( 'within a few hours', 'gwn-email-money-transfer' ),
		'button_text'     => __( 'Place order and get e-Transfer details', 'gwn-email-money-transfer' ),
		'how_collapse'    => 'no',
		'sent_button'     => 'no',
		'notify_sent'     => 'yes',
		'help_url'        => '',
		'color_accent'    => '#2F3A8F',
		'color_highlight' => '#FFD43B',
		'color_text'      => '#1B1B1F',
		'color_panel'     => '#FFFFFF',
		'radius'          => 16,
		'shadow'          => 'soft',
	);
}

/** Optional Interac logo (none bundled). */
function gwnet_logo_uri() {
	// No Interac logo is bundled (it's Interac's trademark). A store licensed to use it can supply its own:
	// add_filter( 'gwnet_logo_url', fn() => 'https://…/interac-logo.png' );
	return (string) apply_filters( 'gwnet_logo_url', '' );
}

function gwnet_logo_img( $size = 28, $class = 'etr-logo' ) {
	if ( ! gwnet_logo_uri() ) { return ''; }
	return '<img class="' . esc_attr( $class ) . '" src="' . esc_url( gwnet_logo_uri() ) . '" width="' . (int) $size . '" height="' . (int) $size . '" alt="Interac">';
}

/** One setting (with defaults). Cached per request; the cache is dropped when settings are saved. */
function gwnet_s( $key ) {
	if ( empty( $GLOBALS['gwnet_opt_cache'] ) ) {
		$opts = wp_parse_args( (array) get_option( 'woocommerce_' . GWNET_ID . '_settings', array() ), gwnet_defaults() );
		// Other plugins can supply settings, e.g. GWND Fulfillment's Look tab sets the panel colours.
		$GLOBALS['gwnet_opt_cache'] = (array) apply_filters( 'gwnet_settings', $opts );
	}
	return $GLOBALS['gwnet_opt_cache'][ $key ] ?? null;
}
foreach ( array( 'add_option_', 'update_option_' ) as $gwnet_hook ) {
	add_action( $gwnet_hook . 'woocommerce_' . GWNET_ID . '_settings', function () { $GLOBALS['gwnet_opt_cache'] = null; } );
}
unset( $gwnet_hook );

/** Public alias for themes/templates. */
function gwnet_opt( $key ) {
	return gwnet_s( $key );
}

function gwnet_email() {
	$e = trim( (string) gwnet_s( 'recipient_email' ) );
	// An example address left in the setting isn't a real one: treat it as not set.
	if ( preg_match( '/@(yourstore\.|example\.)/i', $e ) ) {
		return '';
	}
	return is_email( $e ) ? $e : '';
}

function gwnet_cancel_hours() {
	return max( 0, (int) gwnet_s( 'cancel_hours' ) );
}

/* =========================================================================
 * Order helpers
 * ========================================================================= */

function gwnet_is( $order ) {
	return $order instanceof WC_Order && GWNET_ID === $order->get_payment_method();
}

/** Waiting on the customer's e-Transfer (on-hold, not yet marked paid). */
function gwnet_awaiting( $order ) {
	return gwnet_is( $order ) && $order->has_status( 'on-hold' ) && ! $order->get_meta( '_etr_paid_at' );
}

/**
 * Clean + validate a security answer (Interac: 3–25 characters). Letters and numbers only.
 *
 * @return string|WP_Error
 */
function gwnet_clean_answer( $a ) {
	$a = preg_replace( '/[^A-Za-z0-9]/', '', (string) $a );
	if ( strlen( $a ) < 3 || strlen( $a ) > 25 ) {
		return new WP_Error( 'etr_answer', __( 'The security answer must be 3–25 letters or numbers (no spaces or symbols).', 'gwn-email-money-transfer' ) );
	}
	return $a;
}

/** Answer a new order gets from the settings (per-order or one fixed answer). */
function gwnet_default_answer( $order ) {
	if ( 'fixed' === gwnet_s( 'answer_mode' ) ) {
		$fixed = gwnet_clean_answer( gwnet_s( 'answer_fixed' ) );
		if ( ! is_wp_error( $fixed ) ) { return $fixed; }
	}
	if ( 'random' === gwnet_s( 'answer_mode' ) ) {
		// 8 letters and digits, no look-alikes (0/O, 1/I/L). Nothing in the e-Transfer itself gives it away.
		$chars = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
		$a     = '';
		for ( $i = 0; $i < 8; $i++ ) {
			$a .= $chars[ wp_rand( 0, strlen( $chars ) - 1 ) ];
		}
		return $a;
	}
	$a = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) gwnet_s( 'answer_prefix' ) ) ) . preg_replace( '/[^0-9A-Za-z]/', '', (string) $order->get_order_number() );
	if ( strlen( $a ) < 3 ) { $a = str_pad( $a, 3, '0', STR_PAD_LEFT ); }
	return substr( $a, 0, 25 );
}

/** The order's answer: saved at checkout (or edited later), else the settings default. */
function gwnet_answer( $order ) {
	$a = (string) $order->get_meta( '_etr_answer' );
	if ( '' === $a && 'random' === gwnet_s( 'answer_mode' ) && gwnet_is( $order ) ) {
		$a = gwnet_default_answer( $order ); // a random answer must be the same every time it's shown
		$order->update_meta_data( '_etr_answer', $a );
		$order->save_meta_data();
	}
	return '' !== $a ? substr( $a, 0, 25 ) : gwnet_default_answer( $order );
}

function gwnet_due( $order ) {
	$due = (int) $order->get_meta( '_etr_due' );
	if ( ! $due ) {
		$c   = $order->get_date_created();
		$due = gwnet_due_from( $c ? $c->getTimestamp() : time() );
	}
	return $due;
}

/** Payment deadline for an order placed at $start (add-ons can count business days instead of hours). */
function gwnet_due_from( $start ) {
	return (int) apply_filters( 'gwnet_due_time', $start + gwnet_cancel_hours() * HOUR_IN_SECONDS, $start, gwnet_cancel_hours() );
}

/** "within 72 hours" — or, with business-day timing, "by Fri, Nov 20". */
function gwnet_deadline_phrase( $order = null ) {
	/* translators: %d: number of hours */
	$p = sprintf( _n( 'within %d hour', 'within %d hours', gwnet_cancel_hours(), 'gwn-email-money-transfer' ), gwnet_cancel_hours() );
	return (string) apply_filters( 'gwnet_deadline_phrase', $p, $order );
}

/** Everything the panels and emails show. */
function gwnet_details( $order ) {
	return array(
		'email'       => gwnet_email(),
		'name'        => (string) gwnet_s( 'recipient_name' ),
		'amount'      => (float) $order->get_total(),
		'amount_txt'  => number_format( (float) $order->get_total(), 2, '.', '' ),
		'amount_html' => wc_price( $order->get_total(), array( 'currency' => $order->get_currency() ) ),
		'autodeposit' => 'yes' === gwnet_s( 'autodeposit' ),
		'question'    => (string) gwnet_s( 'question' ),
		'answer'      => gwnet_answer( $order ),
		/* translators: %s: order number */ 'message'     => sprintf( __( 'Order #%s', 'gwn-email-money-transfer' ), $order->get_order_number() ),
		'due'         => gwnet_due( $order ),
		'sent'        => (int) $order->get_meta( '_etr_sent' ),
		'paid'        => (int) $order->get_meta( '_etr_paid_at' ),
	);
}

function gwnet_when( $ts ) {
	/* translators: PHP date format for payment deadlines, e.g. "Sat, Nov 21 at 2:51 pm" */
	return wp_date( _x( 'D, M j \a\t g:i a', 'deadline date format', 'gwn-email-money-transfer' ), $ts );
}

function gwnet_left( $ts ) {
	$s = $ts - time();
	if ( $s <= 0 ) { return __( 'past due', 'gwn-email-money-transfer' ); }
	$h = floor( $s / HOUR_IN_SECONDS );
	$m = floor( ( $s % HOUR_IN_SECONDS ) / MINUTE_IN_SECONDS );
	/* translators: 1: hours, 2: minutes */
	$t = $h >= 1 ? sprintf( __( '%1$dh %2$02dm left', 'gwn-email-money-transfer' ), $h, $m ) : sprintf( __( '%dm left', 'gwn-email-money-transfer' ), max( 1, $m ) );
	return (string) apply_filters( 'gwnet_left_text', $t, $ts );
}

function gwnet_money( $amount ) {
	return html_entity_decode( wp_strip_all_tags( wc_price( $amount ) ), ENT_QUOTES );
}

function gwnet_view_url( $order ) {
	return $order->get_customer_id() ? $order->get_view_order_url() : $order->get_checkout_order_received_url();
}

function gwnet_help_url() {
	$u = trim( (string) gwnet_s( 'help_url' ) );
	return $u ? esc_url( $u ) : '';
}

/* =========================================================================
 * Scheduling: reminder + auto-cancel
 * ========================================================================= */

function gwnet_schedule( $order ) {
	if ( ! function_exists( 'as_schedule_single_action' ) ) { return; }
	$args = array( 'order_id' => $order->get_id() );
	gwnet_unschedule( $order->get_id() );
	$created = $order->get_date_created() ? $order->get_date_created()->getTimestamp() : time();
	$rh = (int) gwnet_s( 'reminder_hours' );
	$ch = gwnet_cancel_hours();
	if ( $rh > 0 && ( ! $ch || $rh < $ch ) ) {
		as_schedule_single_action( (int) apply_filters( 'gwnet_reminder_time', $created + $rh * HOUR_IN_SECONDS, $created, $rh, $order ), 'gwnet_reminder', $args, GWNET_GROUP );
	}
	if ( $ch > 0 ) {
		as_schedule_single_action( gwnet_due( $order ), 'gwnet_expire', $args, GWNET_GROUP );
	}
}

function gwnet_unschedule( $order_id ) {
	if ( ! function_exists( 'as_unschedule_all_actions' ) ) { return; }
	$args = array( 'order_id' => (int) $order_id );
	as_unschedule_all_actions( 'gwnet_reminder', $args, GWNET_GROUP );
	as_unschedule_all_actions( 'gwnet_expire', $args, GWNET_GROUP );
}

add_action( 'gwnet_reminder', function ( $order_id ) {
	$order = wc_get_order( $order_id );
	if ( ! $order || ! gwnet_awaiting( $order ) || $order->get_meta( '_etr_sent' ) ) { return; }
	gwnet_send_reminder( $order, false );
} );

add_action( 'gwnet_expire', 'gwnet_expire' );
function gwnet_expire( $order_id ) {
	$order = wc_get_order( $order_id );
	if ( ! $order || ! gwnet_awaiting( $order ) ) { return; }
	if ( $order->get_meta( '_etr_sent' ) ) {
		// The customer says it's on its way: give it extra time (3 days by default), then cancel like any
		// other unpaid order, so a tap on "I've sent it" can't hold stock forever.
		$grace = (int) apply_filters( 'gwnet_sent_grace', 3 * DAY_IN_SECONDS, $order );
		$until = gwnet_due( $order ) + $grace;
		if ( ! $order->get_meta( '_etr_overdue' ) ) {
			$order->update_meta_data( '_etr_overdue', time() );
			$order->save();
			/* translators: %s: date and time */
			$order->add_order_note( sprintf( __( 'e-Transfer deadline passed, but the customer said they sent it. Check your bank, then mark it paid or cancel it. If nothing is recorded, it will be cancelled automatically on %s.', 'gwn-email-money-transfer' ), gwnet_when( $until ) ) );
		}
		if ( time() < $until ) {
			if ( function_exists( 'as_schedule_single_action' ) && ! as_next_scheduled_action( 'gwnet_expire', array( 'order_id' => $order->get_id() ), GWNET_GROUP ) ) {
				as_schedule_single_action( $until, 'gwnet_expire', array( 'order_id' => $order->get_id() ), GWNET_GROUP );
			}
			return;
		}
	}
	$order->update_meta_data( '_etr_expired', time() );
	$order->save();
	/* translators: %s: deadline, e.g. "within 72 hours" */
	$order->update_status( 'cancelled', sprintf( __( 'No Interac e-Transfer received %s, so it was cancelled automatically and restocked.', 'gwn-email-money-transfer' ), gwnet_deadline_phrase( $order ) ) );
	gwnet_send_customer_mail(
		$order,
		/* translators: %s: order number */
		sprintf( __( 'Order #%s was cancelled: no payment received', 'gwn-email-money-transfer' ), $order->get_order_number() ),
		__( 'Your order was cancelled', 'gwn-email-money-transfer' ),
		'<p class="etr-mail-hi">' . esc_html( gwnet_hi( $order ) ) . '</p>'
		/* translators: 1: order number, 2: deadline, e.g. "within 72 hours" */
		. '<p>' . sprintf( esc_html__( 'We didn\'t receive an Interac e-Transfer for order %1$s %2$s, so we\'ve cancelled it and released the items.', 'gwn-email-money-transfer' ), '<b>#' . esc_html( $order->get_order_number() ) . '</b>', esc_html( gwnet_deadline_phrase( $order ) ) ) . '</p>'
		. '<p>' . esc_html__( 'Already sent it? Just reply to this email and we\'ll sort it out right away.', 'gwn-email-money-transfer' ) . '</p>'
		. '<p class="etr-mail-cta"><a class="etr-mail-btn" href="' . esc_url( wc_get_page_permalink( 'shop' ) ) . '">' . esc_html__( 'Shop again', 'gwn-email-money-transfer' ) . '</a></p>'
	);
}

/* Leaving on-hold stops the timers; re-opening restarts them; manual → processing counts as paid. */
add_action( 'woocommerce_order_status_changed', function ( $id, $from, $to, $order ) {
	delete_transient( 'gwnet_count' );
	if ( ! gwnet_is( $order ) ) { return; }
	if ( 'on-hold' !== $to ) { gwnet_unschedule( $id ); }
	if ( 'on-hold' === $to && in_array( $from, array( 'cancelled', 'failed' ), true ) && ! $order->get_meta( '_etr_paid_at' ) ) {
		$order->update_meta_data( '_etr_due', gwnet_due_from( time() ) );
		$order->delete_meta_data( '_etr_expired' );
		$order->delete_meta_data( '_etr_overdue' );
		$order->save();
		gwnet_schedule( $order );
	}
	if ( in_array( $to, array( 'processing', 'completed' ), true ) && ! $order->get_meta( '_etr_paid_at' ) ) {
		$order->update_meta_data( '_etr_paid_at', time() );
		$order->update_meta_data( '_etr_paid_by', 'status change' );
		$order->save();
	}
}, 10, 4 );

/* =========================================================================
 * Actions (admin panel, order box, REST)
 * ========================================================================= */

/** @return true|WP_Error */
function gwnet_mark_paid( $order, $amount = null, $ref = '', $force = false ) {
	if ( ! gwnet_is( $order ) ) { return new WP_Error( 'etr', __( 'Not an e-Transfer order.', 'gwn-email-money-transfer' ) ); }
	if ( $order->get_meta( '_etr_paid_at' ) || $order->is_paid() ) { return new WP_Error( 'etr', __( 'Already marked paid.', 'gwn-email-money-transfer' ) ); }
	$total  = (float) $order->get_total();
	$amount = ( null === $amount || '' === $amount ) ? $total : (float) wc_format_decimal( $amount );
	if ( $amount + 0.009 < $total && ! $force ) {
		/* translators: 1: amount received, 2: order total */
		return new WP_Error( 'etr_short', sprintf( __( 'Received %1$s but the order total is %2$s. Tick "Mark paid even if the amount is short" to confirm anyway.', 'gwn-email-money-transfer' ), gwnet_money( $amount ), gwnet_money( $total ) ) );
	}
	$ref  = sanitize_text_field( (string) $ref );
	$user = wp_get_current_user();
	$by   = $user && $user->exists() ? $user->display_name : __( 'automatic', 'gwn-email-money-transfer' );
	$order->update_meta_data( '_etr_paid_at', time() );
	$order->update_meta_data( '_etr_paid_amount', $amount );
	$order->update_meta_data( '_etr_paid_by', $by );
	if ( $ref ) { $order->update_meta_data( '_etr_ref', $ref ); }
	$order->save();
	$diff = $amount - $total;
	if ( abs( $diff ) >= 0.01 ) {
		/* translators: %s: amount */
		$diff_note = ' ' . sprintf( $diff > 0 ? __( '(%s over the order total)', 'gwn-email-money-transfer' ) : __( '(%s SHORT of the order total)', 'gwn-email-money-transfer' ), gwnet_money( abs( $diff ) ) );
	} else {
		$diff_note = '';
	}
	/* translators: 1: amount, 2: over/short note, 3: bank reference note, 4: person */
	$order->add_order_note( sprintf( __( 'Interac e-Transfer received: %1$s%2$s%3$s. Marked paid by %4$s.', 'gwn-email-money-transfer' ), gwnet_money( $amount ), $diff_note, $ref ? ' · ' . sprintf( /* translators: %s: bank reference */ __( 'ref %s', 'gwn-email-money-transfer' ), $ref ) : '', $by ) );
	gwnet_unschedule( $order->get_id() );
	$order->payment_complete( $ref );
	return true;
}

/** @return true|WP_Error */
function gwnet_set_answer( $order, $answer, $notify = false ) {
	if ( ! gwnet_awaiting( $order ) ) { return new WP_Error( 'etr', __( 'Only orders awaiting payment can have their answer changed.', 'gwn-email-money-transfer' ) ); }
	$new = gwnet_clean_answer( $answer );
	if ( is_wp_error( $new ) ) { return $new; }
	$old = gwnet_answer( $order );
	if ( $new === $old ) { return new WP_Error( 'etr', __( 'That is already the answer.', 'gwn-email-money-transfer' ) ); }
	$order->update_meta_data( '_etr_answer', $new );
	$order->save();
	$user = wp_get_current_user();
	/* translators: 1: old answer, 2: new answer, 3: person */
	$order->add_order_note( sprintf( __( 'e-Transfer security answer changed from %1$s to %2$s by %3$s.', 'gwn-email-money-transfer' ), $old, $new, $user && $user->exists() ? $user->display_name : __( 'automatic', 'gwn-email-money-transfer' ) ) );
	if ( $notify ) {
		$sent = gwnet_send_customer_mail(
			$order,
			/* translators: %s: order number */
			sprintf( __( 'Updated e-Transfer details for order #%s', 'gwn-email-money-transfer' ), $order->get_order_number() ),
			__( 'Your security answer changed', 'gwn-email-money-transfer' ),
			'<p class="etr-mail-hi">' . esc_html( gwnet_hi( $order ) ) . '</p>'
			/* translators: %s: order number */
			. '<p>' . sprintf( esc_html__( 'Quick update on order %s: please use the new security answer below when you send your Interac e-Transfer.', 'gwn-email-money-transfer' ), '<b>#' . esc_html( $order->get_order_number() ) . '</b>' ) . '</p>'
			. gwnet_mail_panel( $order )
			. '<p class="etr-mail-fine">' . esc_html__( 'Already sent it with the old answer? No problem, we\'ll still match it.', 'gwn-email-money-transfer' ) . ' <a href="' . esc_url( gwnet_view_url( $order ) ) . '">' . esc_html__( 'View your order', 'gwn-email-money-transfer' ) . '</a></p>'
		);
		if ( $sent ) { $order->add_order_note( __( 'Customer emailed the new security answer.', 'gwn-email-money-transfer' ) ); }
	}
	return true;
}

function gwnet_send_reminder( $order, $manual = false ) {
	$d  = gwnet_details( $order );
	$ok = gwnet_send_customer_mail(
		$order,
		/* translators: %s: order number */
		sprintf( __( 'Reminder: send your e-Transfer for order #%s', 'gwn-email-money-transfer' ), $order->get_order_number() ),
		__( 'Your order is still waiting', 'gwn-email-money-transfer' ),
		'<p class="etr-mail-hi">' . esc_html( gwnet_hi( $order ) ) . '</p>'
		/* translators: %s: order number */
		. '<p>' . sprintf( esc_html__( 'Your order %s is still on hold: we haven\'t seen your Interac e-Transfer yet.', 'gwn-email-money-transfer' ), '<b>#' . esc_html( $order->get_order_number() ) . '</b>' )
		/* translators: %s: deadline date and time */
		. ( gwnet_cancel_hours() > 0 ? ' ' . sprintf( esc_html__( 'Send it by %s and we\'ll get it moving as soon as it lands.', 'gwn-email-money-transfer' ), '<b>' . esc_html( gwnet_when( $d['due'] ) ) . '</b>' ) : '' ) . '</p>'
		. gwnet_mail_panel( $order )
		. '<p class="etr-mail-fine">' . esc_html__( 'Already sent it? You can ignore this: it can take a little while to show up on our side.', 'gwn-email-money-transfer' ) . ' <a href="' . esc_url( gwnet_view_url( $order ) ) . '">' . esc_html__( 'View your order', 'gwn-email-money-transfer' ) . '</a></p>'
	);
	if ( $ok ) {
		$order->update_meta_data( '_etr_reminded', time() );
		$order->save();
		$order->add_order_note( $manual ? __( 'e-Transfer reminder emailed to the customer (sent manually).', 'gwn-email-money-transfer' ) : __( 'e-Transfer reminder emailed to the customer.', 'gwn-email-money-transfer' ) );
	}
	return $ok;
}

function gwnet_send_customer_mail( $order, $subject, $heading, $body ) {
	$mailer = WC()->mailer();
	return $mailer->send( $order->get_billing_email(), $subject, $mailer->wrap_message( $heading, $body ) );
}

function gwnet_notify_store_sent( $order ) {
	$mailer = WC()->mailer();
	$emails = $mailer->get_emails();
	$to     = isset( $emails['WC_Email_New_Order'] ) ? $emails['WC_Email_New_Order']->get_recipient() : get_option( 'admin_email' );
	$d      = gwnet_details( $order );
	/* translators: 1: customer name, 2: order number */
	$body   = '<p>' . sprintf( esc_html__( '%1$s says they\'ve sent their Interac e-Transfer for order %2$s.', 'gwn-email-money-transfer' ), '<b>' . esc_html( $order->get_formatted_billing_full_name() ) . '</b>', '<b>#' . esc_html( $order->get_order_number() ) . '</b>' ) . '</p>'
		. '<table class="etr-mail__tbl" cellpadding="0" cellspacing="0" width="100%" role="presentation">'
		. '<tr><td class="k">' . esc_html__( 'Amount', 'gwn-email-money-transfer' ) . '</td><td class="v">' . wp_kses_post( $d['amount_html'] ) . '</td></tr>'
		. ( $d['autodeposit'] ? '' : '<tr><td class="k">' . esc_html__( 'Answer', 'gwn-email-money-transfer' ) . '</td><td class="v">' . esc_html( $d['answer'] ) . '</td></tr>' )
		. '<tr><td class="k">' . esc_html__( 'Customer', 'gwn-email-money-transfer' ) . '</td><td class="v">' . esc_html( $order->get_billing_email() ) . '</td></tr></table>'
		. '<p class="etr-mail-cta"><a class="etr-mail-btn" href="' . esc_url( $order->get_edit_order_url() ) . '">' . esc_html__( 'Open the order', 'gwn-email-money-transfer' ) . '</a></p>';
	/* translators: 1: order number, 2: amount */
	$mailer->send( $to, sprintf( __( 'e-Transfer sent for order #%1$s (%2$s)', 'gwn-email-money-transfer' ), $order->get_order_number(), gwnet_money( $d['amount'] ) ), $mailer->wrap_message( __( 'Customer sent an e-Transfer', 'gwn-email-money-transfer' ), $body ) );
}

/* =========================================================================
 * REST: customer taps "I've sent it" (verified by order key; works for guests)
 * ========================================================================= */

/**
 * Who may use the two routes: only when the store has the "I've sent it" button on, and only with the
 * order's own key (timing-safe compare; a wrong key and a missing order look the same).
 */
function gwnet_rest_order_permission( WP_REST_Request $r ) {
	if ( 'yes' !== gwnet_s( 'sent_button' ) ) {
		return new WP_Error( 'rest_no_route', __( 'No route was found matching the URL and request method.', 'gwn-email-money-transfer' ), array( 'status' => 404 ) );
	}
	$order = wc_get_order( absint( $r['order'] ) );
	if ( ! $order instanceof WC_Order || ! gwnet_is( $order ) || ! is_string( $r['key'] ) || ! hash_equals( $order->get_order_key(), $r['key'] ) ) {
		return new WP_Error( 'etr', __( 'Order not found.', 'gwn-email-money-transfer' ), array( 'status' => 404 ) );
	}
	return true;
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'etransfer/v1', '/sent', array(
		'methods'             => 'POST',
		'permission_callback' => 'gwnet_rest_order_permission',
		'args'                => array( 'order' => array( 'required' => true ), 'key' => array( 'required' => true ) ),
		'callback'            => function ( WP_REST_Request $r ) {
			$order = wc_get_order( absint( $r['order'] ) );
			if ( ! gwnet_awaiting( $order ) ) {
				return array( 'ok' => true, 'already' => true, 'sent' => '' );
			}
			$sent = (int) $order->get_meta( '_etr_sent' );
			if ( ! $sent ) {
				$first = (int) $order->get_meta( '_etr_sent_first' );
				$sent  = $first ?: time(); // after an Undo, the 15-minute window doesn't start over
				$order->update_meta_data( '_etr_sent', $sent );
				if ( ! $first ) {
					$order->update_meta_data( '_etr_sent_first', $sent );
				}
				$notify = 'yes' === gwnet_s( 'notify_sent' ) && ! $order->get_meta( '_etr_notified' );
				if ( $notify ) {
					$order->update_meta_data( '_etr_notified', time() ); // the store hears about it once per order
				}
				$order->save();
				if ( ! $first ) {
					$order->add_order_note( __( 'Customer says they\'ve sent the Interac e-Transfer.', 'gwn-email-money-transfer' ) );
				}
				if ( $notify ) {
					gwnet_notify_store_sent( $order );
				}
				if ( function_exists( 'as_unschedule_all_actions' ) ) {
					as_unschedule_all_actions( 'gwnet_reminder', array( 'order_id' => $order->get_id() ), GWNET_GROUP );
				}
			}
			/* translators: %s: date */
			return array( 'ok' => true, 'sent' => sprintf( __( 'Marked as sent %s.', 'gwn-email-money-transfer' ), wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $sent ) ) . ' ' );
		},
	) );
	// "Undo" right after tapping "I've sent it" by mistake: once per order, within 15 minutes of the first tap.
	register_rest_route( 'etransfer/v1', '/unsent', array(
		'methods'             => 'POST',
		'permission_callback' => 'gwnet_rest_order_permission',
		'args'                => array( 'order' => array( 'required' => true ), 'key' => array( 'required' => true ) ),
		'callback'            => function ( WP_REST_Request $r ) {
			$order = wc_get_order( absint( $r['order'] ) );
			$first = (int) ( $order->get_meta( '_etr_sent_first' ) ?: $order->get_meta( '_etr_sent' ) );
			if ( ! $order->get_meta( '_etr_sent' ) || $order->get_meta( '_etr_undone' ) || ! gwnet_awaiting( $order ) || time() - $first > 15 * MINUTE_IN_SECONDS ) {
				return new WP_Error( 'etr', __( 'Too late to undo.', 'gwn-email-money-transfer' ), array( 'status' => 409 ) );
			}
			$order->delete_meta_data( '_etr_sent' );
			$order->update_meta_data( '_etr_undone', time() );
			$order->save();
			$order->add_order_note( __( 'Customer undid "I\'ve sent it".', 'gwn-email-money-transfer' ) );
			// Put the auto-cancel back. No reminder: the customer is on the page right now.
			if ( function_exists( 'as_schedule_single_action' ) && gwnet_cancel_hours() > 0 ) {
				as_unschedule_all_actions( 'gwnet_expire', array( 'order_id' => $order->get_id() ), GWNET_GROUP );
				as_schedule_single_action( max( time() + MINUTE_IN_SECONDS, gwnet_due( $order ) ), 'gwnet_expire', array( 'order_id' => $order->get_id() ), GWNET_GROUP );
			}
			return array( 'ok' => true );
		},
	) );
} );

/** Greeting for customer emails: "Hi Emma," (or "Hi there,"). */
function gwnet_hi( $order ) {
	$name = $order instanceof WC_Order ? $order->get_billing_first_name() : '';
	/* translators: %s: customer's first name */
	return $name ? sprintf( __( 'Hi %s,', 'gwn-email-money-transfer' ), $name ) : __( 'Hi there,', 'gwn-email-money-transfer' );
}
