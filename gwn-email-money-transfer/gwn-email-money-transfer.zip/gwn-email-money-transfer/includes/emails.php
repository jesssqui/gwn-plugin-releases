<?php
/**
 * Email pay panel (on-hold, reminder, answer-changed emails) + email CSS.
 * Email-safe: tables only, no CSS variables; colours come from the plugin settings.
 */
defined( 'ABSPATH' ) || exit;

function gwnet_mail_panel( $order ) {
	$d      = gwnet_details( $order );
	$rows   = array( array( __( 'Amount', 'gwn-email-money-transfer' ), '<b style="font-size:20px">' . wp_kses_post( $d['amount_html'] ) . '</b> ' . esc_html__( '(exact)', 'gwn-email-money-transfer' ) ) );
	$rows[] = array( __( 'Send to', 'gwn-email-money-transfer' ), $d['email'] ? '<b>' . esc_html( $d['email'] ) . '</b>' : esc_html__( 'Payment email coming soon', 'gwn-email-money-transfer' ) );
	if ( $d['name'] ) { $rows[] = array( __( 'Recipient name', 'gwn-email-money-transfer' ), esc_html( $d['name'] ) ); }
	if ( ! $d['autodeposit'] ) {
		$rows[] = array( __( 'Security question', 'gwn-email-money-transfer' ), esc_html( $d['question'] ) );
		$rows[] = array( __( 'Answer', 'gwn-email-money-transfer' ), '<span class="etr-mail__answer">' . esc_html( $d['answer'] ) . '</span>' );
	}
	$rows[] = array( __( 'Message', 'gwn-email-money-transfer' ), esc_html( $d['message'] ) );

	$h  = '<table class="etr-mail" cellpadding="0" cellspacing="0" width="100%" role="presentation">';
	$h .= '<tr><td class="etr-mail__head"><p class="etr-mail__kicker">' . esc_html__( 'Interac e-Transfer', 'gwn-email-money-transfer' ) . '</p><p class="etr-mail__title">' . esc_html__( 'Send your payment to finish your order', 'gwn-email-money-transfer' ) . '</p>';
	if ( gwnet_cancel_hours() > 0 ) {
		/* translators: %s: deadline date and time */
		$h .= '<p class="etr-mail__due">' . esc_html( sprintf( __( 'Send by %s. Your order is held until then.', 'gwn-email-money-transfer' ), gwnet_when( $d['due'] ) ) ) . '</p>';
	}
	$h .= '</td></tr><tr><td class="etr-mail__body"><table class="etr-mail__tbl" cellpadding="0" cellspacing="0" width="100%" role="presentation">';
	foreach ( $rows as $r ) {
		$h .= '<tr><td class="k">' . esc_html( $r[0] ) . '</td><td class="v">' . $r[1] . '</td></tr>';
	}
	$tip = $d['autodeposit'] ? __( 'Open your bank\'s app → Interac e-Transfer → add us as a recipient → send the exact amount. We\'ll get your order moving as soon as it lands.', 'gwn-email-money-transfer' ) : __( 'Open your bank\'s app → Interac e-Transfer → add us as a recipient → send the exact amount with the question and answer above. We\'ll get your order moving as soon as it lands.', 'gwn-email-money-transfer' );
	$h .= '</table><p class="etr-mail__tip">' . esc_html( $tip ) . '</p></td></tr></table>';
	return $h;
}

function gwnet_mail_panel_plain( $order ) {
	$d  = gwnet_details( $order );
	$t  = "\n==== " . strtoupper( __( 'Send your Interac e-Transfer', 'gwn-email-money-transfer' ) ) . " ====\n";
	/* translators: %s: amount */
	$t .= sprintf( __( 'Amount: %s (exact)', 'gwn-email-money-transfer' ), gwnet_money( $d['amount'] ) ) . "\n";
	/* translators: %s: email address */
	$t .= sprintf( __( 'Send to: %s', 'gwn-email-money-transfer' ), $d['email'] ?: __( 'payment email coming soon', 'gwn-email-money-transfer' ) ) . "\n";
	/* translators: %s: name */
	if ( $d['name'] ) { $t .= sprintf( __( 'Recipient name: %s', 'gwn-email-money-transfer' ), $d['name'] ) . "\n"; }
	if ( ! $d['autodeposit'] ) {
		/* translators: %s: security question */
		$t .= sprintf( __( 'Security question: %s', 'gwn-email-money-transfer' ), $d['question'] ) . "\n";
		/* translators: %s: security answer */
		$t .= sprintf( __( 'Answer: %s', 'gwn-email-money-transfer' ), $d['answer'] ) . "\n";
	}
	/* translators: %s: message to include */
	$t .= sprintf( __( 'Message: %s', 'gwn-email-money-transfer' ), $d['message'] ) . "\n";
	/* translators: %s: deadline */
	if ( gwnet_cancel_hours() > 0 ) { $t .= sprintf( __( 'Send by: %s', 'gwn-email-money-transfer' ), gwnet_when( $d['due'] ) ) . "\n"; }
	return $t . "======================================\n\n";
}

add_action( 'woocommerce_email_before_order_table', function ( $order, $sent_to_admin, $plain, $email = null ) {
	if ( ! gwnet_is( $order ) ) { return; }
	$id = $email && isset( $email->id ) ? $email->id : '';
	if ( 'customer_on_hold_order' === $id && gwnet_awaiting( $order ) ) {
		echo $plain ? gwnet_mail_panel_plain( $order ) : gwnet_mail_panel( $order ); // phpcs:ignore
	} elseif ( $sent_to_admin && 'new_order' === $id && gwnet_awaiting( $order ) ) {
		$line = __( 'Awaiting Interac e-Transfer', 'gwn-email-money-transfer' ) . ( 'yes' === gwnet_s( 'autodeposit' ) ? '' : ' · ' . sprintf( /* translators: %s: answer */ __( 'security answer %s', 'gwn-email-money-transfer' ), gwnet_answer( $order ) ) ) . ' · ' . __( 'mark it paid from the order screen', 'gwn-email-money-transfer' );
		echo $plain ? "\n" . $line . "\n\n" : '<p class="etr-mail-note">' . esc_html( $line ) . '</p>'; // phpcs:ignore
	}
}, 5, 4 );

add_filter( 'woocommerce_email_subject_customer_on_hold_order', function ( $subject, $order ) {
	/* translators: %s: order number */
	return gwnet_is( $order ) ? sprintf( __( 'Send your e-Transfer to complete order #%s', 'gwn-email-money-transfer' ), $order->get_order_number() ) : $subject;
}, 20, 2 );
add_filter( 'woocommerce_email_heading_customer_on_hold_order', function ( $heading, $order ) {
	return gwnet_is( $order ) ? __( 'One last step: pay by e-Transfer', 'gwn-email-money-transfer' ) : $heading;
}, 20, 2 );

add_filter( 'woocommerce_email_styles', function ( $css ) {
	$ink    = gwnet_color( 'color_text' );
	$accent = gwnet_color( 'color_accent' );
	$on_acc = gwnet_on( $accent, $ink );
	$hi     = gwnet_color( 'color_highlight' );
	$on_hi  = gwnet_on( $hi, $ink );
	$r      = max( 0, min( 30, (int) gwnet_s( 'radius' ) ) );
	return $css . "
#body_content_inner .etr-mail { border: 2px solid {$ink} !important; border-radius: {$r}px !important; border-collapse: separate !important; margin: 6px 0 26px !important; overflow: hidden; }
#body_content_inner .etr-mail__head { background-color: {$accent} !important; padding: 18px 22px !important; }
#body_content_inner .etr-mail__kicker { margin: 0 0 4px !important; font-size: 11px !important; font-weight: bold !important; letter-spacing: 1px; text-transform: uppercase; color: {$on_acc} !important; opacity: .85; }
#body_content_inner .etr-mail__title { margin: 0 !important; font-size: 20px !important; font-weight: 800 !important; line-height: 1.2 !important; color: {$on_acc} !important; }
#body_content_inner .etr-mail__due { margin: 8px 0 0 !important; font-size: 14px !important; color: {$on_acc} !important; }
#body_content_inner .etr-mail__body { background-color: #ffffff !important; padding: 8px 22px 18px !important; }
#body_content_inner .etr-mail__tbl td { padding: 10px 0 !important; border-bottom: 1px solid #e7e7ec !important; font-size: 15px !important; vertical-align: top; }
#body_content_inner .etr-mail__tbl td.k { width: 140px; font-size: 11px !important; font-weight: bold !important; text-transform: uppercase; letter-spacing: 1px; opacity: .75; padding-top: 13px !important; }
#body_content_inner .etr-mail__tbl td.v { font-weight: bold !important; word-break: break-all; }
#body_content_inner .etr-mail__answer { display: inline-block; background-color: {$hi}; color: {$on_hi}; border: 2px solid {$ink}; border-radius: 8px; padding: 2px 10px; font-family: Menlo, Consolas, monospace; font-size: 17px; letter-spacing: 1px; }
#body_content_inner .etr-mail__tip { margin: 14px 0 0 !important; font-size: 13px !important; opacity: .85; }
#body_content_inner .etr-mail-hi { font-size: 17px !important; font-weight: bold !important; }
#body_content_inner .etr-mail-fine { font-size: 13px !important; opacity: .85; }
#body_content_inner .etr-mail-cta { margin: 24px 0 8px !important; text-align: center; }
#body_content_inner .etr-mail-note { border: 2px dashed {$ink} !important; border-radius: 12px !important; padding: 10px 14px !important; font-weight: bold !important; }
.etr-mail-btn { display: inline-block; background-color: {$accent} !important; color: {$on_acc} !important; border-radius: 999px !important; padding: 12px 24px !important; font-weight: bold !important; text-decoration: none !important; }
";
}, 30 );

/* =========================================================================
 * "Processing order" email after Mark paid → reads as a payment confirmation.
 * Only for e-Transfer orders that were marked paid; other orders keep WooCommerce's wording.
 * ========================================================================= */

/** Paid e-Transfer order (marked paid in the admin panel)? */
function gwnet_paid_order( $order ) {
	return gwnet_is( $order ) && $order->get_meta( '_etr_paid_at' );
}

add_filter( 'woocommerce_email_subject_customer_processing_order', function ( $subject, $order ) {
	/* translators: %s: order number */
	return gwnet_paid_order( $order ) ? sprintf( __( 'Payment received: order #%s is being packed', 'gwn-email-money-transfer' ), $order->get_order_number() ) : $subject;
}, 20, 2 );
add_filter( 'woocommerce_email_heading_customer_processing_order', function ( $heading, $order ) {
	return gwnet_paid_order( $order ) ? __( 'Payment received!', 'gwn-email-money-transfer' ) : $heading;
}, 20, 2 );

/* Swap the intro line while the processing template (HTML or plain) renders for a paid e-Transfer order. */
add_action( 'woocommerce_before_template_part', function ( $name, $path, $located, $args ) {
	if ( in_array( $name, array( 'emails/customer-processing-order.php', 'emails/plain/customer-processing-order.php' ), true )
		&& ! empty( $args['order'] ) && gwnet_paid_order( $args['order'] ) ) {
		$GLOBALS['gwnet_mail_paid'] = $args['order'];
	}
}, 10, 4 );
add_action( 'woocommerce_after_template_part', function ( $name ) {
	if ( in_array( $name, array( 'emails/customer-processing-order.php', 'emails/plain/customer-processing-order.php' ), true ) ) {
		unset( $GLOBALS['gwnet_mail_paid'] );
	}
} );
add_filter( 'gettext', function ( $t, $text, $domain ) {
	if ( 'woocommerce' !== $domain || empty( $GLOBALS['gwnet_mail_paid'] ) ) { return $t; }
	$order  = $GLOBALS['gwnet_mail_paid'];
	$amount = $order->get_meta( '_etr_paid_amount' );
	$amount = gwnet_money( '' !== $amount && null !== $amount ? (float) $amount : $order->get_total() );
	switch ( $text ) {
		case 'Just to let you know &mdash; we’ve received your order, and it is now being processed.':
			return sprintf( 'We’ve received your Interac e-Transfer of %s — thank you! Your order is now being packed, and we’ll let you know as soon as it ships.', $amount );
		case 'Just to let you know &mdash; we\'ve received your order #%s, and it is now being processed:':
			return 'We’ve received your Interac e-Transfer for order #%s — thank you! It’s now being packed, and we’ll let you know as soon as it ships:';
		case 'Here’s a reminder of what you’ve ordered:':
			return 'Here’s what’s in your order:';
	}
	return $t;
}, 20, 3 );

/* On-hold email for an e-Transfer order: swap WooCommerce's "on hold until we confirm payment" line, which
   repeats the pay box, for one short line. */
add_action( 'woocommerce_before_template_part', function ( $name, $path, $located, $args ) {
	if ( in_array( $name, array( 'emails/customer-on-hold-order.php', 'emails/plain/customer-on-hold-order.php' ), true )
		&& ! empty( $args['order'] ) && gwnet_awaiting( $args['order'] ) ) {
		$GLOBALS['gwnet_mail_hold'] = $args['order'];
	}
}, 10, 4 );
add_action( 'woocommerce_after_template_part', function ( $name ) {
	if ( in_array( $name, array( 'emails/customer-on-hold-order.php', 'emails/plain/customer-on-hold-order.php' ), true ) ) {
		unset( $GLOBALS['gwnet_mail_hold'] );
	}
} );
add_filter( 'gettext_woocommerce', function ( $t, $text ) {
	if ( empty( $GLOBALS['gwnet_mail_hold'] ) ) {
		return $t;
	}
	$hold = array(
		'Thanks for your order. It’s on-hold until we confirm that payment has been received.',
		'Thanks for your order. It’s on-hold until we confirm that payment has been received. In the meantime, here’s a reminder of what you ordered:',
		'We’ve received your order and it’s currently on hold until we can confirm your payment has been processed.',
		'Just to let you know &mdash; we&#39;ve received your order, and it is now on hold until we confirm payment.',
	);
	if ( in_array( $text, $hold, true ) || false !== strpos( $text, 'on hold until we can confirm your payment' ) ) {
		return __( 'Your order is reserved. Send your e-Transfer using the details below and we\'ll start packing as soon as it lands.', 'gwn-email-money-transfer' );
	}
	if ( 'Here’s a reminder of what you’ve ordered:' === $text ) {
		return __( 'Here\'s what you ordered:', 'gwn-email-money-transfer' );
	}
	return $t;
}, 20, 2 );
