<?php
/**
 * Admin-only branding: who made it and where the docs live.
 * Shown on the Plugins screen, the e-Transfers inbox and this gateway's settings. Never on the storefront,
 * in customer emails or in checkout markup.
 */
defined( 'ABSPATH' ) || exit;

/** Is the current admin screen one of ours (inbox or this gateway's settings section)? */
function gwnet_is_own_screen() {
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only screen check
	$page    = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
	$section = isset( $_GET['section'] ) ? sanitize_key( wp_unslash( $_GET['section'] ) ) : '';
	// phpcs:enable
	return GWNET_PAGE === $page || ( 'wc-settings' === $page && GWNET_ID === $section );
}

/** Small studio mark + credit line, used in the footer of our screens. */
function gwnet_brand_line() {
	return sprintf(
		'<span class="gwnet-brand"><img src="%1$s" width="18" height="18" alt=""> %2$s</span>',
		esc_url( GWNET_URL . 'assets/gwnd-mark.svg' ),
		wp_kses(
			sprintf(
				/* translators: 1: plugin name and version, 2: link to the studio, 3: link to docs */
				__( '%1$s is free from %2$s. %3$s', 'gwn-email-money-transfer' ),
				'<b>GWN Email Money Transfer ' . esc_html( GWNET_VERSION ) . '</b>',
				'<a href="https://greatwhitenorthdesign.ca/" target="_blank" rel="noopener">Great White North Design</a>',
				'<a href="' . esc_url( GWNET_HOME ) . '" target="_blank" rel="noopener">' . esc_html__( 'Docs & support', 'gwn-email-money-transfer' ) . '</a>'
			),
			array( 'b' => array(), 'a' => array( 'href' => array(), 'target' => array(), 'rel' => array() ) )
		)
	);
}

/* Plugins screen: docs link under the description. */
add_filter( 'plugin_row_meta', function ( $meta, $file ) {
	if ( plugin_basename( GWNET_FILE ) === $file ) {
		$meta[] = '<a href="' . esc_url( GWNET_HOME ) . '" target="_blank" rel="noopener">' . esc_html__( 'Docs & support', 'gwn-email-money-transfer' ) . '</a>';
	}
	return $meta;
}, 10, 2 );

/* Our screens: replace the "Thank you for creating with WordPress" line with the credit. */
add_filter( 'admin_footer_text', function ( $text ) {
	return gwnet_is_own_screen() ? gwnet_brand_line() : $text;
}, 20 );

/* Our screens: the studio mark beside the page title, and the footer line's layout. */
add_action( 'admin_head', function () {
	if ( ! gwnet_is_own_screen() ) {
		return;
	}
	$mark = esc_url( GWNET_URL . 'assets/gwnd-mark.svg' );
	?>
	<style>
	.gwnet-brand{display:inline-flex;align-items:center;gap:8px;font-style:normal}
	.gwnet-brand img{display:block}
	.etra h1{display:flex;align-items:center;gap:10px}
	.etra h1::before{content:"";width:28px;height:28px;flex:0 0 28px;background:url("<?php echo $mark; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- esc_url above ?>") no-repeat center/contain}
	</style>
	<?php
} );
