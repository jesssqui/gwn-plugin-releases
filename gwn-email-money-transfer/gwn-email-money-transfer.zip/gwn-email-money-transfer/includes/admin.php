<?php
/**
 * Admin: WooCommerce → e-Transfers panel, order-screen box, actions.
 */
defined( 'ABSPATH' ) || exit;

function gwnet_awaiting_orders( $limit = 200 ) {
	return wc_get_orders( array( 'payment_method' => GWNET_ID, 'status' => array( 'wc-on-hold' ), 'limit' => $limit, 'orderby' => 'date', 'order' => 'ASC' ) );
}

/* Handle panel / order-box actions. */
add_action( 'admin_post_gwnet', function () {
	$id   = absint( $_REQUEST['order'] ?? 0 );
	$do   = sanitize_key( $_REQUEST['do'] ?? '' );
	$back = wp_get_referer() ?: admin_url( 'admin.php?page=wc-orders' );
	$back = remove_query_arg( array( 'etr_msg', 'etr_err' ), $back );
	if ( ! current_user_can( 'edit_shop_orders' ) || ! check_admin_referer( 'gwnet_' . $id ) ) { wp_die( esc_html__( 'Not allowed.', 'gwn-email-money-transfer' ) ); }
	$order = wc_get_order( $id );
	if ( ! $order || ! gwnet_is( $order ) ) { wp_safe_redirect( add_query_arg( 'etr_err', rawurlencode( __( 'Order not found.', 'gwn-email-money-transfer' ) ), $back ) ); exit; }
	$num = '#' . $order->get_order_number();
	switch ( $do ) {
		case 'paid':
			$r = gwnet_mark_paid( $order, sanitize_text_field( wp_unslash( $_POST['amount'] ?? '' ) ), sanitize_text_field( wp_unslash( $_POST['ref'] ?? '' ) ), ! empty( $_POST['force'] ) );
			$q = is_wp_error( $r ) ? array( 'etr_err' => rawurlencode( $num . ': ' . $r->get_error_message() ) ) : array( /* translators: %s: order number */ 'etr_msg' => rawurlencode( sprintf( __( '%s marked paid. The customer has been emailed and it\'s ready to pack.', 'gwn-email-money-transfer' ), $num ) ) );
			break;
		case 'answer':
			$r = gwnet_set_answer( $order, sanitize_text_field( wp_unslash( $_POST['answer'] ?? '' ) ), ! empty( $_POST['notify'] ) );
			$q = is_wp_error( $r ) ? array( 'etr_err' => rawurlencode( $num . ': ' . $r->get_error_message() ) ) : array( /* translators: 1: order number, 2: answer */ 'etr_msg' => rawurlencode( sprintf( ! empty( $_POST['notify'] ) ? __( '%1$s security answer is now %2$s. The customer has been emailed.', 'gwn-email-money-transfer' ) : __( '%1$s security answer is now %2$s.', 'gwn-email-money-transfer' ), $num, gwnet_answer( $order ) ) ) );
			break;
		case 'remind':
			$q = gwnet_awaiting( $order ) && gwnet_send_reminder( $order, true ) ? array( /* translators: %s: order number */ 'etr_msg' => rawurlencode( sprintf( __( 'Reminder sent for %s.', 'gwn-email-money-transfer' ), $num ) ) ) : array( /* translators: %s: order number */ 'etr_err' => rawurlencode( sprintf( __( 'Couldn\'t send a reminder for %s.', 'gwn-email-money-transfer' ), $num ) ) );
			break;
		case 'cancel':
			if ( gwnet_awaiting( $order ) ) {
				$order->update_status( 'cancelled', __( 'Cancelled from the e-Transfers screen (no payment) and restocked.', 'gwn-email-money-transfer' ) );
				/* translators: %s: order number */
				$q = array( 'etr_msg' => rawurlencode( sprintf( __( '%s cancelled and restocked.', 'gwn-email-money-transfer' ), $num ) ) );
			} else {
				/* translators: %s: order number */
				$q = array( 'etr_err' => rawurlencode( sprintf( __( '%s isn\'t waiting for payment.', 'gwn-email-money-transfer' ), $num ) ) );
			}
			break;
		default:
			$q = array();
	}
	delete_transient( 'gwnet_count' );
	if ( $q ) {
		set_transient( 'gwnet_notice_' . get_current_user_id(), $q, 5 * MINUTE_IN_SECONDS );
	}
	wp_safe_redirect( $back );
	exit;
} );

function gwnet_admin_notice_from_query() {
	// The result of the last action, saved for this user only (never read from the URL).
	$q = get_transient( 'gwnet_notice_' . get_current_user_id() );
	if ( ! is_array( $q ) ) {
		return;
	}
	delete_transient( 'gwnet_notice_' . get_current_user_id() );
	if ( ! empty( $q['etr_msg'] ) ) {
		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( rawurldecode( (string) $q['etr_msg'] ) ) . '</p></div>';
	}
	if ( ! empty( $q['etr_err'] ) ) {
		echo '<div class="notice notice-error is-dismissible"><p>' . esc_html( rawurldecode( (string) $q['etr_err'] ) ) . '</p></div>';
	}
}

/* Notices on other admin screens (order edit) after a box action. */
add_action( 'admin_notices', function () {
	if ( isset( $_GET['page'] ) && GWNET_PAGE === sanitize_key( wp_unslash( $_GET['page'] ) ) ) { return; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- printed inside the panel
	gwnet_admin_notice_from_query();
} );

/* Order edit screen: e-Transfer box (HPOS + legacy). */
add_action( 'add_meta_boxes', function ( $screen = '', $object = null ) {
	$order = $object instanceof WC_Order ? $object : ( $object instanceof WP_Post ? wc_get_order( $object->ID ) : null );
	if ( ! $order || ! gwnet_is( $order ) ) {
		return; // only e-Transfer orders get the box
	}
	$screens = array( 'shop_order' );
	if ( function_exists( 'wc_get_page_screen_id' ) ) { $screens[] = wc_get_page_screen_id( 'shop-order' ); }
	foreach ( array_unique( $screens ) as $s ) {
		add_meta_box( 'etr-box', __( 'Interac e-Transfer', 'gwn-email-money-transfer' ), 'gwnet_order_box', $s, 'side', 'high' );
	}
}, 10, 2 );

function gwnet_order_box( $post_or_order ) {
	$o = $post_or_order instanceof WC_Order ? $post_or_order : wc_get_order( $post_or_order->ID ?? 0 );
	if ( ! $o || ! gwnet_is( $o ) ) {
		echo '<p class="description">' . esc_html__( 'Not an e-Transfer order.', 'gwn-email-money-transfer' ) . '</p>';
		return;
	}
	$d = gwnet_details( $o );
	echo '<div class="etra etra--box">';
	if ( $d['paid'] ) {
		echo '<p><span class="etra__chip is-lime">' . esc_html__( 'Paid', 'gwn-email-money-transfer' ) . '</span> ' . esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $d['paid'] ) ) . '</p>';
		$amt = $o->get_meta( '_etr_paid_amount' );
		/* translators: %s: amount received */
		if ( '' !== $amt && null !== $amt ) { echo '<p>' . wp_kses_post( sprintf( __( 'Received %s', 'gwn-email-money-transfer' ), wc_price( $amt ) ) ) . '</p>'; }
		/* translators: %s: bank reference */
		if ( $o->get_meta( '_etr_ref' ) ) { echo '<p>' . esc_html( sprintf( __( 'Bank reference: %s', 'gwn-email-money-transfer' ), $o->get_meta( '_etr_ref' ) ) ) . '</p>'; }
	} elseif ( gwnet_awaiting( $o ) ) {
		/* translators: %s: amount */
		echo '<p><b>' . wp_kses_post( sprintf( __( 'Waiting for %s', 'gwn-email-money-transfer' ), $d['amount_html'] ) ) . '</b>';
		if ( ! $d['autodeposit'] ) { echo '<br>' . esc_html__( 'Answer:', 'gwn-email-money-transfer' ) . ' <code>' . esc_html( $d['answer'] ) . '</code>'; }
		if ( (int) gwnet_s( 'cancel_hours' ) > 0 ) { echo '<br>' . esc_html( $d['due'] > time() ? gwnet_left( $d['due'] ) . ' · ' . gwnet_when( $d['due'] ) : __( 'Past due', 'gwn-email-money-transfer' ) ) ; }
		echo '</p>';
		/* translators: %s: time since, e.g. "5 mins" */
		if ( $d['sent'] ) { echo '<p><span class="etra__chip is-lime">' . esc_html__( 'Customer says sent', 'gwn-email-money-transfer' ) . '</span> ' . esc_html( sprintf( __( '%s ago', 'gwn-email-money-transfer' ), human_time_diff( $d['sent'] ) ) ) . '</p>'; }
		echo '</div>';
		// The order screen wraps meta boxes in its own <form>, so these controls post via a small script.
		gwnet_order_box_actions( $o );
		gwnet_admin_css();
		return;
	} else {
		/* translators: %s: order status */
		echo '<p>' . esc_html( sprintf( __( '%s: no payment recorded.', 'gwn-email-money-transfer' ), wc_get_order_status_name( $o->get_status() ) ) ) . '</p>';
	}
	echo '</div>';
	gwnet_admin_css();
}

/**
 * The order edit screen wraps meta boxes in its own <form>, so nested forms won't submit.
 * Use plain inputs + buttons that post via a small script to admin-post.php instead.
 */
function gwnet_order_box_actions( $o ) {
	$nonce = wp_create_nonce( 'gwnet_' . $o->get_id() );
	?>
	<div class="etra etra--box" data-etra-box data-order="<?php echo (int) $o->get_id(); ?>" data-nonce="<?php echo esc_attr( $nonce ); ?>" data-url="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<div class="etra__pay" data-group="paid">
			<label><span><?php esc_html_e( 'Amount received', 'gwn-email-money-transfer' ); ?></span><input type="number" step="0.01" min="0" data-f="amount" value="<?php echo esc_attr( number_format( (float) $o->get_total(), 2, '.', '' ) ); ?>"></label>
			<label><span><?php esc_html_e( 'Bank reference', 'gwn-email-money-transfer' ); ?></span><input type="text" data-f="ref" placeholder="<?php esc_attr_e( 'optional', 'gwn-email-money-transfer' ); ?>"></label>
			<label class="etra__force"><input type="checkbox" data-f="force" value="1"> <?php esc_html_e( 'Mark paid even if the amount is short', 'gwn-email-money-transfer' ); ?></label>
			<button type="button" class="button button-primary" data-do="paid"><?php esc_html_e( 'Mark paid', 'gwn-email-money-transfer' ); ?></button>
		</div>
		<div class="etra__minor"><button type="button" class="button-link" data-do="remind"><?php esc_html_e( 'Send reminder', 'gwn-email-money-transfer' ); ?></button></div>
		<?php if ( 'yes' !== gwnet_s( 'autodeposit' ) ) : ?>
			<details class="etra__ans etra__ans--box">
				<summary><?php esc_html_e( 'Change security answer', 'gwn-email-money-transfer' ); ?></summary>
				<div class="etra__ansform" data-group="answer">
					<input type="text" data-f="answer" value="<?php echo esc_attr( gwnet_answer( $o ) ); ?>" maxlength="25">
					<label><input type="checkbox" data-f="notify" value="1" checked> <?php esc_html_e( 'Email the customer the new answer', 'gwn-email-money-transfer' ); ?></label>
					<button type="button" class="button" data-do="answer"><?php esc_html_e( 'Save answer', 'gwn-email-money-transfer' ); ?></button>
				</div>
			</details>
		<?php endif; ?>
	</div>
	<script>
	(function(){
		var box=document.querySelector('[data-etra-box]'); if(!box||box.dataset.bound) return; box.dataset.bound=1;
		box.addEventListener('click',function(e){
			var b=e.target.closest('[data-do]'); if(!b) return; e.preventDefault();
			var f=document.createElement('form'); f.method='post'; f.action=box.dataset.url;
			var add=function(k,v){var i=document.createElement('input'); i.type='hidden'; i.name=k; i.value=v; f.appendChild(i);};
			add('action','gwnet'); add('do',b.dataset.do); add('order',box.dataset.order); add('_wpnonce',box.dataset.nonce); add('_wp_http_referer',location.pathname+location.search);
			var scope=b.closest('[data-group]')||box.querySelector('.etra__pay');
			if(b.dataset.do!=='remind') scope.querySelectorAll('[data-f]').forEach(function(i){ if(i.type!=='checkbox'||i.checked) add(i.dataset.f,i.value); });
			document.body.appendChild(f); f.submit();
		});
	})();
	</script>
	<?php
}

function gwnet_admin_css() {
	static $done = false;
	if ( $done ) { return; }
	$done = true;
	?>
	<style>
	.etra{--ink:#17111F;--violet:<?php echo esc_attr( gwnet_color( 'color_accent' ) ); ?>;--lime:<?php echo esc_attr( gwnet_color( 'color_highlight' ) ); ?>;--on-violet:<?php echo esc_attr( gwnet_on( gwnet_color( 'color_accent' ), '#17111F' ) ); ?>;--on-lime:<?php echo esc_attr( gwnet_on( gwnet_color( 'color_highlight' ), '#17111F' ) ); ?>;--pink:#FF4D8D;--orange:#FFB020;--lilac:#EFEAFF;--paper:#FFFCF5}
	.etra__top{display:flex;justify-content:space-between;align-items:flex-start;gap:20px;margin:10px 0 14px}
	.etra h1{font-size:23px;font-weight:400;margin:0 0 6px;padding:0}
	.etra__sub{margin:0;color:#50575e;font-size:13px;max-width:780px}
	.etra__stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:16px 0 18px}
	.etra__stat{display:grid;gap:2px;padding:14px 16px;background:#fff;border:1px solid #dcdcde;border-left:4px solid #dcdcde;border-radius:4px}
	.etra__stat span{font-size:11px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:#50575e}
	.etra__stat b{font-size:26px;line-height:1.15;font-weight:600;color:#1d2327}
	.etra__stat small{font-size:12px;color:#646970}
	.etra__stat.is-violet{border-left-color:var(--violet)}.etra__stat.is-lime{border-left-color:#00a32a}.etra__stat.is-orange{border-left-color:#dba617}.etra__stat.is-pink{border-left-color:#d63638}
	.etra__tabs{display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin:0 0 12px}
	.etra__tabs a{padding:5px 12px;border:1px solid #c3c4c7;border-radius:999px;background:#fff;color:#2c3338;font-weight:500;text-decoration:none}
	.etra__tabs a.is-on{background:#1d2327;border-color:#1d2327;color:#fff}
	.etra__tabs a:focus{box-shadow:0 0 0 2px #2271b1;outline:0}
	.etra .etra__search{margin-left:auto;min-width:300px;padding:4px 12px;border:1px solid #8c8f94;border-radius:4px}
	.etra__list{display:grid;gap:8px}
	.etra__row{display:grid;grid-template-columns:100px minmax(160px,1.1fr) 160px minmax(150px,.9fr) minmax(380px,1.7fr);gap:16px;align-items:center;padding:12px 16px;background:#fff;border:1px solid #dcdcde;border-left:4px solid transparent;border-radius:4px}
	.etra__row.is-history{grid-template-columns:100px minmax(160px,1.1fr) 170px minmax(200px,1fr) 130px}
	.etra__row.is-sent{border-left-color:#00a32a}
	.etra__row.is-late{border-left-color:#d63638}
	.etra__cell{display:grid;gap:4px;min-width:0}
	.etra__order a{font-size:15px;font-weight:600;text-decoration:none;color:#2271b1}
	.etra__order span,.etra__cust span,.etra__muted{font-size:12px;color:#646970;overflow:hidden;text-overflow:ellipsis}
	.etra__cust b{font-size:13px}
	.etra code{justify-self:start;background:var(--lime);color:var(--on-lime);border-radius:3px;padding:1px 6px;font-weight:600;font-size:12px}
	.etra__copy{justify-self:start;border:0;background:none;padding:0;cursor:copy;font-size:18px;font-weight:600;color:#1d2327}
	.etra__copy.is-done::after{content:" \2713";font-size:12px;color:#00a32a}
	.etra__chip{justify-self:start;display:inline-block;padding:1px 8px;border-radius:999px;background:#f0f0f1;color:#2c3338;font-size:11.5px;font-weight:600}
	.etra__chip.is-lime{background:#edfaef;color:#007017}.etra__chip.is-pink{background:#fcf0f1;color:#b32d2e}
	.etra__due{font-weight:600;font-size:13px}.is-soon .etra__due{color:#996800}.is-late .etra__due{color:#b32d2e}
	.etra__pay{display:flex;flex-wrap:wrap;align-items:center;gap:8px}
	.etra__pay label{display:inline-flex;align-items:center;gap:4px;font-size:12px;font-weight:500}
	.etra__pay input[type=number]{width:90px}.etra__pay input[type=text]{width:110px}
	.etra .etra__force{font-weight:400;color:#50575e}
	.etra__minor{display:flex;gap:14px;margin-top:4px}.etra__minor form{margin:0}
	.etra .etra__danger{color:#b32d2e}
	.etra__empty{display:grid;gap:4px;padding:30px;text-align:center;background:#fff;border:1px dashed #c3c4c7;border-radius:4px}
	.etra__empty b{font-size:16px;font-weight:600}
	.etra__ans{justify-self:start}
	.etra__ans summary{cursor:pointer;list-style:none;display:inline-flex;align-items:center;gap:6px}
	.etra__ans summary::-webkit-details-marker{display:none}
	.etra__ans summary span{font-size:11.5px;color:#2271b1;text-decoration:underline}
	.etra__ansform{display:flex;flex-wrap:wrap;align-items:center;gap:6px;margin-top:8px;padding:8px;background:#f6f7f7;border:1px solid #dcdcde;border-radius:4px}
	.etra__ansform input[type=text]{width:130px;font-family:ui-monospace,Menlo,monospace;font-weight:600;text-transform:none}
	.etra__ansform label{font-size:12px}
	.etra__ans--box{margin-top:10px}.etra__ans--box summary{color:#2271b1;text-decoration:underline}
	.etra__ans--box .etra__ansform{display:grid}.etra__ans--box .etra__ansform input[type=text]{width:100%}
	.etra--box p{margin:0 0 8px}
	.etra--box .etra__pay{display:grid;gap:8px;margin-top:6px}.etra--box .etra__pay input[type=number],.etra--box .etra__pay input[type=text]{width:100%}
	.etra--box .etra__pay label{display:grid;gap:2px}.etra--box .etra__force{display:flex;gap:6px}
	@media (max-width:1500px){.etra__row{grid-template-columns:90px 1fr 150px 1fr}.etra__actions{grid-column:1/-1;padding-top:10px;border-top:1px solid #f0f0f1}.etra__row.is-history{grid-template-columns:90px 1fr 150px 1fr 120px}.etra__row.is-history .etra__actions{grid-column:auto;padding:0;border:0}}
	@media (max-width:782px){.etra__stats{grid-template-columns:1fr 1fr}.etra__row,.etra__row.is-history{grid-template-columns:1fr 1fr}.etra .etra__search{min-width:0;width:100%;margin-left:0}}
	.etra .etra__force{display:flex!important;flex-direction:row!important;gap:6px;align-items:center;font-size:12px}.etra .etra__force input{margin:0}
	</style>
	<?php
}
