<?php
/**
 * Customer side: checkout box, pay panel (thank-you page + My Account), assets.
 *
 * Themes with a custom thank-you template can call gwnet_panel( $order ) wherever they like;
 * the default woocommerce_thankyou_{gateway} output is skipped once the panel has been printed.
 */
defined( 'ABSPATH' ) || exit;

/* =========================================================================
 * Checkout box
 * ========================================================================= */

function gwnet_checkout_box_html() {
	$h = gwnet_cancel_hours();
	ob_start();
	?>
	<div class="etr-co">
		<p class="etr-co__lead"><?php echo wp_kses( __( '<b>Pay by Interac e-Transfer</b> from any Canadian bank. No card needed.', 'gwn-email-money-transfer' ), array( 'b' => array() ) ); ?></p>
		<ol class="etr-co__steps">
			<li><span>1</span><div><b><?php esc_html_e( 'Place your order', 'gwn-email-money-transfer' ); ?></b>
				<?php
				/* translators: %s: how long items are held, e.g. "72 hours" */
				echo $h ? ' ' . esc_html( (string) apply_filters( 'gwnet_hold_phrase', sprintf( __( 'We hold your items for %s.', 'gwn-email-money-transfer' ), sprintf( _n( '%d hour', '%d hours', $h, 'gwn-email-money-transfer' ), $h ) ) ) ) : '';
				?>
			</div></li>
			<li><span>2</span><div><b><?php esc_html_e( 'Send the e-Transfer', 'gwn-email-money-transfer' ); ?></b> <?php echo esc_html( 'yes' === gwnet_s( 'autodeposit' ) ? __( 'using the email we show you next (we email it too).', 'gwn-email-money-transfer' ) : __( 'using the email, question and answer we show you next (we email them too).', 'gwn-email-money-transfer' ) ); ?></div></li>
			<li><span>3</span><div><b><?php esc_html_e( 'We ship once it lands', 'gwn-email-money-transfer' ); ?></b>
				<?php
				/* translators: %s: e.g. "within a few hours" */
				echo esc_html( sprintf( __( 'We confirm payments %s.', 'gwn-email-money-transfer' ), gwnet_s( 'confirm_time' ) ) );
				?>
			</div></li>
		</ol>
	</div>
	<?php
	return trim( ob_get_clean() );
}

function gwnet_checkout_box() {
	echo gwnet_checkout_box_html(); // phpcs:ignore -- escaped above
}

/* =========================================================================
 * Pay panel
 * ========================================================================= */

function gwnet_copy_row( $label, $value, $display = null, $class = '' ) {
	$display = null === $display ? esc_html( $value ) : $display;
	?>
	<div class="etr__row <?php echo esc_attr( $class ); ?>">
		<dt><?php echo esc_html( $label ); ?></dt>
		<dd>
			<span class="etr__val"><?php echo $display; // phpcs:ignore -- escaped by caller ?></span>
			<?php /* translators: %s: field name, e.g. "amount" */ ?>
			<button type="button" class="etr__copy" data-etr-copy="<?php echo esc_attr( $value ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Copy %s', 'gwn-email-money-transfer' ), strtolower( $label ) ) ); ?>"><?php esc_html_e( 'Copy', 'gwn-email-money-transfer' ); ?></button>
		</dd>
	</div>
	<?php
}

/**
 * Print the pay panel for an order.
 *
 * @param WC_Order $order
 * @param string   $context 'thankyou' | 'account'
 */
function gwnet_panel( $order, $context = 'thankyou' ) {
	if ( ! gwnet_is( $order ) ) { return; }
	$GLOBALS['gwnet_panel_done'][ $order->get_id() ] = true;
	gwnet_enqueue_assets();
	$d = gwnet_details( $order );

	if ( $order->has_status( 'cancelled' ) ) {
		$help = gwnet_help_url();
		$contact = $help ? '<a href="' . esc_url( $help ) . '">' . esc_html__( 'Contact us', 'gwn-email-money-transfer' ) . '</a>' : esc_html__( 'Reply to your order email', 'gwn-email-money-transfer' );
		/* translators: %s: "Contact us" link or "Reply to your order email" */
		echo '<section class="etr etr--closed"><div class="etr__closed"><span class="etr__badge">' . gwnet_logo_img( 18, 'etr-logo etr-logo--badge' ) . esc_html__( 'Interac e-Transfer', 'gwn-email-money-transfer' ) . '</span><h2 class="etr__closed-title">' . esc_html__( 'This order was cancelled', 'gwn-email-money-transfer' ) . '</h2><p>' . sprintf( esc_html__( 'We didn\'t receive an e-Transfer in time, so the items were released. Already sent it? %s and we\'ll sort it out.', 'gwn-email-money-transfer' ), $contact ) . '</p>' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the logo img and $contact are built from escaped parts
			. '<p><a class="etr__btn etr__btn--ghost" href="' . esc_url( wc_get_page_permalink( 'shop' ) ) . '">' . esc_html__( 'Shop again', 'gwn-email-money-transfer' ) . '</a></p></div></section>'; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped above
		return;
	}
	if ( ! gwnet_awaiting( $order ) ) {
		if ( 'account' === $context && $d['paid'] ) {
			/* translators: %s: date */
			echo '<section class="etr etr--closed etr--paid"><div class="etr__closed"><span class="etr__badge">' . gwnet_logo_img( 18, 'etr-logo etr-logo--badge' ) . esc_html__( 'Interac e-Transfer', 'gwn-email-money-transfer' ) . '</span><h2 class="etr__closed-title">' . esc_html__( 'Payment received', 'gwn-email-money-transfer' ) . ' <span aria-hidden="true">✓</span></h2><p>' . esc_html( sprintf( __( 'Your e-Transfer landed on %s. Thanks!', 'gwn-email-money-transfer' ), wp_date( 'M j, g:i a', $d['paid'] ) ) ) . '</p></div></section>'; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped above
		}
		return;
	}
	$late = $d['due'] <= time();
	?>
	<section class="etr<?php echo $d['sent'] ? ' is-sent' : ''; ?><?php echo 'yes' === gwnet_s( 'how_collapse' ) ? ' etr--collapse-how' : ''; ?> etr--<?php echo esc_attr( $context ); ?>" id="pay" data-etr data-order="<?php echo (int) $order->get_id(); ?>" data-key="<?php echo 'yes' === gwnet_s( 'sent_button' ) ? esc_attr( $order->get_order_key() ) : ''; ?>" data-due="<?php echo (int) $d['due']; ?>" data-tick="<?php echo apply_filters( 'gwnet_live_countdown', true ) ? '1' : '0'; ?>">
		<div class="etr__head">
			<div class="etr__head-copy">
				<span class="etr__badge"><?php echo gwnet_logo_img( 18, 'etr-logo etr-logo--badge' ); // phpcs:ignore ?><?php esc_html_e( 'Interac e-Transfer', 'gwn-email-money-transfer' ); ?></span>
				<?php /* translators: %s: amount */ ?>
				<h2 class="etr__title"><?php echo wp_kses_post( sprintf( __( 'Send %s to finish your order', 'gwn-email-money-transfer' ), '<span class="etr__title-amt">' . $d['amount_html'] . '</span>' ) ); ?></h2>
				<p class="etr__lead"><?php esc_html_e( 'Your order is reserved. Send it from your bank\'s app or online banking and we\'ll get it moving as soon as it lands.', 'gwn-email-money-transfer' ); ?></p>
			</div>
			<?php if ( gwnet_cancel_hours() > 0 ) : ?>
				<div class="etr__due<?php echo $late ? ' is-late' : ''; ?>">
					<span><?php esc_html_e( 'Send by', 'gwn-email-money-transfer' ); ?></span>
					<b data-etr-left><?php echo esc_html( $late ? __( 'Past due', 'gwn-email-money-transfer' ) : gwnet_left( $d['due'] ) ); ?></b>
					<small><?php echo esc_html( gwnet_when( $d['due'] ) ); ?></small>
				</div>
			<?php endif; ?>
		</div>

		<div class="etr__body">
			<dl class="etr__fields">
				<?php
				gwnet_copy_row( __( 'Amount', 'gwn-email-money-transfer' ), $d['amount_txt'], '<b class="etr__amt">' . wp_kses_post( $d['amount_html'] ) . '</b> <em>' . esc_html__( 'exact amount', 'gwn-email-money-transfer' ) . '</em>' );
				if ( $d['email'] ) {
					gwnet_copy_row( __( 'Send to', 'gwn-email-money-transfer' ), $d['email'], null, 'is-email' );
				} else {
					echo '<div class="etr__row is-missing"><dt>' . esc_html__( 'Send to', 'gwn-email-money-transfer' ) . '</dt><dd><span class="etr__val">' . esc_html__( 'Payment email coming soon', 'gwn-email-money-transfer' ) . '</span></dd></div>';
				}
				if ( $d['name'] ) {
					gwnet_copy_row( __( 'Recipient name', 'gwn-email-money-transfer' ), $d['name'] );
				}
				if ( ! $d['autodeposit'] ) {
					gwnet_copy_row( __( 'Security question', 'gwn-email-money-transfer' ), $d['question'] );
					gwnet_copy_row( __( 'Answer', 'gwn-email-money-transfer' ), $d['answer'], '<code class="etr__answer">' . esc_html( $d['answer'] ) . '</code>', 'is-answer' );
				}
				gwnet_copy_row( __( 'Message', 'gwn-email-money-transfer' ), $d['message'], null, 'is-msg' );
				?>
			</dl>

			<details class="etr__how" open>
				<summary class="etr__how-title"><?php esc_html_e( 'How to send it', 'gwn-email-money-transfer' ); ?></summary>
				<ol>
					<li><?php echo wp_kses( __( 'Open your bank\'s app and choose <b>Interac e-Transfer</b> (sometimes under "Send money").', 'gwn-email-money-transfer' ), array( 'b' => array() ) ); ?></li>
					<?php /* translators: 1: recipient name, 2: email */ ?>
					<li><?php echo wp_kses( $d['email'] ? sprintf( __( 'Add <b>%1$s</b> as a recipient using <b>%2$s</b>.', 'gwn-email-money-transfer' ), esc_html( $d['name'] ?: __( 'us', 'gwn-email-money-transfer' ) ), esc_html( $d['email'] ) ) : sprintf( __( 'Add <b>%s</b> as a recipient.', 'gwn-email-money-transfer' ), esc_html( $d['name'] ?: __( 'us', 'gwn-email-money-transfer' ) ) ), array( 'b' => array() ) ); ?></li>
					<li><?php echo wp_kses( $d['autodeposit'] ? __( 'Send the <b>exact amount</b>.', 'gwn-email-money-transfer' ) : __( 'Send the <b>exact amount</b> with the security question and answer shown here.', 'gwn-email-money-transfer' ), array( 'b' => array() ) ); ?></li>
					<?php /* translators: %s: message to include, e.g. "Order #1042" */ ?>
					<li><?php echo wp_kses( sprintf( __( 'Add <b>%s</b> in the message so we can match it fast.', 'gwn-email-money-transfer' ), esc_html( $d['message'] ) ), array( 'b' => array() ) ); ?></li>
				</ol>
				<?php /* translators: %s: email address */ ?>
				<p class="etr__fine"><?php echo wp_kses( sprintf( __( 'These details were also emailed to <b>%s</b>.', 'gwn-email-money-transfer' ), esc_html( $order->get_billing_email() ) ), array( 'b' => array() ) ); ?></p>
			</details>
		</div>

		<?php
		$btn  = 'yes' === gwnet_s( 'sent_button' );
		// Without the button the foot is just a "we confirm payments…" note. Skip it when a theme prints the
		// panel itself on its own thank-you template (it has its own next-steps copy) and nothing's been sent.
		$note = 'account' === $context || doing_action( 'woocommerce_thankyou_' . GWNET_ID );
		if ( $btn || $note || $d['sent'] ) :
		?>
		<div class="etr__foot">
			<?php if ( $btn ) : ?>
			<div class="etr__sent-cta">
				<button type="button" class="etr__btn" data-etr-sent><?php esc_html_e( 'I\'ve sent it', 'gwn-email-money-transfer' ); ?></button>
				<?php /* translators: %s: e.g. "within a few hours" */ ?>
				<span><?php echo esc_html( sprintf( __( 'Tap once you\'ve sent it so we know to watch for it. We confirm payments %s.', 'gwn-email-money-transfer' ), gwnet_s( 'confirm_time' ) ) ); ?></span>
			</div>
			<?php elseif ( $note ) : ?>
			<?php /* translators: %s: e.g. "within a few hours" */ ?>
			<p class="etr__foot-note"><?php echo esc_html( sprintf( __( 'We confirm payments %s and email you as soon as yours lands.', 'gwn-email-money-transfer' ), gwnet_s( 'confirm_time' ) ) ); ?></p>
			<?php endif; ?>
			<div class="etr__sent-ok" role="status">
				<span class="etr__tick" aria-hidden="true">✓</span>
				<?php /* translators: %s: date */ ?>
				<span><b><?php esc_html_e( 'Thanks, we\'re watching for it.', 'gwn-email-money-transfer' ); ?></b> <span data-etr-sent-at><?php echo $d['sent'] ? esc_html( sprintf( __( 'Marked as sent %s.', 'gwn-email-money-transfer' ), wp_date( 'M j, g:i a', $d['sent'] ) ) ) . ' ' : ''; ?></span><?php esc_html_e( 'We\'ll email you the moment it lands.', 'gwn-email-money-transfer' ); ?>
				<button type="button" class="etr__undo" data-etr-undo<?php echo $d['sent'] && ( time() - $d['sent'] ) > 15 * MINUTE_IN_SECONDS ? ' hidden' : ''; ?>><?php esc_html_e( 'Undo', 'gwn-email-money-transfer' ); ?></button></span>
			</div>
		</div>
		<?php endif; ?>
	</section>
	<?php
}

/*
 * Thank-you page: the pay panel goes right under "Order received" and the line asking them to send it,
 * above the order summary, because it's the one thing the customer has to act on.
 * Block themes: before the order confirmation summary block. Classic template: the standard
 * woocommerce_thankyou_{gateway} spot below, which already sits between the overview and the details.
 */
add_filter( 'render_block_woocommerce/order-confirmation-summary', function ( $html ) {
	global $wp;
	$order_id = isset( $wp->query_vars['order-received'] ) ? absint( $wp->query_vars['order-received'] ) : 0;
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	$key      = isset( $_GET['key'] ) ? sanitize_text_field( wp_unslash( $_GET['key'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- WooCommerce's order key, compared with hash_equals below
	if ( ! $order || ! gwnet_is( $order ) || ! hash_equals( $order->get_order_key(), (string) $key ) || ! empty( $GLOBALS['gwnet_panel_done'][ $order_id ] ) || ! gwnet_can_see_thankyou( $order ) ) {
		return $html;
	}
	ob_start();
	gwnet_panel( $order, 'thankyou' );
	return '<div class="alignwide etr-wrap">' . ob_get_clean() . '</div>' . $html; // as wide as the summary below
} );

/* Fallback thank-you placement (standard WooCommerce hook). */
add_action( 'woocommerce_thankyou_' . GWNET_ID, function ( $order_id ) {
	if ( ! empty( $GLOBALS['gwnet_panel_done'][ $order_id ] ) ) { return; }
	gwnet_panel( wc_get_order( $order_id ), 'thankyou' );
}, 5 );

/* "Thank you. Your order has been received." → prompt to pay. */
add_filter( 'woocommerce_thankyou_order_received_text', function ( $text, $order ) {
	return $order && gwnet_awaiting( $order ) ? __( 'Almost done! Your order is reserved. Send your Interac e-Transfer below to complete it.', 'gwn-email-money-transfer' ) : $text;
}, 10, 2 );

/* My Account → order view: panel above the order details. */
add_action( 'woocommerce_view_order', function ( $order_id ) {
	gwnet_panel( wc_get_order( $order_id ), 'account' );
}, 5 );

/* My Account → orders list: "Send e-Transfer" button on awaiting orders. */
add_filter( 'woocommerce_my_account_my_orders_actions', function ( $actions, $order ) {
	if ( gwnet_awaiting( $order ) && is_wc_endpoint_url( 'orders' ) ) {
		$actions = array( 'etr-pay' => array( 'url' => $order->get_view_order_url() . '#pay', 'name' => __( 'Send e-Transfer', 'gwn-email-money-transfer' ) ) ) + $actions;
	}
	return $actions;
}, 10, 2 );

/* =========================================================================
 * Assets
 * ========================================================================= */

function gwnet_hex_rgb( $hex ) {
	$hex = ltrim( (string) $hex, '#' );
	if ( 3 === strlen( $hex ) ) { $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2]; }
	if ( ! preg_match( '/^[0-9a-fA-F]{6}$/', $hex ) ) { return array( 0, 0, 0 ); }
	return array( hexdec( substr( $hex, 0, 2 ) ), hexdec( substr( $hex, 2, 2 ) ), hexdec( substr( $hex, 4, 2 ) ) );
}

/** Black or white text for a background colour. */
function gwnet_on( $hex, $dark = '#111111' ) {
	list( $r, $g, $b ) = gwnet_hex_rgb( $hex );
	$l = ( 0.2126 * $r + 0.7152 * $g + 0.0722 * $b ) / 255;
	return $l > 0.6 ? $dark : '#FFFFFF';
}

function gwnet_color( $key ) {
	$c = sanitize_hex_color( (string) gwnet_s( $key ) );
	return $c ?: gwnet_defaults()[ $key ];
}

function gwnet_css_vars() {
	$ink    = gwnet_color( 'color_text' );
	$accent = gwnet_color( 'color_accent' );
	$hi     = gwnet_color( 'color_highlight' );
	$panel  = gwnet_color( 'color_panel' );
	$r      = max( 0, min( 40, (int) gwnet_s( 'radius' ) ) );
	switch ( gwnet_s( 'shadow' ) ) {
		case 'hard': $sh = "6px 6px 0 {$ink}"; $shs = "3px 3px 0 {$ink}"; $bw = '2.5px'; break;
		case 'none': $sh = 'none'; $shs = 'none'; $bw = '1.5px'; break;
		default:     $sh = '0 10px 30px rgba(0,0,0,.10), 0 2px 6px rgba(0,0,0,.06)'; $shs = '0 2px 6px rgba(0,0,0,.08)'; $bw = '1.5px';
	}
	return sprintf(
		':root{--etr-ink:%1$s;--etr-accent:%2$s;--etr-on-accent:%3$s;--etr-hi:%4$s;--etr-on-hi:%5$s;--etr-panel:%6$s;--etr-soft:color-mix(in srgb,%2$s 9%%,%6$s);--etr-r:%7$dpx;--etr-r-sm:%8$dpx;--etr-shadow:%9$s;--etr-shadow-sm:%10$s;--etr-bw:%11$s}',
		$ink, $accent, gwnet_on( $accent, $ink ), $hi, gwnet_on( $hi, $ink ), $panel, $r, max( 0, (int) round( $r * 0.6 ) ), $sh, $shs, $bw
	);
}

function gwnet_enqueue_assets() {
	static $done = false;
	if ( $done ) { return; }
	$done = true;
	wp_enqueue_style( 'etr', GWNET_URL . 'assets/etr.css', array(), GWNET_VERSION );
	wp_add_inline_style( 'etr', gwnet_css_vars() );
	wp_enqueue_script( 'etr', GWNET_URL . 'assets/etr.js', array(), GWNET_VERSION, true );
	wp_localize_script( 'etr', 'etrCfg', array(
		'sentUrl'  => esc_url_raw( rest_url( 'etransfer/v1/sent' ) ),
		'undoUrl'  => esc_url_raw( rest_url( 'etransfer/v1/unsent' ) ),
		'copied'   => __( 'Copied!', 'gwn-email-money-transfer' ),
		'copy'     => __( 'Copy', 'gwn-email-money-transfer' ),
		'pastDue'  => __( 'Past due', 'gwn-email-money-transfer' ),
		'failed'   => __( 'Couldn\'t save that. Please try again, or reply to your order email.', 'gwn-email-money-transfer' ),
	) );
	// If the panel is printed after wp_head (normal), make sure the style still lands: print it now.
	if ( did_action( 'wp_head' ) && ! doing_action( 'wp_head' ) ) {
		wp_print_styles( 'etr' );
	}
}

add_action( 'wp_enqueue_scripts', function () {
	if ( function_exists( 'is_checkout' ) && ( is_checkout() || is_account_page() ) ) {
		gwnet_enqueue_assets();
	}
}, 20 );

/**
 * The same access rule WooCommerce uses on the order-received page: an order that belongs to an account
 * is only for that customer, signed in; a guest order only shortly after checkout (after that WooCommerce
 * asks for the billing email, and its own woocommerce_thankyou hook shows the panel once that's done).
 */
function gwnet_can_see_thankyou( $order ) {
	if ( $order->get_customer_id() ) {
		return get_current_user_id() === (int) $order->get_customer_id();
	}
	$created = $order->get_date_created() ? $order->get_date_created()->getTimestamp() : 0;
	$grace   = (int) apply_filters( 'woocommerce_order_email_verification_grace_period', 10 * MINUTE_IN_SECONDS, $order );
	return $created && ( time() - $created ) <= $grace;
}
