<?php
/**
 * The Interac e-Transfer payment gateway.
 */
defined( 'ABSPATH' ) || exit;

class GWNET_Gateway extends WC_Payment_Gateway {

	public function __construct() {
		$this->id                 = GWNET_ID;
		$this->method_title       = __( 'Interac e-Transfer', 'gwn-email-money-transfer' );
		$this->method_description = __( 'Customers place the order, then send an Interac e-Transfer. Orders wait on hold (stock held) until you mark them paid from the order screen.', 'gwn-email-money-transfer' );
		$this->has_fields         = true; // renders the how-it-works box at checkout
		$this->supports           = array( 'products' );
		$this->order_button_text  = (string) gwnet_s( 'button_text' );

		$this->init_form_fields();
		$this->init_settings();
		$this->title       = $this->get_option( 'title' );
		$this->description = '';

		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
	}

	/** Interac logo next to the method name at checkout. */
	public function get_icon() {
		return apply_filters( 'woocommerce_gateway_icon', gwnet_logo_img( 28, 'etr-logo etr-logo--method' ), $this->id );
	}

	public function init_form_fields() {
		$d = gwnet_defaults();
		$this->form_fields = array(
			'sec_setup'       => array( 'title' => __( 'Receiving account', 'gwn-email-money-transfer' ), 'type' => 'title' ),
			'enabled'         => array( 'title' => __( 'Enable', 'gwn-email-money-transfer' ), 'type' => 'checkbox', 'label' => __( 'Accept Interac e-Transfer', 'gwn-email-money-transfer' ), 'default' => $d['enabled'] ),
			'recipient_email' => array( 'title' => __( 'Send-to email', 'gwn-email-money-transfer' ), 'type' => 'email', 'default' => '', 'placeholder' => 'payments@example.com', 'description' => __( 'The email registered for e-Transfer with your bank. Required: checkout hides this payment method until it\'s set.', 'gwn-email-money-transfer' ) ),
			'recipient_name'  => array( 'title' => __( 'Recipient name', 'gwn-email-money-transfer' ), 'type' => 'text', 'default' => $d['recipient_name'], 'description' => __( 'What customers should name you when adding you as a recipient.', 'gwn-email-money-transfer' ) ),
			'autodeposit'     => array( 'title' => __( 'Autodeposit', 'gwn-email-money-transfer' ), 'type' => 'checkbox', 'label' => __( 'Autodeposit is on (hide the security question and answer)', 'gwn-email-money-transfer' ), 'default' => $d['autodeposit'] ),

			'sec_answer'      => array( 'title' => __( 'Security question and answer', 'gwn-email-money-transfer' ), 'type' => 'title', 'description' => __( 'Ignored when Autodeposit is on.', 'gwn-email-money-transfer' ) ),
			'question'        => array( 'title' => __( 'Security question', 'gwn-email-money-transfer' ), 'type' => 'text', 'default' => $d['question'], 'custom_attributes' => array( 'maxlength' => 40 ), 'description' => __( 'Max 40 characters. Match it to the answer type below.', 'gwn-email-money-transfer' ) ),
			'answer_mode'     => array( 'title' => __( 'Security answer', 'gwn-email-money-transfer' ), 'type' => 'select', 'default' => $d['answer_mode'], 'options' => array( 'random' => __( 'A random code for every order (recommended)', 'gwn-email-money-transfer' ), 'order' => __( 'Prefix + order number', 'gwn-email-money-transfer' ), 'fixed' => __( 'Same answer for every order', 'gwn-email-money-transfer' ) ), 'description' => __( 'New orders only. Any single order\'s answer can be changed from its order screen. The order number is in the e-Transfer message, so an answer built from it is easy to guess for anyone who sees the Interac notification.', 'gwn-email-money-transfer' ) ),
			'answer_prefix'   => array( 'title' => __( 'Answer prefix', 'gwn-email-money-transfer' ), 'type' => 'text', 'default' => $d['answer_prefix'], 'custom_attributes' => array( 'maxlength' => 8 ), 'description' => __( 'Per-order answers: prefix + order number, e.g. ORDER1042. Use a few letters of the store name.', 'gwn-email-money-transfer' ) ),
			'answer_fixed'    => array( 'title' => __( 'Fixed answer', 'gwn-email-money-transfer' ), 'type' => 'text', 'default' => $d['answer_fixed'], 'custom_attributes' => array( 'maxlength' => 25 ), 'description' => __( 'Used with "Same answer for every order". 3–25 letters or numbers, no spaces.', 'gwn-email-money-transfer' ) ),

			'sec_timing'      => array( 'title' => __( 'Timing', 'gwn-email-money-transfer' ), 'type' => 'title' ),
			'reminder_hours'  => array( 'title' => __( 'Reminder after (hours)', 'gwn-email-money-transfer' ), 'type' => 'number', 'default' => $d['reminder_hours'], 'description' => __( '0 = no reminder email.', 'gwn-email-money-transfer' ) ),
			'cancel_hours'    => array( 'title' => __( 'Auto-cancel after (hours)', 'gwn-email-money-transfer' ), 'type' => 'number', 'default' => $d['cancel_hours'], 'description' => __( 'Unpaid orders are cancelled and restocked. If the customer tapped "I\'ve sent it", they get 3 more days first. 0 = never.', 'gwn-email-money-transfer' ) ),
			'sent_button'     => array( 'title' => __( '"I\'ve sent it" button', 'gwn-email-money-transfer' ), 'type' => 'checkbox', 'label' => __( 'Show an "I\'ve sent it" button on the pay panel', 'gwn-email-money-transfer' ), 'default' => $d['sent_button'], 'description' => __( 'Lets customers flag that they\'ve sent it (flagged orders aren\'t auto-cancelled). Needs the public REST API.', 'gwn-email-money-transfer' ) ),
			'notify_sent'     => array( 'title' => __( '"I\'ve sent it" alerts', 'gwn-email-money-transfer' ), 'type' => 'checkbox', 'label' => __( 'Email the store when a customer says they\'ve sent their e-Transfer', 'gwn-email-money-transfer' ), 'default' => $d['notify_sent'] ),

			'sec_words'       => array( 'title' => __( 'Wording', 'gwn-email-money-transfer' ), 'type' => 'title' ),
			'title'           => array( 'title' => __( 'Checkout title', 'gwn-email-money-transfer' ), 'type' => 'text', 'default' => $d['title'] ),
			'button_text'     => array( 'title' => __( 'Place order button', 'gwn-email-money-transfer' ), 'type' => 'text', 'default' => $d['button_text'] ),
			'confirm_time'    => array( 'title' => __( 'Confirmation time', 'gwn-email-money-transfer' ), 'type' => 'text', 'default' => $d['confirm_time'], 'description' => __( 'Shown to customers: "We confirm payments …", e.g. "within a few hours (9am–9pm ET)".', 'gwn-email-money-transfer' ) ),
			'help_url'        => array( 'title' => __( 'Help / contact link', 'gwn-email-money-transfer' ), 'type' => 'text', 'default' => '', 'placeholder' => home_url( '/contact/' ), 'description' => __( 'Optional. Linked from cancelled orders ("Already sent it? Contact us").', 'gwn-email-money-transfer' ) ),

			'sec_look'        => array( 'title' => __( 'Look', 'gwn-email-money-transfer' ), 'type' => 'title', 'description' => __( 'The pay panel uses your theme\'s fonts. If GWND Fulfillment is installed, its Look tab can set these colours for you.', 'gwn-email-money-transfer' ) ),
			'how_collapse'    => array( 'title' => __( '"How to send it" on phones', 'gwn-email-money-transfer' ), 'type' => 'checkbox', 'label' => __( 'Collapse the steps into a tap-to-open section on small screens', 'gwn-email-money-transfer' ), 'default' => $d['how_collapse'] ),
			'color_accent'    => array( 'title' => __( 'Accent colour', 'gwn-email-money-transfer' ), 'type' => 'color', 'default' => $d['color_accent'], 'description' => __( 'Panel header, step numbers, admin email heading.', 'gwn-email-money-transfer' ) ),
			'color_highlight' => array( 'title' => __( 'Highlight colour', 'gwn-email-money-transfer' ), 'type' => 'color', 'default' => $d['color_highlight'], 'description' => __( 'Amount and answer chips, "sent" confirmation.', 'gwn-email-money-transfer' ) ),
			'color_text'      => array( 'title' => __( 'Text / outline colour', 'gwn-email-money-transfer' ), 'type' => 'color', 'default' => $d['color_text'] ),
			'color_panel'     => array( 'title' => __( 'Panel background', 'gwn-email-money-transfer' ), 'type' => 'color', 'default' => $d['color_panel'] ),
			'radius'          => array( 'title' => __( 'Corner radius (px)', 'gwn-email-money-transfer' ), 'type' => 'number', 'default' => $d['radius'], 'custom_attributes' => array( 'min' => 0, 'max' => 40 ) ),
			'shadow'          => array( 'title' => __( 'Shadow', 'gwn-email-money-transfer' ), 'type' => 'select', 'default' => $d['shadow'], 'options' => array( 'none' => __( 'None', 'gwn-email-money-transfer' ), 'soft' => __( 'Soft', 'gwn-email-money-transfer' ), 'hard' => __( 'Hard offset (bold / sticker look)', 'gwn-email-money-transfer' ) ) ),
		);
		$this->form_fields = (array) apply_filters( 'gwnet_form_fields', $this->form_fields, $d );
	}

	/** Settings screen: warn when a filled-in answer setting is being ignored by the current mode. */
	public function admin_options() {
		gwnet_setup_check();
		$msgs = gwnet_answer_warnings( $this->get_option( 'answer_mode' ), $this->get_option( 'answer_fixed' ), $this->get_option( 'answer_prefix' ), $this->get_option( 'autodeposit' ) );
		echo '<div id="etr-answer-warn" class="notice notice-warning inline"' . ( $msgs ? '' : ' style="display:none"' ) . '><p>' . wp_kses_post( implode( '<br>', $msgs ) ) . '</p></div>';
		echo '<div class="etr-settings">';
		parent::admin_options();
		echo '</div>';
		?>
		<style>
		/* Each settings group (Receiving account, Security answer, Timing, Wording, Look) as a card. */
		.etr-settings{max-width:960px}
		.etr-settings h3.wc-settings-sub-title{margin:24px 0 0;padding:16px 20px 4px;background:#fff;border:1px solid #dcdcde;border-bottom:0;border-radius:4px 4px 0 0;font-size:14px}
		.etr-settings h3.wc-settings-sub-title + p{margin:0;padding:0 20px 6px;background:#fff;border-left:1px solid #dcdcde;border-right:1px solid #dcdcde;color:#646970}
		.etr-settings h3.wc-settings-sub-title ~ table.form-table{background:#fff;border:1px solid #dcdcde;border-top:0;border-radius:0 0 4px 4px;margin:0 0 8px}
		.etr-settings table.form-table th{padding-left:20px;width:220px}
		.etr-settings table.form-table td{padding-right:20px}
		.etr-settings > h2 + p, .etr-settings > p:first-of-type{max-width:760px}
		</style>
		<?php
		$ids = array(
			'mode'   => $this->get_field_key( 'answer_mode' ),
			'fixed'  => $this->get_field_key( 'answer_fixed' ),
			'prefix' => $this->get_field_key( 'answer_prefix' ),
			'auto'   => $this->get_field_key( 'autodeposit' ),
		);
		?>
		<script>
		( function () {
			var ids = <?php echo wp_json_encode( $ids ); ?>, $ = function ( k ) { return document.getElementById( ids[ k ] ); };
			var box = document.getElementById( 'etr-answer-warn' ), mode = $( 'mode' ), fixed = $( 'fixed' ), prefix = $( 'prefix' ), auto = $( 'auto' );
			if ( ! box || ! mode || ! fixed ) { return; }
			var td = fixed.closest( 'td' );
			if ( td ) { td.appendChild( box ); box.style.margin = '10px 0 0'; }
			function esc( t ) { var d = document.createElement( 'div' ); d.textContent = t; return d.innerHTML; }
			function row( el ) { return el ? el.closest( 'tr' ) : null; }
			var question = document.getElementById( ids.mode.replace( 'answer_mode', 'question' ) );
			function check() {
				// Only show the answer settings that apply: prefix for per-order answers, fixed answer for
				// "same answer", and none of them with Autodeposit.
				var a = auto && auto.checked;
				[ row( mode ), row( question ) ].forEach( function ( r ) { if ( r ) { r.style.display = a ? 'none' : ''; } } );
				if ( row( prefix ) ) { row( prefix ).style.display = ( a || 'order' !== mode.value ) ? 'none' : ''; }
				if ( row( fixed ) ) { row( fixed ).style.display = ( a || 'fixed' !== mode.value ) ? 'none' : ''; }
				box.style.display = 'none';
			}
			[ mode, fixed, prefix, auto ].forEach( function ( el ) { if ( el ) { el.addEventListener( 'input', check ); el.addEventListener( 'change', check ); } } );
			if ( window.jQuery ) { jQuery( mode ).on( 'change', check ); } // selectWoo
			check();
		} )();
		</script>
		<?php
	}

	public function validate_answer_fixed_field( $key, $value ) {
		$value = trim( (string) $value );
		if ( '' === $value ) { return ''; }
		$clean = gwnet_clean_answer( $value );
		if ( is_wp_error( $clean ) ) {
			/* translators: %s: error */ WC_Admin_Settings::add_error( sprintf( __( 'Fixed answer: %s', 'gwn-email-money-transfer' ), $clean->get_error_message() ) );
			return $this->get_option( 'answer_fixed' );
		}
		return $clean;
	}

	public function validate_answer_mode_field( $key, $value ) {
		$value = in_array( $value, array( 'random', 'order', 'fixed' ), true ) ? $value : 'random';
		$field = $this->get_field_key( 'answer_fixed' );
		$fixed = isset( $_POST[ $field ] ) ? sanitize_text_field( wp_unslash( $_POST[ $field ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce verified the settings form nonce
		if ( 'fixed' === $value && is_wp_error( gwnet_clean_answer( $fixed ) ) ) {
			WC_Admin_Settings::add_error( __( 'Add a valid fixed answer before switching to "Same answer for every order". Per-order answers are kept for now.', 'gwn-email-money-transfer' ) );
			return 'order';
		}
		return $value;
	}

	public function validate_question_field( $key, $value ) {
		return mb_substr( sanitize_text_field( (string) $value ), 0, 40 );
	}

	public function is_available() {
		if ( ! parent::is_available() ) { return false; }
		return (bool) gwnet_email() || in_array( wp_get_environment_type(), array( 'local', 'development' ), true );
	}

	public function payment_fields() {
		gwnet_checkout_box();
	}

	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );
		$order->update_meta_data( '_etr_answer', gwnet_default_answer( $order ) );
		$order->update_meta_data( '_etr_due', gwnet_due_from( time() ) );
		$order->save();

		/* translators: 1: amount, 2: security answer */
		$note = 'yes' === gwnet_s( 'autodeposit' ) ? sprintf( __( 'Waiting for an Interac e-Transfer of %s.', 'gwn-email-money-transfer' ), gwnet_money( $order->get_total() ) ) : sprintf( __( 'Waiting for an Interac e-Transfer of %1$s. Security answer: %2$s.', 'gwn-email-money-transfer' ), gwnet_money( $order->get_total() ), gwnet_answer( $order ) );
		$order->update_status( 'on-hold', $note );
		wc_maybe_reduce_stock_levels( $order_id );
		gwnet_schedule( $order );

		if ( WC()->cart ) { WC()->cart->empty_cart(); }
		return array( 'result' => 'success', 'redirect' => $this->get_return_url( $order ) );
	}
}

add_filter( 'woocommerce_payment_gateways', function ( $g ) {
	$g[] = 'GWNET_Gateway';
	return $g;
} );

/**
 * Answer settings that are filled in but ignored by the current mode (saved values).
 *
 * @return string[] HTML messages
 */
function gwnet_answer_warnings( $mode = null, $fixed = null, $prefix = null, $autodeposit = null ) {
	// The settings screen now only shows the answer fields that apply, so a leftover value in a hidden
	// field is harmless and isn't worth a warning. Kept for anything that still calls it.
	return (array) apply_filters( 'gwnet_answer_warnings', array(), $mode, $fixed, $prefix, $autodeposit );
}

/* e-Transfers screen: same warning, with a link to fix it. */
add_action( 'admin_notices', function () {
	if ( ! isset( $_GET['page'] ) || GWNET_PAGE !== $_GET['page'] || ! current_user_can( 'manage_woocommerce' ) ) { return; } // phpcs:ignore
	$msgs = gwnet_answer_warnings();
	if ( ! $msgs ) { return; }
	echo '<div class="notice notice-warning"><p><strong>Interac e-Transfer:</strong> ' . wp_kses_post( implode( '<br>', $msgs ) ) . ' <a href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout&section=' . GWNET_ID ) ) . '">Open settings</a></p></div>';
} );

/** Setup check shown at the top of the settings: a short checklist until the store can take payments. */
function gwnet_setup_check() {
	$tested = (bool) wc_get_orders( array( 'limit' => 1, 'return' => 'ids', 'payment_method' => GWNET_ID ) );
	$checks = array(
		array( (bool) gwnet_email(), __( 'Add your send-to email', 'gwn-email-money-transfer' ), __( 'The email your bank uses for e-Transfers. Until it\'s set, checkout hides this payment method.', 'gwn-email-money-transfer' ) ),
		array( '' !== trim( (string) gwnet_s( 'recipient_name' ) ), __( 'Add the recipient name', 'gwn-email-money-transfer' ), __( 'The name customers add you under in their banking app.', 'gwn-email-money-transfer' ) ),
		array( 'yes' === gwnet_s( 'autodeposit' ) || 'random' === gwnet_s( 'answer_mode' ) || ! is_wp_error( 'fixed' === gwnet_s( 'answer_mode' ) ? gwnet_clean_answer( gwnet_s( 'answer_fixed' ) ) : gwnet_clean_answer( gwnet_s( 'answer_prefix' ) . '1000' ) ), __( 'Set up the security answer', 'gwn-email-money-transfer' ), __( 'Answers must be 3–25 letters or numbers. Turn on Autodeposit if your bank account has it.', 'gwn-email-money-transfer' ) ),
		array( $tested, __( 'Place a test order', 'gwn-email-money-transfer' ), __( 'Check out with e-Transfer to see the pay panel and email your customers get.', 'gwn-email-money-transfer' ) ),
	);
	$done  = count( array_filter( wp_list_pluck( $checks, 0 ) ) );
	$ready = $checks[0][0] && $checks[1][0] && $checks[2][0];
	echo '<div class="etr-setup' . ( $ready ? ' is-ready' : '' ) . '"><div class="etr-setup__head"><strong>' . esc_html( $ready ? __( 'Ready to take e-Transfers', 'gwn-email-money-transfer' ) : __( 'Get set up', 'gwn-email-money-transfer' ) ) . '</strong>';
	/* translators: 1: steps done, 2: all steps */
	echo '<span>' . esc_html( sprintf( __( '%1$d of %2$d done', 'gwn-email-money-transfer' ), $done, count( $checks ) ) ) . '</span></div><ol>';
	foreach ( $checks as $c ) {
		echo '<li class="' . ( $c[0] ? 'is-done' : '' ) . '"><i aria-hidden="true"></i><div><b>' . esc_html( $c[1] ) . '</b>' . ( $c[0] ? ' <span class="screen-reader-text">' . esc_html__( '(done)', 'gwn-email-money-transfer' ) . '</span>' : '' ) . '<p>' . esc_html( $c[2] ) . '</p></div></li>';
	}
	echo '</ol></div>';
	?>
	<style>
	.etr-setup{max-width:960px;box-sizing:border-box;background:#fff;border:1px solid #dcdcde;border-left:4px solid #dba617;border-radius:4px;padding:14px 20px;margin:16px 0}
	.etr-setup.is-ready{border-left-color:#00a32a}
	.etr-setup__head{display:flex;gap:12px;align-items:baseline}.etr-setup__head strong{font-size:14px}.etr-setup__head span{color:#50575e}
	.etr-setup ol{list-style:none;margin:10px 0 0;padding:0;display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:4px 24px}
	.etr-setup li{display:flex;gap:10px;margin:0;padding:6px 0}
	.etr-setup li p{margin:2px 0 0;color:#646970;font-size:12.5px}
	.etr-setup li i{flex:0 0 18px;height:18px;margin-top:1px;border:2px solid #c3c4c7;border-radius:50%;box-sizing:border-box;position:relative}
	.etr-setup li.is-done i{background:#00a32a;border-color:#00a32a}
	.etr-setup li.is-done i::after{content:"";position:absolute;left:4px;top:1px;width:4px;height:8px;border:solid #fff;border-width:0 2px 2px 0;transform:rotate(45deg)}
	.etr-setup li.is-done b{color:#50575e;font-weight:400;text-decoration:line-through}
	</style>
	<?php
}

/* Admin warning until the send-to email is set. */
add_action( 'admin_notices', function () {
	if ( gwnet_email() || ! current_user_can( 'manage_woocommerce' ) || 'yes' !== gwnet_s( 'enabled' ) ) { return; }
	// Only where it's useful (Dashboard, Plugins, WooCommerce → Settings → Payments), not on every screen,
	// and not on this method's own settings, which show the setup check instead.
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	$id     = $screen ? $screen->id : '';
	$here   = in_array( $id, array( 'dashboard', 'plugins' ), true ) || ( 'woocommerce_page_wc-settings' === $id && 'checkout' === sanitize_key( wp_unslash( $_GET['tab'] ?? '' ) ) && empty( $_GET['section'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
	if ( ! $here ) { return; }
	/* translators: %s: link to the payment settings */
	echo '<div class="notice notice-warning"><p>' . sprintf( esc_html__( 'Interac e-Transfer: no send-to email set yet. %s. Checkout hides e-Transfer until it\'s set.', 'gwn-email-money-transfer' ), '<a href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout&section=' . GWNET_ID ) ) . '">' . esc_html__( 'Add it in the payment settings', 'gwn-email-money-transfer' ) . '</a>' ) . '</p></div>';
} );
