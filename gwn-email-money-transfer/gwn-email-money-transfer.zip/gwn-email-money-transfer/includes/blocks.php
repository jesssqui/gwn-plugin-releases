<?php
/**
 * Cart & Checkout blocks support (for stores using the block checkout instead of [woocommerce_checkout]).
 */
defined( 'ABSPATH' ) || exit;

add_action( 'woocommerce_blocks_payment_method_type_registration', function ( $registry ) {
	if ( ! class_exists( '\Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) { return; }

	if ( ! class_exists( 'GWNET_Blocks' ) ) {
		class GWNET_Blocks extends \Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType {
			protected $name = GWNET_ID;

			public function initialize() {
				$this->settings = get_option( 'woocommerce_' . GWNET_ID . '_settings', array() );
			}

			public function is_active() {
				$gws = WC()->payment_gateways() ? WC()->payment_gateways()->payment_gateways() : array();
				return isset( $gws[ GWNET_ID ] ) && $gws[ GWNET_ID ]->is_available();
			}

			public function get_payment_method_script_handles() {
				if ( ! wp_script_is( 'etr-blocks', 'registered' ) ) {
					wp_register_script( 'etr-blocks', GWNET_URL . 'assets/etr-blocks.js', array( 'wc-blocks-registry', 'wp-element' ), GWNET_VERSION, true );
				}
				return array( 'etr-blocks' );
			}

			public function get_payment_method_data() {
				return array(
					'name'        => GWNET_ID,
					'title'       => (string) gwnet_s( 'title' ),
					'logo'        => gwnet_logo_uri(),
					'boxHtml'     => gwnet_checkout_box_html(),
					'buttonLabel' => (string) gwnet_s( 'button_text' ),
					'supports'    => array( 'products' ),
				);
			}
		}
	}
	$registry->register( new GWNET_Blocks() );
} );
