<?php
/**
 * WooCommerce → e-Transfers: every order waiting on an e-Transfer in one place, with search,
 * stat cards and Mark paid / reminder / answer / cancel for each.
 */
defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', function () {
	$n = 0;
	if ( current_user_can( 'edit_shop_orders' ) ) {
		$n = get_transient( 'gwnet_count' );
		if ( false === $n ) {
			$n = count( wc_get_orders( array( 'payment_method' => GWNET_ID, 'status' => array( 'wc-on-hold' ), 'limit' => -1, 'return' => 'ids' ) ) );
			set_transient( 'gwnet_count', $n, 5 * MINUTE_IN_SECONDS );
		}
	}
	$bubble = $n ? ' <span class="awaiting-mod count-' . (int) $n . '"><span class="pending-count">' . (int) $n . '</span></span>' : '';
	add_submenu_page( 'woocommerce', __( 'Interac e-Transfers', 'gwn-email-money-transfer' ), __( 'e-Transfers', 'gwn-email-money-transfer' ) . $bubble, 'edit_shop_orders', GWNET_PAGE, 'gwnet_admin_page', 2 );
}, 60 );

function gwnet_customer_cell( $o ) {
	$name = trim( $o->get_formatted_billing_full_name() ) ?: '(no name)';
	return '<b>' . esc_html( $name ) . '</b><span>' . esc_html( $o->get_billing_email() ) . '</span>';
}

function gwnet_admin_page() {
	$tab  = sanitize_key( wp_unslash( $_GET['tab'] ?? 'awaiting' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- which tab to show
	$now  = time();
	$wait = gwnet_awaiting_orders();
	$sum  = 0; $sent = 0; $soon = 0; $late = 0;
	foreach ( $wait as $o ) {
		$sum += (float) $o->get_total();
		if ( $o->get_meta( '_etr_sent' ) ) { $sent++; }
		$left = gwnet_due( $o ) - $now;
		if ( $left <= 0 ) { $late++; } elseif ( $left < 12 * HOUR_IN_SECONDS ) { $soon++; }
	}
	$paid30   = wc_get_orders( array( 'payment_method' => GWNET_ID, 'status' => array( 'wc-processing', 'wc-completed' ), 'date_paid' => '>' . ( $now - 30 * DAY_IN_SECONDS ), 'limit' => -1 ) );
	$paid_sum = array_sum( array_map( function ( $o ) { $a = $o->get_meta( '_etr_paid_amount' ); return (float) ( '' !== $a && null !== $a ? $a : $o->get_total() ); }, $paid30 ) );
	$base     = admin_url( 'admin.php?page=' . GWNET_PAGE );
	$tabs     = array( /* translators: %d: number of orders */ 'awaiting' => sprintf( __( 'Awaiting payment (%d)', 'gwn-email-money-transfer' ), count( $wait ) ), 'paid' => __( 'Paid', 'gwn-email-money-transfer' ), 'cancelled' => __( 'Cancelled', 'gwn-email-money-transfer' ) );
	$settings = admin_url( 'admin.php?page=wc-settings&tab=checkout&section=' . GWNET_ID );
	?>
	<div class="wrap etra">
		<div class="etra__top">
			<div>
				<h1><?php esc_html_e( 'Interac e-Transfers', 'gwn-email-money-transfer' ); ?></h1>
				<p class="etra__sub"><?php esc_html_e( 'Got a deposit notice from the bank? Type the amount, name or answer in the search to find the order, then click Mark paid. Paid orders move to Processing and the customer gets their "order received" email.', 'gwn-email-money-transfer' ); ?></p>
			</div>
			<a class="button" href="<?php echo esc_url( $settings ); ?>"><?php esc_html_e( 'Settings', 'gwn-email-money-transfer' ); ?></a>
		</div>
		<?php gwnet_admin_notice_from_query(); ?>
		<?php if ( ! gwnet_email() ) : ?>
			<div class="notice notice-warning inline"><p><b><?php esc_html_e( 'No send-to email set.', 'gwn-email-money-transfer' ); ?></b> <?php esc_html_e( 'Checkout hides e-Transfer until it\'s set.', 'gwn-email-money-transfer' ); ?> <a href="<?php echo esc_url( $settings ); ?>"><?php esc_html_e( 'Set it in settings', 'gwn-email-money-transfer' ); ?></a></p></div>
		<?php endif; ?>

		<div class="etra__stats">
			<div class="etra__stat is-violet"><span><?php esc_html_e( 'Awaiting', 'gwn-email-money-transfer' ); ?></span><b><?php echo (int) count( $wait ); ?></b><small><?php /* translators: %s: amount */ echo wp_kses_post( sprintf( __( '%s outstanding', 'gwn-email-money-transfer' ), wc_price( $sum ) ) ); ?></small></div>
			<div class="etra__stat is-lime"><span><?php esc_html_e( 'Customer says sent', 'gwn-email-money-transfer' ); ?></span><b><?php echo (int) $sent; ?></b><small><?php esc_html_e( 'check your bank for these first', 'gwn-email-money-transfer' ); ?></small></div>
			<div class="etra__stat<?php echo $late ? ' is-pink' : ' is-orange'; ?>"><span><?php echo esc_html( $late ? __( 'Overdue', 'gwn-email-money-transfer' ) : __( 'Due within 12 hours', 'gwn-email-money-transfer' ) ); ?></span><b><?php echo (int) ( $late ?: $soon ); ?></b><small><?php echo esc_html( $late ? __( 'past the deadline, customer says sent', 'gwn-email-money-transfer' ) : __( 'cancelled soon if unpaid', 'gwn-email-money-transfer' ) ); ?></small></div>
			<div class="etra__stat"><span><?php esc_html_e( 'Received · 30 days', 'gwn-email-money-transfer' ); ?></span><b><?php echo wp_kses_post( wc_price( $paid_sum ) ); ?></b><small><?php /* translators: %d: number of orders */ echo esc_html( sprintf( _n( '%d order', '%d orders', count( $paid30 ), 'gwn-email-money-transfer' ), count( $paid30 ) ) ); ?></small></div>
		</div>

		<nav class="etra__tabs">
			<?php foreach ( $tabs as $k => $label ) : ?>
				<a href="<?php echo esc_url( add_query_arg( 'tab', $k, $base ) ); ?>" class="<?php echo $tab === $k ? 'is-on' : ''; ?>"><?php echo esc_html( $label ); ?></a>
			<?php endforeach; ?>
			<input type="search" class="etra__search" placeholder="Search amount, name, email, answer…" data-etra-search>
		</nav>

		<?php
		if ( 'awaiting' === $tab ) {
			gwnet_admin_table_awaiting( $wait );
		} else {
			$st   = 'paid' === $tab ? array( 'wc-processing', 'wc-completed', 'wc-refunded' ) : array( 'wc-cancelled' );
			$list = wc_get_orders( array( 'payment_method' => GWNET_ID, 'status' => $st, 'limit' => 60, 'orderby' => 'date', 'order' => 'DESC' ) );
			gwnet_admin_table_history( $list, $tab );
		}
		?>
	</div>
	<?php gwnet_admin_css(); ?>
	<script>
	(function(){
		var q=document.querySelector('[data-etra-search]');
		if(q){q.addEventListener('input',function(){
			var v=q.value.toLowerCase().replace(/[$,\s]/g,''), shown=0;
			document.querySelectorAll('.etra__row').forEach(function(r){
				var ok=!v||r.getAttribute('data-s').indexOf(v)>-1; r.style.display=ok?'':'none'; if(ok) shown++;
			});
			var e=document.querySelector('.etra__nomatch'); if(e) e.style.display=shown?'none':'';
		});}
		document.querySelectorAll('[data-etra-confirm]').forEach(function(f){
			f.addEventListener('submit',function(ev){ if(!window.confirm(f.getAttribute('data-etra-confirm'))) ev.preventDefault(); });
		});
		document.querySelectorAll('.etra__copy').forEach(function(b){
			b.addEventListener('click',function(){ if(navigator.clipboard) navigator.clipboard.writeText(b.getAttribute('data-copy')); b.classList.add('is-done'); setTimeout(function(){b.classList.remove('is-done');},1200); });
		});
	})();
	</script>
	<?php
}

function gwnet_search_blob( $o ) {
	$s = array( '#' . $o->get_order_number(), number_format( (float) $o->get_total(), 2, '.', '' ), $o->get_formatted_billing_full_name(), $o->get_billing_email(), gwnet_answer( $o ), $o->get_meta( '_etr_ref' ) );
	return strtolower( str_replace( array( ' ', ',', '$' ), '', implode( '|', $s ) ) );
}

function gwnet_action_form( $o, $do, $label, $class = 'button', $confirm = '' ) {
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"' . ( $confirm ? ' data-etra-confirm="' . esc_attr( $confirm ) . '"' : '' ) . '>';
	wp_nonce_field( 'gwnet_' . $o->get_id() );
	echo '<input type="hidden" name="action" value="gwnet"><input type="hidden" name="do" value="' . esc_attr( $do ) . '"><input type="hidden" name="order" value="' . (int) $o->get_id() . '">';
	echo '<button class="' . esc_attr( $class ) . '">' . esc_html( $label ) . '</button></form>';
}

function gwnet_answer_form( $o ) {
	?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="etra__ansform">
		<?php wp_nonce_field( 'gwnet_' . $o->get_id() ); ?>
		<input type="hidden" name="action" value="gwnet"><input type="hidden" name="do" value="answer"><input type="hidden" name="order" value="<?php echo (int) $o->get_id(); ?>">
		<input type="text" name="answer" value="<?php echo esc_attr( gwnet_answer( $o ) ); ?>" minlength="3" maxlength="25" pattern="[A-Za-z0-9]{3,25}" title="3–25 letters or numbers, no spaces" required>
		<label><input type="checkbox" name="notify" value="1" checked> email customer</label>
		<button class="button"><?php esc_html_e( 'Save', 'gwn-email-money-transfer' ); ?></button>
	</form>
	<?php
}

function gwnet_paid_form( $o ) {
	?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="etra__pay">
		<?php wp_nonce_field( 'gwnet_' . $o->get_id() ); ?>
		<input type="hidden" name="action" value="gwnet"><input type="hidden" name="do" value="paid"><input type="hidden" name="order" value="<?php echo (int) $o->get_id(); ?>">
		<label><span><?php esc_html_e( 'Received', 'gwn-email-money-transfer' ); ?></span><input type="number" step="0.01" min="0" name="amount" value="<?php echo esc_attr( number_format( (float) $o->get_total(), 2, '.', '' ) ); ?>"></label>
		<label><span><?php esc_html_e( 'Bank ref', 'gwn-email-money-transfer' ); ?></span><input type="text" name="ref" placeholder="<?php esc_attr_e( 'optional', 'gwn-email-money-transfer' ); ?>"></label>
		<label class="etra__force"><input type="checkbox" name="force" value="1"> <?php esc_html_e( 'Mark paid even if short', 'gwn-email-money-transfer' ); ?></label>
		<button class="button button-primary"><?php esc_html_e( 'Mark paid', 'gwn-email-money-transfer' ); ?></button>
	</form>
	<?php
}

function gwnet_admin_table_awaiting( $orders ) {
	if ( ! $orders ) {
		echo '<div class="etra__empty"><b>' . esc_html__( 'All caught up.', 'gwn-email-money-transfer' ) . '</b><span>' . esc_html__( 'No orders waiting on an e-Transfer.', 'gwn-email-money-transfer' ) . '</span></div>';
		return;
	}
	$now = time();
	echo '<div class="etra__list">';
	foreach ( $orders as $o ) {
		$d    = gwnet_details( $o );
		$left = $d['due'] - $now;
		$cls  = (int) gwnet_s( 'cancel_hours' ) > 0 ? ( $left <= 0 ? 'is-late' : ( $left < 12 * HOUR_IN_SECONDS ? 'is-soon' : '' ) ) : '';
		$c    = $o->get_date_created();
		?>
		<div class="etra__row <?php echo esc_attr( $cls . ( $d['sent'] ? ' is-sent' : '' ) ); ?>" data-s="<?php echo esc_attr( gwnet_search_blob( $o ) ); ?>">
			<div class="etra__cell etra__order">
				<a href="<?php echo esc_url( $o->get_edit_order_url() ); ?>">#<?php echo esc_html( $o->get_order_number() ); ?></a>
				<span><?php echo esc_html( $c ? human_time_diff( $c->getTimestamp(), $now ) . ' ago' : '' ); ?></span>
			</div>
			<div class="etra__cell etra__cust"><?php echo gwnet_customer_cell( $o ); // phpcs:ignore ?></div>
			<div class="etra__cell etra__amt">
				<button type="button" class="etra__copy" data-copy="<?php echo esc_attr( $d['amount_txt'] ); ?>" title="Copy amount"><?php echo wp_kses_post( $d['amount_html'] ); ?></button>
				<?php if ( ! $d['autodeposit'] ) : ?>
					<details class="etra__ans">
						<summary title="Security answer — click to edit"><code><?php echo esc_html( $d['answer'] ); ?></code> <span>edit</span></summary>
						<?php gwnet_answer_form( $o ); ?>
					</details>
				<?php endif; ?>
			</div>
			<div class="etra__cell etra__state">
				<?php if ( $d['sent'] ) : ?><span class="etra__chip is-lime"><?php /* translators: %s: time since */ echo esc_html( sprintf( __( 'Customer sent it · %s ago', 'gwn-email-money-transfer' ), human_time_diff( $d['sent'], $now ) ) ); ?></span><?php endif; ?>
				<?php if ( $o->get_meta( '_etr_reminded' ) ) : ?><span class="etra__chip"><?php esc_html_e( 'Reminder sent', 'gwn-email-money-transfer' ); ?></span><?php endif; ?>
				<?php if ( (int) gwnet_s( 'cancel_hours' ) > 0 ) : ?>
					<span class="etra__due"><?php echo esc_html( $left <= 0 ? __( 'Past due', 'gwn-email-money-transfer' ) : gwnet_left( $d['due'] ) ); ?></span>
				<?php endif; ?>
			</div>
			<div class="etra__cell etra__actions">
				<?php gwnet_paid_form( $o ); ?>
				<div class="etra__minor">
					<?php
					gwnet_action_form( $o, 'remind', __( 'Send reminder', 'gwn-email-money-transfer' ), 'button-link' );
					/* translators: %s: order number */ gwnet_action_form( $o, 'cancel', __( 'Cancel & restock', 'gwn-email-money-transfer' ), 'button-link etra__danger', sprintf( __( 'Cancel order #%s and put the stock back?', 'gwn-email-money-transfer' ), $o->get_order_number() ) );
					?>
				</div>
			</div>
		</div>
		<?php
	}
	echo '<div class="etra__empty etra__nomatch" style="display:none"><b>' . esc_html__( 'No match.', 'gwn-email-money-transfer' ) . '</b><span>' . esc_html__( 'Try the amount without the $ sign (e.g. 53.97) or the customer\'s last name.', 'gwn-email-money-transfer' ) . '</span></div>';
	echo '</div>';
}

function gwnet_admin_table_history( $orders, $tab ) {
	if ( ! $orders ) {
		echo '<div class="etra__empty"><b>' . esc_html__( 'Nothing here yet.', 'gwn-email-money-transfer' ) . '</b></div>';
		return;
	}
	echo '<div class="etra__list">';
	foreach ( $orders as $o ) {
		$paid = (int) $o->get_meta( '_etr_paid_at' );
		$amt  = $o->get_meta( '_etr_paid_amount' );
		?>
		<div class="etra__row is-history" data-s="<?php echo esc_attr( gwnet_search_blob( $o ) ); ?>">
			<div class="etra__cell etra__order"><a href="<?php echo esc_url( $o->get_edit_order_url() ); ?>">#<?php echo esc_html( $o->get_order_number() ); ?></a><span><?php echo esc_html( wc_get_order_status_name( $o->get_status() ) ); ?></span></div>
			<div class="etra__cell etra__cust"><?php echo gwnet_customer_cell( $o ); // phpcs:ignore ?></div>
			<div class="etra__cell etra__amt"><b><?php echo wp_kses_post( wc_price( $o->get_total() ) ); ?></b><?php if ( '' !== $amt && null !== $amt && abs( (float) $amt - (float) $o->get_total() ) >= 0.01 ) : ?><span class="etra__chip is-pink">received <?php echo wp_kses_post( wc_price( $amt ) ); ?></span><?php endif; ?></div>
			<div class="etra__cell etra__state">
				<?php if ( 'paid' === $tab ) : ?>
					<span><?php /* translators: %s: date */ echo esc_html( $paid ? sprintf( __( 'Paid %s', 'gwn-email-money-transfer' ), wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $paid ) ) : __( 'Paid', 'gwn-email-money-transfer' ) ); ?></span>
					<span class="etra__muted"><?php echo esc_html( trim( ( $o->get_meta( '_etr_paid_by' ) ? 'by ' . $o->get_meta( '_etr_paid_by' ) : '' ) . ( $o->get_meta( '_etr_ref' ) ? ' · ref ' . $o->get_meta( '_etr_ref' ) : '' ) ) ); ?></span>
				<?php else : ?>
					<span><?php echo esc_html( $o->get_meta( '_etr_expired' ) ? __( 'Auto-cancelled (no payment)', 'gwn-email-money-transfer' ) : __( 'Cancelled', 'gwn-email-money-transfer' ) ); ?></span>
				<?php endif; ?>
			</div>
			<div class="etra__cell etra__actions"><a class="button" href="<?php echo esc_url( $o->get_edit_order_url() ); ?>"><?php esc_html_e( 'View order', 'gwn-email-money-transfer' ); ?></a></div>
		</div>
		<?php
	}
	echo '<div class="etra__empty etra__nomatch" style="display:none"><b>' . esc_html__( 'No match.', 'gwn-email-money-transfer' ) . '</b></div></div>';
}

