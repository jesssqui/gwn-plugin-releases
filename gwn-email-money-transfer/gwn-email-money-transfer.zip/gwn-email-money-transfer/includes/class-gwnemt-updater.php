<?php
/**
 * Updates GWN Email Money Transfer from the public GWN releases repository.
 *
 * Source lives in the private jesssqui/gwn-etransfer repo. Each release (built by
 * .github/workflows/release.yml or bin/publish.sh) is published to the
 * public jesssqui/gwn-plugin-releases repo: the zip as a release asset under
 * the tag gwn-email-money-transfer-v<version>, and gwn-email-money-transfer/info.json describing the latest
 * version. Stores read info.json and get the new version as a normal
 * WordPress update, so no store needs a token or any file edits.
 *
 * info.json is read from raw.githubusercontent.com, not GitHub's API (the API
 * allows anonymous callers 60 requests an hour per IP, easy to exhaust on
 * shared hosting).
 *
 * Every release zip is signed (Ed25519). info.json carries the signature and
 * the zip's SHA-256; before WordPress installs an update this class downloads
 * the zip itself and refuses it unless both match SIGNING_PUBLIC_KEY and the
 * zip holds the announced version. Downloads that aren't this plugin's
 * release assets on the releases repo are refused.
 *
 * WordPress auto-updates are switched on for this plugin once, the first time
 * an admin loads wp-admin, with a one-time notice and a link to switch them
 * off. That choice is never overridden.
 *
 * Only in the GitHub build: bin/build-zip.sh leaves this file and lib/ out of the
 * WordPress.org build (WPORG=1), where WordPress.org delivers updates itself.
 *
 * Checking and caching: bundled Plugin Update Checker (MIT,
 * https://github.com/YahnisElsts/plugin-update-checker).
 *
 * Switch updates off on one site: add_filter( 'gwnemt_update_metadata_url', '__return_empty_string' );
 */
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'GWNEMT_Updater' ) ) :

final class GWNEMT_Updater {

	const SLUG                 = 'gwn-email-money-transfer';
	const NAME                 = 'GWN Email Money Transfer';
	const METADATA_URL         = 'https://raw.githubusercontent.com/jesssqui/gwn-plugin-releases/HEAD/gwn-email-money-transfer/info.json';
	const DOWNLOAD_URL_PREFIX  = 'https://github.com/jesssqui/gwn-plugin-releases/releases/download/';
	const CHECK_PERIOD_HOURS   = 6;

	/** Base64 Ed25519 public key that GWN release zips are signed with (shared by all GWN plugins). */
	const SIGNING_PUBLIC_KEY   = 'crX+wFvfxAKMJ3R3XdWlbka8rHMDGHz+xT8Ij1gh8xM=';

	const SIGNATURES_OPTION    = 'gwnemt_update_signatures';
	const AUTO_UPDATE_FLAG     = 'gwnemt_auto_updates_defaulted';
	const NOTICE_OPTION        = 'gwnemt_auto_updates_notice';
	const NOTICE_DISMISSED     = 'gwnemt_auto_updates_notice_dismissed';

	/** @var string Main plugin file. */
	private static $file = '';

	/** Call from the main plugin file at load time (not on a later hook). */
	public static function init( $plugin_file ) {
		self::$file = $plugin_file;

		$url = (string) apply_filters( 'gwnemt_update_metadata_url', self::METADATA_URL );
		if ( '' === $url ) {
			return;
		}

		require_once dirname( __DIR__ ) . '/lib/plugin-update-checker/plugin-update-checker.php';

		$checker = \YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker( $url, $plugin_file, self::SLUG, self::CHECK_PERIOD_HOURS );
		$checker->addResultFilter( array( __CLASS__, 'filter_info_result' ) );

		add_filter( 'upgrader_pre_download', array( __CLASS__, 'verify_download' ), 10, 4 );
		add_action( 'admin_init', array( __CLASS__, 'maybe_enable_auto_updates' ) );
		add_action( 'admin_notices', array( __CLASS__, 'render_notice' ) );
		add_action( 'network_admin_notices', array( __CLASS__, 'render_notice' ) );
		add_action( 'admin_post_gwnemt_dismiss_update_notice', array( __CLASS__, 'dismiss_notice' ) );
	}

	/* ---------------------------------------------------------------- Signed updates */

	/** Drop updates whose download isn't ours or that carry no valid signature; remember the signature for verify_download(). */
	public static function filter_info_result( $info, $result = null ) {
		if ( ! is_object( $info ) ) {
			return $info;
		}
		$version = isset( $info->version ) ? (string) $info->version : '';
		$url     = isset( $info->download_url ) ? (string) $info->download_url : '';
		if ( ! self::is_trusted_download_url( $url ) ) {
			self::log( sprintf( 'ignoring update %s: download_url "%s" is not a release asset of %s', $version, $url, self::SLUG ) );
			return null;
		}
		$signature = isset( $info->signature ) ? trim( (string) $info->signature ) : '';
		$sha256    = isset( $info->sha256 ) ? strtolower( trim( (string) $info->sha256 ) ) : '';
		$sig_raw   = base64_decode( $signature, true );
		if ( false === $sig_raw || 64 !== strlen( $sig_raw ) || 1 !== preg_match( '/^[0-9a-f]{64}$/', $sha256 ) ) {
			self::log( sprintf( 'ignoring update %s: info.json has no valid signature/sha256', $version ) );
			return null;
		}
		$store = get_site_option( self::SIGNATURES_OPTION, array() );
		$store = is_array( $store ) ? $store : array();
		$store[ $version ] = array( 'download_url' => $url, 'signature' => $signature, 'sha256' => $sha256 );
		uksort( $store, 'version_compare' );
		update_site_option( self::SIGNATURES_OPTION, array_slice( $store, -5, null, true ) );
		return $info;
	}

	/** upgrader_pre_download: download our package here and hand it to WordPress only if it verifies. */
	public static function verify_download( $reply, $package, $upgrader = null, $hook_extra = array() ) {
		if ( false !== $reply ) {
			return $reply;
		}
		$package   = (string) $package;
		$is_url    = (bool) preg_match( '#^(https?|ftp)://#i', $package );
		$ours_hook = is_array( $hook_extra ) && isset( $hook_extra['plugin'] ) && plugin_basename( self::$file ) === $hook_extra['plugin'];
		$ours_url  = $is_url && self::is_trusted_download_url( $package );
		if ( ( ! $ours_hook && ! $ours_url ) || ! $is_url ) {
			return $reply; // Not this plugin, or a zip uploaded by hand.
		}
		if ( ! $ours_url ) {
			return new WP_Error( self::SLUG . '_untrusted_package', sprintf( '%s update refused: the download is not from the official releases page.', self::NAME ) );
		}
		$expected = self::signature_for_package( $package );
		if ( null === $expected ) {
			return new WP_Error( self::SLUG . '_unsigned_package', sprintf( '%s update refused: no signature is on record for this download. Check for updates again, then retry.', self::NAME ) );
		}
		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$file = download_url( $package, 300 );
		if ( is_wp_error( $file ) ) {
			return $file;
		}
		$check = self::verify_package( $file, $expected['sha256'], $expected['signature'], self::SIGNING_PUBLIC_KEY, $expected['version'] );
		if ( is_wp_error( $check ) ) {
			wp_delete_file( $file );
			self::log( 'refused ' . $package . ': ' . $check->get_error_message() );
			return $check;
		}
		return $file;
	}

	/** Check a zip against its SHA-256, Ed25519 signature and (when ZipArchive exists) the version inside. */
	public static function verify_package( $file, $sha256, $signature_b64, $public_key_b64, $expected_version = null ) {
		$fail = function ( $code, $msg ) {
			return new WP_Error( self::SLUG . '_' . $code, sprintf( '%s update refused: %s', self::NAME, $msg ) );
		};
		if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
			return $fail( 'no_sodium', 'this server\'s PHP cannot check signatures (libsodium is missing).' );
		}
		$public_key = base64_decode( (string) $public_key_b64, true );
		$signature  = base64_decode( (string) $signature_b64, true );
		if ( false === $public_key || SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES !== strlen( $public_key ) || false === $signature || SODIUM_CRYPTO_SIGN_BYTES !== strlen( $signature ) ) {
			return $fail( 'bad_signature', 'the signature or key is malformed.' );
		}
		$bytes = is_readable( $file ) ? file_get_contents( $file ) : false;
		if ( false === $bytes || '' === $bytes ) {
			return $fail( 'unreadable', 'the download could not be read.' );
		}
		if ( ! hash_equals( strtolower( (string) $sha256 ), hash( 'sha256', $bytes ) ) ) {
			return $fail( 'checksum', 'the download does not match its checksum.' );
		}
		try {
			$valid = sodium_crypto_sign_verify_detached( $signature, $bytes, $public_key );
		} catch ( \Throwable $e ) {
			$valid = false;
		}
		if ( ! $valid ) {
			return $fail( 'signature', 'the download\'s signature is not valid.' );
		}
		if ( $expected_version && class_exists( 'ZipArchive' ) ) {
			$zip = new ZipArchive();
			if ( true === $zip->open( $file ) ) {
				$main = $zip->getFromName( self::SLUG . '/' . self::SLUG . '.php' );
				$zip->close();
				if ( false === $main || ! preg_match( '/^\s*\*\s*Version:\s*(\S+)/mi', $main, $m ) || $m[1] !== $expected_version ) {
					return $fail( 'version', 'the download is not the version that was announced.' );
				}
			}
		}
		return true;
	}

	/** True when $url is one of this plugin's release assets: …/download/{slug}-v{ver}/{slug}-{ver}.zip */
	public static function is_trusted_download_url( $url ) {
		if ( ! is_string( $url ) || 0 !== strpos( $url, self::DOWNLOAD_URL_PREFIX ) ) {
			return false;
		}
		$rest = substr( $url, strlen( self::DOWNLOAD_URL_PREFIX ) );
		$q    = preg_quote( self::SLUG, '#' );
		return 1 === preg_match( '#^' . $q . '-v[0-9A-Za-z.\-]+/' . $q . '-[0-9A-Za-z.\-]+\.zip$#', $rest ) && false === strpos( $rest, '..' );
	}

	private static function signature_for_package( $package ) {
		$store = get_site_option( self::SIGNATURES_OPTION, array() );
		foreach ( is_array( $store ) ? $store : array() as $version => $e ) {
			if ( is_array( $e ) && isset( $e['download_url'], $e['signature'], $e['sha256'] ) && $e['download_url'] === $package ) {
				$e['version'] = (string) $version;
				return $e;
			}
		}
		return null;
	}

	private static function log( $message ) {
		error_log( '[' . self::NAME . ' updater] ' . $message ); // phpcs:ignore
	}

	/* ---------------------------------------------------------------- Auto-updates */

	/** Switch WordPress auto-updates on for this plugin once per site; an admin's later "off" is respected. */
	public static function maybe_enable_auto_updates() {
		if ( ! current_user_can( 'update_plugins' ) || get_site_option( self::AUTO_UPDATE_FLAG ) ) {
			return;
		}
		$basename = plugin_basename( self::$file );
		$enabled  = (array) get_site_option( 'auto_update_plugins', array() );
		$switched = false;
		if ( ! in_array( $basename, $enabled, true ) ) {
			$enabled[] = $basename;
			update_site_option( 'auto_update_plugins', array_values( array_unique( $enabled ) ) );
			$switched = true;
		}
		update_site_option( self::NOTICE_OPTION, $switched ? time() : 0 );
		update_site_option( self::AUTO_UPDATE_FLAG, current_time( 'mysql' ) );
	}

	public static function auto_updates_enabled() {
		if ( function_exists( 'wp_is_auto_update_enabled_for_type' ) && ! wp_is_auto_update_enabled_for_type( 'plugin' ) ) {
			return false;
		}
		return in_array( plugin_basename( self::$file ), (array) get_site_option( 'auto_update_plugins', array() ), true );
	}

	public static function render_notice() {
		if ( ! current_user_can( 'update_plugins' ) || ! get_site_option( self::NOTICE_OPTION ) ) {
			return;
		}
		// Only on the Plugins screen: never stacked on every admin page.
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || ! in_array( $screen->id, array( 'plugins', 'plugins-network' ), true ) ) {
			return;
		}
		if ( get_user_meta( get_current_user_id(), self::NOTICE_DISMISSED, true ) || ! self::auto_updates_enabled() ) {
			return;
		}
		$plugins = is_multisite() ? network_admin_url( 'plugins.php' ) : admin_url( 'plugins.php' );
		$off     = wp_nonce_url( add_query_arg( array( 'action' => 'disable-auto-update', 'plugin' => rawurlencode( plugin_basename( self::$file ) ) ), $plugins ), 'updates' );
		$dismiss = wp_nonce_url( add_query_arg( 'action', 'gwnemt_dismiss_update_notice', admin_url( 'admin-post.php' ) ), 'gwnemt_dismiss_update_notice' );
		printf(
			'<div class="notice notice-info"><p>%s <a href="%s">%s</a> &middot; <a href="%s">%s</a></p></div>',
			esc_html( sprintf( '%s will update itself automatically so you get fixes quickly.', self::NAME ) ),
			esc_url( $off ),
			esc_html( 'Turn off automatic updates' ),
			esc_url( $dismiss ),
			esc_html( 'Dismiss' )
		);
	}

	public static function dismiss_notice() {
		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_die( 'You do not have permission to do that.', 403 );
		}
		check_admin_referer( 'gwnemt_dismiss_update_notice' );
		update_user_meta( get_current_user_id(), self::NOTICE_DISMISSED, time() );
		wp_safe_redirect( wp_get_referer() ?: admin_url() );
		exit;
	}
}

endif;
