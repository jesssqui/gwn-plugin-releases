<?php
/**
 * Plugin Name:       GWN Email Money Transfer
 * Description:       Take Interac e-Transfer payments: customers get the amount, email, security question and answer with copy buttons; orders wait on hold (stock held) until you mark them paid, with reminders, auto-cancel, business-day deadlines and an e-Transfers inbox. Free, no add-ons.
 * Version:           1.2.1
 * Plugin URI:        https://greatwhitenorthdesign.ca/tools/email-money-transfer/
 * Author:            Great White North Design
 * Author URI:        https://greatwhitenorthdesign.ca
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Requires Plugins:  woocommerce
 * WC requires at least: 8.0
 * WC tested up to:   11.1
 * Text Domain:       gwn-email-money-transfer
 *
 * Interac e-Transfer is a registered trademark of Interac Corp. This plugin isn't made, affiliated with or endorsed by Interac Corp.
 * Formerly "GWN e-Transfer" (folder gwn-etransfer): same settings, orders and gateway id.
 * Nothing customer-facing names this plugin; classes use the neutral `etr-` prefix and the REST route is
 * /wp-json/etransfer/v1/…
 */
defined( 'ABSPATH' ) || exit;

/*
 * Renamed from GWN e-Transfer (gwn-etransfer). Both can't run at once (same functions), so if the old
 * one is still active: switch it off, skip loading this request, and say so. Settings and orders carry over.
 */
if ( defined( 'GWNET_FILE' ) || in_array( 'gwn-etransfer/gwn-etransfer.php', (array) get_option( 'active_plugins', array() ), true ) ) {
	add_action( 'admin_init', function () {
		if ( ! current_user_can( 'activate_plugins' ) || wp_doing_ajax() ) {
			return; // only an admin's own page load switches the old plugin off
		}
		if ( ! function_exists( 'deactivate_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		// Silent on purpose: the old plugin's deactivation hook would clear the reminders and auto-cancels
		// that this plugin carries on with (same Action Scheduler group).
		deactivate_plugins( array( 'gwn-etransfer/gwn-etransfer.php', 'gwn-etransfer-pro/gwn-etransfer-pro.php' ), true );
		set_transient( 'gwnet_renamed', 1, DAY_IN_SECONDS );
	} );
	return;
}

define( 'GWNET_VERSION', '1.2.1' );
define( 'GWNET_HOME', 'https://greatwhitenorthdesign.ca/tools/email-money-transfer/' ); // docs & support
define( 'GWNET_FILE', __FILE__ );
define( 'GWNET_DIR', plugin_dir_path( __FILE__ ) );
define( 'GWNET_ID', 'interac_etransfer' );   // gateway id (appears in checkout markup — keep neutral)
define( 'GWNET_GROUP', 'gwn-etransfer' );    // Action Scheduler group (admin only)
define( 'GWNET_PAGE', 'etransfers' );        // admin page slug

define( 'GWNET_URL', plugin_dir_url( __FILE__ ) );

/* HPOS + cart/checkout blocks compatibility. */

add_action( 'before_woocommerce_init', function () {
	if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', GWNET_FILE, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', GWNET_FILE, true );
	}
} );

add_action( 'plugins_loaded', function () {
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', function () {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'GWN Email Money Transfer needs WooCommerce to be installed and active.', 'gwn-email-money-transfer' ) . '</p></div>';
		} );
		return;
	}
	require_once GWNET_DIR . 'includes/core.php';
	require_once GWNET_DIR . 'includes/class-gateway.php';
	require_once GWNET_DIR . 'includes/frontend.php';
	require_once GWNET_DIR . 'includes/emails.php';
	require_once GWNET_DIR . 'includes/admin.php';
	require_once GWNET_DIR . 'includes/blocks.php';
	require_once GWNET_DIR . 'includes/inbox.php';  // WooCommerce → e-Transfers
	require_once GWNET_DIR . 'includes/timing.php'; // business-day deadlines
	// Add-ons hook in here. (Not "gwnet_loaded": the retired GWN e-Transfer Pro listened to that and its
	// features are now part of this plugin, so it must not load them a second time.)
	do_action( 'gwnet_init' );

}, 20 );

/* After (re)activation: put back the reminders and auto-cancels for orders still waiting on payment.
   On init, once WooCommerce's order storage is ready. */
add_action( 'init', function () {
	if ( ! get_option( 'gwnet_reschedule' ) || ! function_exists( 'as_schedule_single_action' ) || ! function_exists( 'gwnet_schedule' ) ) {
		return;
	}
	delete_option( 'gwnet_reschedule' );
	foreach ( wc_get_orders( array( 'status' => 'on-hold', 'payment_method' => GWNET_ID, 'limit' => 500, 'return' => 'objects' ) ) as $gwnet_o ) {
		if ( gwnet_awaiting( $gwnet_o ) ) {
			gwnet_schedule( $gwnet_o );
		}
	}
}, 20 );

/* Deactivated: stop the reminders and auto-cancels (they come back on activation). Order data is kept. */
register_deactivation_hook( __FILE__, function () {
	if ( function_exists( 'as_unschedule_all_actions' ) ) {
		as_unschedule_all_actions( '', array(), GWNET_GROUP );
	}
} );

/* After the rename: tell the store once that the old plugin was switched off. */
add_action( 'admin_notices', function () {
	if ( ! get_transient( 'gwnet_renamed' ) || ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	delete_transient( 'gwnet_renamed' );
	echo '<div class="notice notice-info is-dismissible"><p>' . esc_html__( 'GWN e-Transfer is now GWN Email Money Transfer. The old plugin has been switched off and your settings and orders carry over. You can delete "GWN e-Transfer" (and "GWN e-Transfer Pro") from the Plugins page.', 'gwn-email-money-transfer' ) . '</p></div>';
} );

/* GWN e-Transfer Pro is retired: everything it did is built in now. Switch it off and say so, once. */
add_action( 'admin_init', function () {
	if ( ! defined( 'GWNETP_FILE' ) || ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	deactivate_plugins( plugin_basename( GWNETP_FILE ), true );
	set_transient( 'gwnet_pro_retired', 1, DAY_IN_SECONDS );
} );
add_action( 'admin_notices', function () {
	if ( ! get_transient( 'gwnet_pro_retired' ) || ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	delete_transient( 'gwnet_pro_retired' );
	echo '<div class="notice notice-info is-dismissible"><p>' . esc_html__( 'The e-Transfers inbox and business-day deadlines are now part of GWN Email Money Transfer, so GWN e-Transfer Pro has been switched off. Your settings are kept. You can delete GWN e-Transfer Pro from the Plugins page.', 'gwn-email-money-transfer' ) . '</p></div>';
} );


/* On activation: let Stock Link (if installed) hold stock for the long offline window. */
register_activation_hook( __FILE__, function () {
	update_option( 'gwnet_reschedule', 1, false );
	$opt = get_option( 'sl_offline_gateways', null );
	if ( null !== $opt ) {
		$list = array_filter( array_map( 'trim', explode( ',', (string) $opt ) ) );
		if ( ! in_array( GWNET_ID, $list, true ) ) {
			$list[] = GWNET_ID;
			update_option( 'sl_offline_gateways', implode( ',', $list ) );
		}
	}
} );

/* Settings + panel links on the Plugins screen. */
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
	array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout&section=' . GWNET_ID ) ) . '">' . esc_html__( 'Settings', 'gwn-email-money-transfer' ) . '</a>', '<a href="' . esc_url( admin_url( 'admin.php?page=' . GWNET_PAGE ) ) . '">' . esc_html__( 'e-Transfers', 'gwn-email-money-transfer' ) . '</a>' );
	return $links;
} );

/* Admin-only credit and docs link (nothing customer-facing names the plugin or the studio). */
require_once GWNET_DIR . 'includes/brand.php';

/* Signed automatic updates from the GWN releases repo. Only in the GitHub build: the WordPress.org
   build leaves this file out and WordPress.org delivers its updates. */
if ( is_readable( GWNET_DIR . 'includes/class-gwnemt-updater.php' ) ) {
	require_once GWNET_DIR . 'includes/class-gwnemt-updater.php';
	GWNEMT_Updater::init( __FILE__ );
}
