/* Interac e-Transfer pay panel: copy buttons, countdown, "I've sent it" (with undo), collapsible steps. */
(function () {
	'use strict';
	var cfg = window.etrCfg || {};
	var t = function (k, d) { return cfg[k] || d; };

	function legacy(text) {
		var ta = document.createElement('textarea');
		ta.value = text; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.opacity = '0';
		document.body.appendChild(ta); ta.select();
		try { document.execCommand('copy'); } catch (e) {}
		document.body.removeChild(ta);
	}
	function copy(text, btn) {
		var done = function () {
			btn.classList.add('is-copied');
			btn.textContent = t('copied', 'Copied!');
			setTimeout(function () { btn.classList.remove('is-copied'); btn.textContent = t('copy', 'Copy'); }, 1400);
		};
		if (navigator.clipboard && window.isSecureContext) {
			navigator.clipboard.writeText(text).then(done, function () { legacy(text); done(); });
		} else { legacy(text); done(); }
	}

	document.addEventListener('click', function (e) {
		var b = e.target.closest('[data-etr-copy]');
		if (b) { e.preventDefault(); copy(b.getAttribute('data-etr-copy'), b); }
	});

	function left(due) {
		var s = due - Math.floor(Date.now() / 1000);
		if (s <= 0) return t('pastDue', 'Past due');
		var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60);
		return h >= 1 ? h + 'h ' + (m < 10 ? '0' : '') + m + 'm' : Math.max(1, m) + 'm';
	}

	function post(url, panel) {
		return fetch(url, {
			method: 'POST',
			credentials: 'omit',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ order: panel.getAttribute('data-order'), key: panel.getAttribute('data-key') })
		}).then(function (r) { return r.json(); }).then(function (j) {
			if (!j || !j.ok) throw new Error('fail');
			return j;
		});
	}

	document.querySelectorAll('[data-etr]').forEach(function (panel) {
		// Steps collapse on phones when the store asks for it.
		var how = panel.querySelector('details.etr__how');
		if (how && panel.classList.contains('etr--collapse-how') && window.matchMedia('(max-width: 600px)').matches) {
			how.removeAttribute('open');
		}

		var due = parseInt(panel.getAttribute('data-due'), 10);
		var out = panel.querySelector('[data-etr-left]');
		if (out && due && panel.getAttribute('data-tick') !== '0') {
			var suffix = out.getAttribute('data-suffix') || '';
			var tick = function () {
				var txt = left(due);
				out.textContent = due * 1000 <= Date.now() ? txt : out.textContent.replace(/^[0-9]+h [0-9]{2}m|^[0-9]+m/, txt);
				if (due * 1000 <= Date.now()) out.closest('.etr__due').classList.add('is-late');
			};
			setInterval(tick, 30000);
		}

		var btn = panel.querySelector('[data-etr-sent]');
		var undo = panel.querySelector('[data-etr-undo]');
		if (btn && cfg.sentUrl) {
			var label = btn.textContent;
			btn.addEventListener('click', function () {
				btn.disabled = true;
				post(cfg.sentUrl, panel).then(function (j) {
					var at = panel.querySelector('[data-etr-sent-at]');
					if (at && j.sent) at.textContent = j.sent;
					panel.classList.add('is-sent');
					if (undo) undo.hidden = false;
					btn.disabled = false;
				}).catch(function () {
					btn.disabled = false;
					btn.textContent = label;
					window.alert(t('failed', 'Couldn’t save that. Please try again.'));
				});
			});
		}
		if (undo && cfg.undoUrl) {
			undo.addEventListener('click', function () {
				undo.disabled = true;
				post(cfg.undoUrl, panel).then(function () {
					panel.classList.remove('is-sent');
					undo.disabled = false;
				}).catch(function () {
					undo.disabled = false;
					undo.hidden = true;
				});
			});
		}
	});
})();
