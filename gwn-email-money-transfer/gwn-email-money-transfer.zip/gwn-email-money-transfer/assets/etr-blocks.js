/* Interac e-Transfer — block checkout registration (no build step). */
(function () {
	var reg = window.wc && window.wc.wcBlocksRegistry;
	var el = window.wp && window.wp.element;
	var s = window.wc && window.wc.wcSettings;
	if (!reg || !el) return;
	var data = (s && s.getPaymentMethodData && s.getPaymentMethodData('interac_etransfer')) ||
		(s && s.getSetting && s.getSetting('interac_etransfer_data', {})) || {};
	var title = data.title || 'Interac e-Transfer';

	var Content = function () {
		return el.createElement('div', { dangerouslySetInnerHTML: { __html: data.boxHtml || '' } });
	};
	var Label = function () {
		return el.createElement('span', { className: 'etr-blocks-label' }, title,
			data.logo ? el.createElement('img', { src: data.logo, alt: 'Interac', width: 28, height: 28 }) : null);
	};

	reg.registerPaymentMethod({
		name: 'interac_etransfer',
		label: el.createElement(Label),
		content: el.createElement(Content),
		edit: el.createElement(Content),
		canMakePayment: function () { return true; },
		ariaLabel: title,
		placeOrderButtonLabel: data.buttonLabel || 'Place order',
		supports: { features: data.supports || ['products'] }
	});
})();
