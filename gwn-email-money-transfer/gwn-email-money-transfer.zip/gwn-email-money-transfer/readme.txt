=== GWN Email Money Transfer ===
Contributors: greatwhitenorthdesign
Tags: woocommerce, payment gateway, email money transfer, canada, interac
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
WC requires at least: 8.0
WC tested up to: 11.1
Stable tag: 1.2.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Take Interac e-Transfer payments in WooCommerce: a clear pay panel, a random security answer per order, reminders, auto-cancel and an inbox.

== Description ==

For Canadian stores that accept Interac e-Transfer. The customer places the order, the order waits on hold with stock reserved, and they get everything they need to send the money:

* A pay panel on the thank-you page and in My account: amount, send-to email, recipient name, security question and answer, and the message to include, each with a Copy button.
* A random security answer for every order (or your prefix + the order number, or one fixed answer). None at all if you use Autodeposit.
* The same details in the on-hold email.
* An optional "I've sent it" button so customers can tell you it's on its way (with one Undo within 15 minutes).
* A reminder email and automatic cancel + restock if nothing arrives in time.
* Deadlines in hours, or in business days ("send by Friday, Nov 20") with your own business days and closing time.
* A WooCommerce → e-Transfers inbox: every order waiting on payment, with counts, search, and Mark paid, remind, change answer or cancel in one click.
* Mark paid from the order screen, with the amount received and bank reference. Short payments are flagged.
* Works with the classic checkout and the Cart & Checkout blocks, and with HPOS.
* Every customer-facing line is translation-ready; the checkout title, button and confirmation time are settings.
* A setup check on the settings page tells you when the store is ready to take payments.

Everything is free. There's no paid version.

Made by [Great White North Design](https://greatwhitenorthdesign.ca/), a WooCommerce studio in Ontario. Docs and support: [greatwhitenorthdesign.ca/tools/email-money-transfer](https://greatwhitenorthdesign.ca/tools/email-money-transfer/).

Interac e-Transfer is a registered trademark of Interac Corp. This plugin isn't made, affiliated with or endorsed by Interac Corp, and it doesn't include the Interac logo.

== Installation ==

1. Install and activate the plugin (WooCommerce must be active).
2. WooCommerce → Settings → Payments → Interac e-Transfer: add the email your bank uses for e-Transfers and check the setup box at the top.
3. When the money arrives, open the order and click Mark paid.

== Frequently Asked Questions ==

= Where do customers see the payment details? =

On the thank-you page right after checkout, in the on-hold email, and on the order in My account.

= Is the security answer safe? =

By default every order gets its own random 8-character answer. The order number goes in the e-Transfer message so you can match the payment, so an answer built from the order number would be easy to guess for anyone who sees the Interac notification.

= Does it check my bank automatically? =

No. Banks don't offer a way to read incoming e-Transfers, so you mark orders paid when the deposit lands.

= What happens if nobody pays? =

After the reminder, the order is cancelled when the deadline passes and the stock goes back on the shelf. If the customer tapped "I've sent it", you get 3 more days to check your bank before it's cancelled.

== External services ==

This plugin doesn't send data to any outside service. The "I've sent it" button talks only to your own site (`/wp-json/etransfer/v1/sent`).

== Screenshots ==

1. Checkout: e-Transfer as a payment option, with the three steps explained before the order is placed.
2. The pay panel on the thank-you page: amount, send-to email, recipient name, security question and answer, each with a Copy button, and the time left to send.
3. After the customer taps "I've sent it": the store is told to watch for the payment, with one Undo.
4. The pay panel on a phone.
5. The on-hold email carries the same payment details.
6. WooCommerce → e-Transfers: every order waiting on payment, with counts, search and Mark paid in one click.
7. The order screen: Mark paid with the amount received and bank reference.
8. Settings, with the setup check that says when the store is ready to take payments.

== Changelog ==

= 1.2.1 =
* Plugin home and docs moved to greatwhitenorthdesign.ca/tools/email-money-transfer/.
* Admin screens now credit Great White North Design and link to the docs. Nothing customer-facing changed.
* Admin notices use the plugin's current name.

= 1.2.0 =
* First release on WordPress.org.
* Random security answer per order by default; setup checklist on the settings page.
* e-Transfers inbox, business-day deadlines, reminder and auto-cancel.
* "I've sent it" button with one Undo; the store is notified once per order.
* Works with the Cart & Checkout blocks and HPOS. Fully translatable.
* Formerly "GWN e-Transfer": installing this switches the old plugin off; settings and orders carry over.

== Upgrade Notice ==

= 1.2.1 =
New docs link and admin credit. Nothing customer-facing changed.

= 1.2.0 =
First WordPress.org release. Replaces "GWN e-Transfer"; your settings and orders carry over.
