<?php
/**
 * Uninstall: stops scheduled reminders and auto-cancels.
 * Order history (the _etr_* order meta and notes) is always kept.
 * Gateway settings are kept too, unless wp-config.php defines GWNET_REMOVE_SETTINGS_ON_UNINSTALL as true.
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

if ( function_exists( 'as_unschedule_all_actions' ) ) {
	// By group: every reminder/auto-cancel job carries an order_id, so a hook-only match would miss them.
	as_unschedule_all_actions( '', array(), 'gwn-etransfer' ); // GWNET_GROUP: kept from before the rename
} else {
	global $wpdb;
	$gwnet_table = $wpdb->prefix . 'actionscheduler_actions';
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $gwnet_table ) ) === $gwnet_table ) { // phpcs:ignore
		$wpdb->query( "DELETE FROM {$gwnet_table} WHERE status = 'pending' AND hook IN ('gwnet_reminder','gwnet_expire')" ); // phpcs:ignore
	}
}
delete_transient( 'gwnet_count' );
delete_option( 'gwnet_reschedule' );
// Updater bookkeeping (GitHub build only).
foreach ( array( 'gwnemt_update_signatures', 'gwnemt_auto_updates_defaulted', 'gwnemt_auto_updates_notice' ) as $gwnet_opt ) {
	delete_site_option( $gwnet_opt );
}
delete_metadata( 'user', 0, 'gwnemt_auto_updates_notice_dismissed', '', true );
if ( defined( 'GWNET_REMOVE_SETTINGS_ON_UNINSTALL' ) && GWNET_REMOVE_SETTINGS_ON_UNINSTALL ) {
	delete_option( 'woocommerce_interac_etransfer_settings' );
}
